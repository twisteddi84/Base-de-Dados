﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class SelectTipos : Form
    {
        private SqlConnection cn;
        private List<string> selectedTipos;
        public event EventHandler CancelButtonClicked;
        public SelectTipos()
        {
            InitializeComponent();
            selectedTipos = new List<string>(); // Inicializa a lista no construtor
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void SelectTipos_Load(object sender, EventArgs e)
        {

            string query = "SELECT tipo_servico FROM Banda.Tipo_servico";

            cn = DatabaseManager.GetConnection();
            SqlCommand command = new SqlCommand(query, cn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                checkedListBox1.Items.Add(reader["tipo_servico"].ToString());
            }

            reader.Close();
            cn.Close();
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {

            // Disparar o evento quando o botão "Cancelar" for clicado
            CancelButtonClicked?.Invoke(this, EventArgs.Empty);
            this.Close();
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            // Armazenar as checkboxes selecionadas na lista selectedTipos
            selectedTipos.Clear(); // Limpar a lista antes de adicionar os itens selecionados

            foreach (var item in checkedListBox1.CheckedItems)
            {
                selectedTipos.Add(item.ToString());
            }

            // Fechar o formulário SelectTipos
            this.Close();
        }

        public List<string> GetSelectedTipos()
        {
            return selectedTipos;
        }
    }
}
