﻿
namespace WinFormsApp1
{
    partial class Diretores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancelar = new System.Windows.Forms.Button();
            this.Confirmar = new System.Windows.Forms.Button();
            this.Remover = new System.Windows.Forms.Button();
            this.Atualizar = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.cargo_label = new System.Windows.Forms.Label();
            this.cargo_box = new System.Windows.Forms.TextBox();
            this.tele_label = new System.Windows.Forms.Label();
            this.tele_box = new System.Windows.Forms.TextBox();
            this.data_label = new System.Windows.Forms.Label();
            this.data_box = new System.Windows.Forms.TextBox();
            this.email_label = new System.Windows.Forms.Label();
            this.email_box = new System.Windows.Forms.TextBox();
            this.nome_label = new System.Windows.Forms.Label();
            this.nome_box = new System.Windows.Forms.TextBox();
            this.nif_label = new System.Windows.Forms.Label();
            this.id_box = new System.Windows.Forms.TextBox();
            this.Musicos_label = new System.Windows.Forms.Label();
            this.list_diretores = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Cancelar
            // 
            this.Cancelar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cancelar.Location = new System.Drawing.Point(651, 435);
            this.Cancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(128, 40);
            this.Cancelar.TabIndex = 42;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // Confirmar
            // 
            this.Confirmar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Confirmar.Location = new System.Drawing.Point(451, 435);
            this.Confirmar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Confirmar.Name = "Confirmar";
            this.Confirmar.Size = new System.Drawing.Size(128, 40);
            this.Confirmar.TabIndex = 41;
            this.Confirmar.Text = "Confirmar";
            this.Confirmar.UseVisualStyleBackColor = true;
            this.Confirmar.Click += new System.EventHandler(this.Confirmar_Click);
            // 
            // Remover
            // 
            this.Remover.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Remover.Location = new System.Drawing.Point(307, 555);
            this.Remover.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Remover.Name = "Remover";
            this.Remover.Size = new System.Drawing.Size(128, 40);
            this.Remover.TabIndex = 40;
            this.Remover.Text = "Remover";
            this.Remover.UseVisualStyleBackColor = true;
            this.Remover.Click += new System.EventHandler(this.Remover_Click);
            // 
            // Atualizar
            // 
            this.Atualizar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Atualizar.Location = new System.Drawing.Point(160, 555);
            this.Atualizar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Atualizar.Name = "Atualizar";
            this.Atualizar.Size = new System.Drawing.Size(128, 40);
            this.Atualizar.TabIndex = 39;
            this.Atualizar.Text = "Atualizar";
            this.Atualizar.UseVisualStyleBackColor = true;
            this.Atualizar.Click += new System.EventHandler(this.Atualizar_Click);
            // 
            // Add
            // 
            this.Add.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Add.Location = new System.Drawing.Point(13, 555);
            this.Add.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(128, 40);
            this.Add.TabIndex = 38;
            this.Add.Text = "Adicionar";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(859, 22);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 40);
            this.button1.TabIndex = 37;
            this.button1.Text = "HOME";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cargo_label
            // 
            this.cargo_label.AutoSize = true;
            this.cargo_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cargo_label.Location = new System.Drawing.Point(307, 334);
            this.cargo_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cargo_label.Name = "cargo_label";
            this.cargo_label.Size = new System.Drawing.Size(108, 24);
            this.cargo_label.TabIndex = 36;
            this.cargo_label.Text = "CARGOS:";
            // 
            // cargo_box
            // 
            this.cargo_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cargo_box.Location = new System.Drawing.Point(431, 333);
            this.cargo_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.cargo_box.Name = "cargo_box";
            this.cargo_box.ReadOnly = true;
            this.cargo_box.Size = new System.Drawing.Size(288, 28);
            this.cargo_box.TabIndex = 35;
            // 
            // tele_label
            // 
            this.tele_label.AutoSize = true;
            this.tele_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_label.Location = new System.Drawing.Point(308, 386);
            this.tele_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tele_label.Name = "tele_label";
            this.tele_label.Size = new System.Drawing.Size(136, 24);
            this.tele_label.TabIndex = 34;
            this.tele_label.Text = "TELEFONE:";
            // 
            // tele_box
            // 
            this.tele_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_box.Location = new System.Drawing.Point(462, 382);
            this.tele_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.tele_box.Name = "tele_box";
            this.tele_box.ReadOnly = true;
            this.tele_box.Size = new System.Drawing.Size(185, 28);
            this.tele_box.TabIndex = 33;
            // 
            // data_label
            // 
            this.data_label.AutoSize = true;
            this.data_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_label.Location = new System.Drawing.Point(307, 208);
            this.data_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.data_label.Name = "data_label";
            this.data_label.Size = new System.Drawing.Size(234, 24);
            this.data_label.TabIndex = 32;
            this.data_label.Text = "DATA NASCIMENTO:";
            // 
            // data_box
            // 
            this.data_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_box.Location = new System.Drawing.Point(565, 205);
            this.data_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.data_box.Name = "data_box";
            this.data_box.ReadOnly = true;
            this.data_box.Size = new System.Drawing.Size(178, 28);
            this.data_box.TabIndex = 31;
            // 
            // email_label
            // 
            this.email_label.AutoSize = true;
            this.email_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.email_label.Location = new System.Drawing.Point(307, 273);
            this.email_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.email_label.Name = "email_label";
            this.email_label.Size = new System.Drawing.Size(94, 24);
            this.email_label.TabIndex = 30;
            this.email_label.Text = "EMAIL:";
            // 
            // email_box
            // 
            this.email_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.email_box.Location = new System.Drawing.Point(416, 272);
            this.email_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.email_box.Name = "email_box";
            this.email_box.ReadOnly = true;
            this.email_box.Size = new System.Drawing.Size(272, 28);
            this.email_box.TabIndex = 29;
            // 
            // nome_label
            // 
            this.nome_label.AutoSize = true;
            this.nome_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_label.Location = new System.Drawing.Point(565, 136);
            this.nome_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nome_label.Name = "nome_label";
            this.nome_label.Size = new System.Drawing.Size(80, 24);
            this.nome_label.TabIndex = 28;
            this.nome_label.Text = "NOME:";
            // 
            // nome_box
            // 
            this.nome_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_box.Location = new System.Drawing.Point(660, 133);
            this.nome_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.nome_box.Name = "nome_box";
            this.nome_box.ReadOnly = true;
            this.nome_box.Size = new System.Drawing.Size(268, 28);
            this.nome_box.TabIndex = 27;
            // 
            // nif_label
            // 
            this.nif_label.AutoSize = true;
            this.nif_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nif_label.Location = new System.Drawing.Point(307, 136);
            this.nif_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nif_label.Name = "nif_label";
            this.nif_label.Size = new System.Drawing.Size(66, 24);
            this.nif_label.TabIndex = 26;
            this.nif_label.Text = "NIF:";
            // 
            // id_box
            // 
            this.id_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_box.Location = new System.Drawing.Point(379, 136);
            this.id_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.id_box.Name = "id_box";
            this.id_box.ReadOnly = true;
            this.id_box.Size = new System.Drawing.Size(162, 28);
            this.id_box.TabIndex = 25;
            // 
            // Musicos_label
            // 
            this.Musicos_label.AutoSize = true;
            this.Musicos_label.Font = new System.Drawing.Font("OCR A Extended", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Musicos_label.Location = new System.Drawing.Point(71, 7);
            this.Musicos_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Musicos_label.Name = "Musicos_label";
            this.Musicos_label.Size = new System.Drawing.Size(166, 29);
            this.Musicos_label.TabIndex = 24;
            this.Musicos_label.Text = "Diretores";
            // 
            // list_diretores
            // 
            this.list_diretores.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_diretores.FormattingEnabled = true;
            this.list_diretores.ItemHeight = 17;
            this.list_diretores.Location = new System.Drawing.Point(2, 40);
            this.list_diretores.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.list_diretores.Name = "list_diretores";
            this.list_diretores.Size = new System.Drawing.Size(298, 463);
            this.list_diretores.TabIndex = 23;
            this.list_diretores.SelectedIndexChanged += new System.EventHandler(this.list_diretores_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(502, 455);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(265, 58);
            this.button2.TabIndex = 43;
            this.button2.Text = "Ver Serviços Realizados";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Diretores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(996, 603);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.Confirmar);
            this.Controls.Add(this.Remover);
            this.Controls.Add(this.Atualizar);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cargo_label);
            this.Controls.Add(this.cargo_box);
            this.Controls.Add(this.tele_label);
            this.Controls.Add(this.tele_box);
            this.Controls.Add(this.data_label);
            this.Controls.Add(this.data_box);
            this.Controls.Add(this.email_label);
            this.Controls.Add(this.email_box);
            this.Controls.Add(this.nome_label);
            this.Controls.Add(this.nome_box);
            this.Controls.Add(this.nif_label);
            this.Controls.Add(this.id_box);
            this.Controls.Add(this.Musicos_label);
            this.Controls.Add(this.list_diretores);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Diretores";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Diretores";
            this.Load += new System.EventHandler(this.Diretores_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button Confirmar;
        private System.Windows.Forms.Button Remover;
        private System.Windows.Forms.Button Atualizar;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label cargo_label;
        private System.Windows.Forms.TextBox cargo_box;
        private System.Windows.Forms.Label tele_label;
        private System.Windows.Forms.TextBox tele_box;
        private System.Windows.Forms.Label data_label;
        private System.Windows.Forms.TextBox data_box;
        private System.Windows.Forms.Label email_label;
        private System.Windows.Forms.TextBox email_box;
        private System.Windows.Forms.Label nome_label;
        private System.Windows.Forms.TextBox nome_box;
        private System.Windows.Forms.Label nif_label;
        private System.Windows.Forms.TextBox id_box;
        private System.Windows.Forms.Label Musicos_label;
        private System.Windows.Forms.ListBox list_diretores;
        private System.Windows.Forms.Button button2;
    }
}