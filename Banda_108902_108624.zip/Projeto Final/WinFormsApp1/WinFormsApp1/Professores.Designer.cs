﻿
namespace WinFormsApp1
{
    partial class Professores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Remover = new System.Windows.Forms.Button();
            this.Atualizar = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Cancelar = new System.Windows.Forms.Button();
            this.Confirmar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.ordenado_label = new System.Windows.Forms.Label();
            this.ordenado_box = new System.Windows.Forms.TextBox();
            this.tele_label = new System.Windows.Forms.Label();
            this.tele_box = new System.Windows.Forms.TextBox();
            this.data_label = new System.Windows.Forms.Label();
            this.data_box = new System.Windows.Forms.TextBox();
            this.tipo_label = new System.Windows.Forms.Label();
            this.tipo_box = new System.Windows.Forms.TextBox();
            this.nome_label = new System.Windows.Forms.Label();
            this.nome_box = new System.Windows.Forms.TextBox();
            this.nif_label = new System.Windows.Forms.Label();
            this.id_box = new System.Windows.Forms.TextBox();
            this.Musicos_label = new System.Windows.Forms.Label();
            this.list_professores = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Remover
            // 
            this.Remover.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Remover.Location = new System.Drawing.Point(320, 518);
            this.Remover.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Remover.Name = "Remover";
            this.Remover.Size = new System.Drawing.Size(128, 40);
            this.Remover.TabIndex = 64;
            this.Remover.Text = "Remover";
            this.Remover.UseVisualStyleBackColor = true;
            this.Remover.Click += new System.EventHandler(this.Remover_Click);
            // 
            // Atualizar
            // 
            this.Atualizar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Atualizar.Location = new System.Drawing.Point(173, 518);
            this.Atualizar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Atualizar.Name = "Atualizar";
            this.Atualizar.Size = new System.Drawing.Size(128, 40);
            this.Atualizar.TabIndex = 63;
            this.Atualizar.Text = "Atualizar";
            this.Atualizar.UseVisualStyleBackColor = true;
            this.Atualizar.Click += new System.EventHandler(this.Atualizar_Click);
            // 
            // Add
            // 
            this.Add.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Add.Location = new System.Drawing.Point(26, 518);
            this.Add.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(128, 40);
            this.Add.TabIndex = 62;
            this.Add.Text = "Adicionar";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Cancelar
            // 
            this.Cancelar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cancelar.Location = new System.Drawing.Point(651, 394);
            this.Cancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(128, 40);
            this.Cancelar.TabIndex = 60;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click_1);
            // 
            // Confirmar
            // 
            this.Confirmar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Confirmar.Location = new System.Drawing.Point(451, 394);
            this.Confirmar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Confirmar.Name = "Confirmar";
            this.Confirmar.Size = new System.Drawing.Size(128, 40);
            this.Confirmar.TabIndex = 59;
            this.Confirmar.Text = "Confirmar";
            this.Confirmar.UseVisualStyleBackColor = true;
            this.Confirmar.Click += new System.EventHandler(this.Confirmar_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(861, 22);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 40);
            this.button1.TabIndex = 58;
            this.button1.Text = "HOME";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ordenado_label
            // 
            this.ordenado_label.AutoSize = true;
            this.ordenado_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ordenado_label.Location = new System.Drawing.Point(309, 332);
            this.ordenado_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ordenado_label.Name = "ordenado_label";
            this.ordenado_label.Size = new System.Drawing.Size(136, 24);
            this.ordenado_label.TabIndex = 57;
            this.ordenado_label.Text = "ORDENADO:";
            this.ordenado_label.Click += new System.EventHandler(this.ordenado_label_Click);
            // 
            // ordenado_box
            // 
            this.ordenado_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ordenado_box.Location = new System.Drawing.Point(476, 332);
            this.ordenado_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.ordenado_box.Name = "ordenado_box";
            this.ordenado_box.ReadOnly = true;
            this.ordenado_box.Size = new System.Drawing.Size(116, 28);
            this.ordenado_box.TabIndex = 56;
            // 
            // tele_label
            // 
            this.tele_label.AutoSize = true;
            this.tele_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_label.Location = new System.Drawing.Point(620, 332);
            this.tele_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tele_label.Name = "tele_label";
            this.tele_label.Size = new System.Drawing.Size(136, 24);
            this.tele_label.TabIndex = 55;
            this.tele_label.Text = "TELEFONE:";
            // 
            // tele_box
            // 
            this.tele_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_box.Location = new System.Drawing.Point(774, 331);
            this.tele_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.tele_box.Name = "tele_box";
            this.tele_box.ReadOnly = true;
            this.tele_box.Size = new System.Drawing.Size(187, 28);
            this.tele_box.TabIndex = 54;
            this.tele_box.TextChanged += new System.EventHandler(this.tele_box_TextChanged);
            // 
            // data_label
            // 
            this.data_label.AutoSize = true;
            this.data_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_label.Location = new System.Drawing.Point(309, 208);
            this.data_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.data_label.Name = "data_label";
            this.data_label.Size = new System.Drawing.Size(234, 24);
            this.data_label.TabIndex = 53;
            this.data_label.Text = "DATA NASCIMENTO:";
            // 
            // data_box
            // 
            this.data_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_box.Location = new System.Drawing.Point(567, 205);
            this.data_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.data_box.Name = "data_box";
            this.data_box.ReadOnly = true;
            this.data_box.Size = new System.Drawing.Size(178, 28);
            this.data_box.TabIndex = 52;
            // 
            // tipo_label
            // 
            this.tipo_label.AutoSize = true;
            this.tipo_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tipo_label.Location = new System.Drawing.Point(309, 273);
            this.tipo_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tipo_label.Name = "tipo_label";
            this.tipo_label.Size = new System.Drawing.Size(248, 24);
            this.tipo_label.TabIndex = 51;
            this.tipo_label.Text = "TIPO INSTRUMENTO:";
            // 
            // tipo_box
            // 
            this.tipo_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tipo_box.Location = new System.Drawing.Point(582, 270);
            this.tipo_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.tipo_box.Name = "tipo_box";
            this.tipo_box.ReadOnly = true;
            this.tipo_box.Size = new System.Drawing.Size(246, 28);
            this.tipo_box.TabIndex = 50;
            // 
            // nome_label
            // 
            this.nome_label.AutoSize = true;
            this.nome_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_label.Location = new System.Drawing.Point(567, 136);
            this.nome_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nome_label.Name = "nome_label";
            this.nome_label.Size = new System.Drawing.Size(80, 24);
            this.nome_label.TabIndex = 49;
            this.nome_label.Text = "NOME:";
            // 
            // nome_box
            // 
            this.nome_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_box.Location = new System.Drawing.Point(670, 135);
            this.nome_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.nome_box.Name = "nome_box";
            this.nome_box.ReadOnly = true;
            this.nome_box.Size = new System.Drawing.Size(268, 28);
            this.nome_box.TabIndex = 48;
            // 
            // nif_label
            // 
            this.nif_label.AutoSize = true;
            this.nif_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nif_label.Location = new System.Drawing.Point(309, 136);
            this.nif_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nif_label.Name = "nif_label";
            this.nif_label.Size = new System.Drawing.Size(66, 24);
            this.nif_label.TabIndex = 47;
            this.nif_label.Text = "NIF:";
            // 
            // id_box
            // 
            this.id_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_box.Location = new System.Drawing.Point(381, 136);
            this.id_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.id_box.Name = "id_box";
            this.id_box.ReadOnly = true;
            this.id_box.Size = new System.Drawing.Size(162, 28);
            this.id_box.TabIndex = 46;
            // 
            // Musicos_label
            // 
            this.Musicos_label.AutoSize = true;
            this.Musicos_label.Font = new System.Drawing.Font("OCR A Extended", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Musicos_label.Location = new System.Drawing.Point(73, 7);
            this.Musicos_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Musicos_label.Name = "Musicos_label";
            this.Musicos_label.Size = new System.Drawing.Size(200, 29);
            this.Musicos_label.TabIndex = 45;
            this.Musicos_label.Text = "Professores";
            // 
            // list_professores
            // 
            this.list_professores.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_professores.FormattingEnabled = true;
            this.list_professores.ItemHeight = 17;
            this.list_professores.Location = new System.Drawing.Point(4, 40);
            this.list_professores.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.list_professores.Name = "list_professores";
            this.list_professores.Size = new System.Drawing.Size(298, 463);
            this.list_professores.TabIndex = 44;
            this.list_professores.SelectedIndexChanged += new System.EventHandler(this.list_professores_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(557, 422);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(187, 45);
            this.button2.TabIndex = 65;
            this.button2.Text = "Ver Alunos";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Professores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1014, 566);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Remover);
            this.Controls.Add(this.Atualizar);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.Confirmar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ordenado_label);
            this.Controls.Add(this.ordenado_box);
            this.Controls.Add(this.tele_label);
            this.Controls.Add(this.tele_box);
            this.Controls.Add(this.data_label);
            this.Controls.Add(this.data_box);
            this.Controls.Add(this.tipo_label);
            this.Controls.Add(this.tipo_box);
            this.Controls.Add(this.nome_label);
            this.Controls.Add(this.nome_box);
            this.Controls.Add(this.nif_label);
            this.Controls.Add(this.id_box);
            this.Controls.Add(this.Musicos_label);
            this.Controls.Add(this.list_professores);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Professores";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Professores";
            this.Load += new System.EventHandler(this.Professores_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Remover;
        private System.Windows.Forms.Button Atualizar;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button Confirmar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label ordenado_label;
        private System.Windows.Forms.TextBox oredenado_box;
        private System.Windows.Forms.Label tele_label;
        private System.Windows.Forms.TextBox tele_box;
        private System.Windows.Forms.Label data_label;
        private System.Windows.Forms.TextBox data_box;
        private System.Windows.Forms.Label tipo_label;
        private System.Windows.Forms.TextBox tipo_box;
        private System.Windows.Forms.Label nome_label;
        private System.Windows.Forms.TextBox nome_box;
        private System.Windows.Forms.Label nif_label;
        private System.Windows.Forms.TextBox id_box;
        private System.Windows.Forms.Label Musicos_label;
        private System.Windows.Forms.ListBox list_professores;
        private System.Windows.Forms.TextBox ordenado_box;
        private System.Windows.Forms.Button button2;
    }
}