﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{

    public partial class Professores : Form
    {

        private SqlConnection cn;
        private int currentContact;
        private bool adding;
        public Professores()
        {
            InitializeComponent();
        }

        private void ordenado_label_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;
        }
        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }
        private float ParseFloat(string value)
        {
            value = value.Replace("$", "").Replace(",", "");

            if (float.TryParse(value, out float result))
            {
                return result / 100; // Divide the value by 100 to get the desired format (e.g., 1900 becomes 19)
            }

            return 0.0f;
        }
        private double ParseDouble(string value)
        {
            value = value.Replace("$", "").Replace(",", "");

            if (double.TryParse(value, out double result))
            {
                return result / 100; // Divide the value by 100 to get the desired format (e.g., 1900 becomes 19)
            }

            return 0.0;
        }
        private void Professores_Load(object sender, EventArgs e)
        {
            button2.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Professor ", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            list_professores.Items.Clear();

            while (reader.Read())
            {
                Professor i = new Professor();
                i.NIF = (int)reader["NIF"];
                i.DataNasc = (DateTime)reader["data_de_nascimento"];
                i.Nome = reader["nome"].ToString();
                i.TipoInstru = reader["tipo_instrumento"].ToString();
                i.Telefone = (int)reader["telefone"];
                i.Ordenado = (float)(double)reader["ordenado"];
             
                list_professores.Items.Add(i);
            }
            reader.Close();
            cn.Close();

            currentContact = 0;
            ShowContact();
        }
        public void ShowContact()
        {
            if (list_professores.Items.Count == 0 || currentContact < 0)
                return;

            Professor i = (Professor)list_professores.Items[currentContact];
            id_box.Text = i.NIF.ToString();
            data_box.Text = i.DataNasc.ToString("yyyy-MM-dd");
            nome_box.Text = i.Nome;
            tipo_box.Text = i.TipoInstru.ToString();
            tele_box.Text = i.Telefone.ToString();
            ordenado_box.Text = i.Ordenado.ToString();

        }

        private void list_professores_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_professores.SelectedIndex >= 0)
            {
                currentContact = list_professores.SelectedIndex;
                ShowContact();
            }
        }

        public void ClearFields()
        {
            id_box.Text = "";
            data_box.Text = "";
            nome_box.Text = "";
            tipo_box.Text = "";
            ordenado_box.Text = "";
            tele_box.Text = "";

        }

        public void UnlockControls()
        {
            id_box.ReadOnly = false;
            data_box.ReadOnly = false;
            nome_box.ReadOnly = false;
            tipo_box.ReadOnly = false;
            ordenado_box.ReadOnly = false;
            tele_box.ReadOnly = false;
        }

        public void LockControls()
        {
            id_box.ReadOnly = true;
            data_box.ReadOnly = true;
            nome_box.ReadOnly = true;
            tipo_box.ReadOnly = true;
            ordenado_box.ReadOnly = true;
            tele_box.ReadOnly = true;
        }

        public void HideButtons()
        {
            UnlockControls();
            Add.Visible = false;
            Atualizar.Visible = false;
            Remover.Visible = false;
        }


        private void Add_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            adding = true;
            ClearFields();
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_professores.Enabled = false;
        }
        public void ShowButtons()
        {
            LockControls();
            Add.Visible = true;
            Atualizar.Visible = true;
            Remover.Visible = true;
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                SaveProf();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            list_professores.Enabled = true;
            int idx = list_professores.FindString(id_box.Text);
            list_professores.SelectedIndex = idx;
            ShowButtons();
            Professores_Load(sender, e);
            button2.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
        }

        private bool SaveProf()
        {
            Professor i = new Professor();
            try
            {
                if (adding)
                {
                    i.NIF = int.Parse(id_box.Text);
                    i.DataNasc = DateTime.Parse(data_box.Text);
                    i.Nome = nome_box.Text;
                    i.Telefone = int.Parse(tele_box.Text);
                    i.TipoInstru = tipo_box.Text;
                    i.Ordenado = float.Parse(ordenado_box.Text);
                }
                else
                {
                    i.NIF = int.Parse(id_box.Text);
                    i.DataNasc = DateTime.Parse(data_box.Text);
                    i.Nome = nome_box.Text;
                    i.Telefone = int.Parse(tele_box.Text);
                    i.TipoInstru = tipo_box.Text;
                    i.Ordenado = float.Parse(ordenado_box.Text);
                }
            
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            if (adding)
            {
                SubmitContact(i);
                list_professores.Items.Add(i);
            }
            else
            {
                UpdateProf(i);
                list_professores.Items[currentContact] = i;
            }
            return true;
        }

        private void SubmitContact(Professor C)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "InsertProfessor";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", C.NIF);
            cmd.Parameters.AddWithValue("@Nome", C.Nome);
            cmd.Parameters.AddWithValue("@Data", C.DataNasc);
            cmd.Parameters.AddWithValue("@TipoInstru", C.TipoInstru);
            cmd.Parameters.AddWithValue("@Telefone", C.Telefone);
            cmd.Parameters.AddWithValue("@Ordenado", C.Ordenado);
            cmd.Connection = cn;

            // Execute the stored procedure
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to insert professor and update aluno. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                // Rest of your code
            }
        }

        private void UpdateProf(Professor C)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "UpdateProfessor";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", C.NIF);
            cmd.Parameters.AddWithValue("@Nome", C.Nome);
            cmd.Parameters.AddWithValue("@Data", C.DataNasc);
            cmd.Parameters.AddWithValue("@TipoInstru", C.TipoInstru);
            cmd.Parameters.AddWithValue("@Telefone", C.Telefone);
            cmd.Parameters.AddWithValue("@Ordenado", C.Ordenado);
            cmd.Connection = cn;

            // Execute the stored procedure
            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update professor and update aluno. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                // Rest of your code
            }
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            list_professores.Enabled = true;
            if (list_professores.Items.Count > 0)
            {
                currentContact = list_professores.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }

        private void RemoveContact(int NIF)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "DELETE Banda.Professor WHERE NIF=@NIF";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", NIF);
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to delete contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private void Atualizar_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            currentContact = list_professores.SelectedIndex;
            if (currentContact <= 0)
            {
                //MessageBox.Show("Please select a contact to edit");
                currentContact = 1;
                //return;
            }
            adding = false;
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_professores.Enabled = false;
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            if (list_professores.SelectedIndex > -1)
            {
                try
                {
                    RemoveContact(((Professor)list_professores.SelectedItem).NIF);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                list_professores.Items.RemoveAt(list_professores.SelectedIndex);
                if (currentContact == list_professores.Items.Count)
                    currentContact = list_professores.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more contacts");
                }
                else
                {
                    ShowContact();
                }
            }
        }

        private void Cancelar_Click_1(object sender, EventArgs e)
        {
            tipo_box.Visible = true;
            tele_box.Visible = true;
            nome_box.Visible = true;
            data_box.Visible = true;
            id_box.Visible = true;
            ordenado_box.Visible = true;

            Confirmar.Visible = false;
            Cancelar.Visible = false;
            list_professores.Enabled = true;
            if (list_professores.Items.Count > 0)
            {
                currentContact = list_professores.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }

        private void tele_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool HasAlunos = false;
            cn = DatabaseManager.GetConnection();
            SqlCommand cmd = new SqlCommand("Banda.GetAlunoByProfNif", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@NIF_prof", int.Parse(id_box.Text));

            try
            {
                SqlDataReader reader = cmd.ExecuteReader();
                String mensagem = "Alunos do Professor " + nome_box.Text + ":\n";
                while (reader.Read())
                {
                    String aluno = reader["NIF"].ToString() + " " + (String)reader["nome"] + " " + reader["naipe"].ToString();
                    mensagem += aluno + "\n";
                    HasAlunos = true;

                }

                reader.Close();
                if (HasAlunos)
                {
                    MessageBox.Show(mensagem);
                }
                else
                {
                    MessageBox.Show("Professor não tem alunos");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
