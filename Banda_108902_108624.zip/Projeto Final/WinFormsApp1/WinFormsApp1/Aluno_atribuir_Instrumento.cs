﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Aluno_atribuir_Instrumento : Form
    {
        private int currentContact;
        private SqlConnection cn;
        private String ID_Instrumento;
        public Aluno_atribuir_Instrumento(String ID)
        {
            ID_Instrumento = ID;
            InitializeComponent();
        }

        private void Aluno_atribuir_Instrumento_Load(object sender, EventArgs e)
        {
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Aluno ", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            list_alunos.Items.Clear();

            while (reader.Read())
            {
                Aluno i = new Aluno();
                i.NIF = (int)reader["NIF"];
                i.DataNasc = (DateTime)reader["data_de_nascimento"];
                i.Nome = reader["nome"].ToString();
                i.Naipe = reader["naipe"].ToString();
                i.Telefone = (int)reader["telefone"];
                if (reader["NIF_Professor"] != DBNull.Value)
                {
                    i.NIF_Professor = (int)reader["NIF_Professor"];
                }
                else
                {
                    i.NIF_Professor = 404; // Define o valor como nulo, dependendo da definição do tipo da propriedade FardaID em Musicos_class
                }

                list_alunos.Items.Add(i);
            }

            reader.Close();

            cn.Close();


            currentContact = 0;
            ShowContact();
        }

        public void ShowContact()
        {
            if (list_alunos.Items.Count == 0 | currentContact < 0)
                return;
            Aluno i = new Aluno();
            i = (Aluno)list_alunos.Items[currentContact];
            id_box.Text = i.NIF.ToString();
            data_box.Text = i.DataNasc.ToString("yyyy-MM-dd");
            nome_box.Text = i.Nome;
            naipe_box.Text = i.Naipe;
            tele_box.Text = i.Telefone.ToString();
            if (i.NIF_Professor == 404)
            {
                prof_box.Text = "Nao tem";
            }
            else
            {
                prof_box.Text = i.NIF_Professor.ToString();
            }
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = DatabaseManager.GetConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }

        private void list_alunos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_alunos.SelectedIndex >= 0)
            {
                currentContact = list_alunos.SelectedIndex;
                ShowContact();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            cn = DatabaseManager.GetConnection();
            if (list_alunos.SelectedIndex >= 0)
            {

                // Update the "Pessoa_Instrumento" table with the selected musician's NIF for the specified instrument ID
                if (verifySGBDConnection())
                {
                    string insertQuery = "Banda.InsertAlunoInstrumento"; 
                    SqlCommand updateCmd = new SqlCommand(insertQuery, cn);
                    updateCmd.CommandType = CommandType.StoredProcedure;
                    updateCmd.Parameters.AddWithValue("@NIF", int.Parse(id_box.Text));
                    updateCmd.Parameters.AddWithValue("@InstrumentoID", int.Parse(ID_Instrumento));
                    int rowsAffected = updateCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Instrumento atribuído ao aluno com sucesso!");
                        // Perform any additional actions or updates if needed
                        Instrumentos i = new Instrumentos();
                        i.Show();
                        Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Falha ao atribuir o instrumento ao aluno.");
                    }

                    cn.Close();
                }
            }
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            Instrumentos i = new Instrumentos();
            i.Show();
            Close();
        }
    }
}
