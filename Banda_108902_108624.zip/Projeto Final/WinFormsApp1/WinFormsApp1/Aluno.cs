﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
	class Aluno
	{
		private int _NIF;
		private DateTime _dataNasc;
		private String _nome;
		private String _naipe;
		private int _telefone;
		private int _NIF_Professor;

		public int NIF
		{
			get { return _NIF; }
			set { _NIF = value; }
		}

		public int Telefone
		{
			get { return _telefone; }
			set { _telefone = value; }
		}

		public String Nome
		{
			get { return _nome; }
			set
			{
				if (value == null | String.IsNullOrEmpty(value))
				{
					throw new Exception(" field can’t be empty");
					return;
				}
				_nome = value;
			}
		}

		public String Naipe
		{
			get { return _naipe; }
			set { _naipe = value; }
		}

		public DateTime DataNasc
		{
			get { return _dataNasc; }
			set { _dataNasc = value; }
		}

		public int NIF_Professor
		{
			get { return _NIF_Professor; }
			set { _NIF_Professor = value; }
		}




		public override String ToString()
		{
			return _NIF + "   " + _nome;
		}

		public Aluno() : base()
		{
		}

		public Aluno(int NIF, DateTime datanasc, String nome, String naipe, int telefone,int NIF_Professor) : base()
		{
			this._NIF = NIF;
			this._dataNasc = datanasc;
			this._nome = nome;
			this._naipe = naipe;
			this._telefone = telefone;
			this._NIF_Professor = NIF_Professor;
		}
		public Aluno(int NIF, DateTime datanasc, String nome, String naipe, int telefone) : base()
		{
			this._NIF = NIF;
			this._dataNasc = datanasc;
			this._nome = nome;
			this._naipe = naipe;
			this._telefone = telefone;
		}


		public Aluno(int NIF, String nome) : base()
		{
			this._NIF = NIF;
			this._nome = nome;
		}
	}
}
