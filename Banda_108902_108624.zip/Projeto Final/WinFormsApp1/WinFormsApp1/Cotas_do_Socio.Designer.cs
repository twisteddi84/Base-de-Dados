﻿
namespace WinFormsApp1
{
    partial class Cotas_do_Socio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Voltar = new System.Windows.Forms.Button();
            this.pagamento_label = new System.Windows.Forms.Label();
            this.data_box = new System.Windows.Forms.TextBox();
            this.diretor_label = new System.Windows.Forms.Label();
            this.diretor_box = new System.Windows.Forms.TextBox();
            this.ano_label = new System.Windows.Forms.Label();
            this.ano_box = new System.Windows.Forms.TextBox();
            this.CotaSocio_label = new System.Windows.Forms.Label();
            this.list_cotasSocio = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.valorBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Voltar
            // 
            this.Voltar.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Voltar.Location = new System.Drawing.Point(654, 534);
            this.Voltar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Voltar.Name = "Voltar";
            this.Voltar.Size = new System.Drawing.Size(106, 40);
            this.Voltar.TabIndex = 53;
            this.Voltar.Text = "VOLTAR";
            this.Voltar.UseVisualStyleBackColor = true;
            this.Voltar.Click += new System.EventHandler(this.Voltar_Click);
            // 
            // pagamento_label
            // 
            this.pagamento_label.AutoSize = true;
            this.pagamento_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pagamento_label.Location = new System.Drawing.Point(247, 309);
            this.pagamento_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pagamento_label.Name = "pagamento_label";
            this.pagamento_label.Size = new System.Drawing.Size(220, 24);
            this.pagamento_label.TabIndex = 52;
            this.pagamento_label.Text = "DATA PAGAMENTO:";
            this.pagamento_label.Click += new System.EventHandler(this.tele_label_Click);
            // 
            // data_box
            // 
            this.data_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_box.Location = new System.Drawing.Point(475, 309);
            this.data_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.data_box.Name = "data_box";
            this.data_box.ReadOnly = true;
            this.data_box.Size = new System.Drawing.Size(230, 28);
            this.data_box.TabIndex = 51;
            // 
            // diretor_label
            // 
            this.diretor_label.AutoSize = true;
            this.diretor_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.diretor_label.Location = new System.Drawing.Point(247, 215);
            this.diretor_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.diretor_label.Name = "diretor_label";
            this.diretor_label.Size = new System.Drawing.Size(234, 24);
            this.diretor_label.TabIndex = 50;
            this.diretor_label.Text = "DIRETOR EMISSOR:";
            // 
            // diretor_box
            // 
            this.diretor_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.diretor_box.Location = new System.Drawing.Point(489, 215);
            this.diretor_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.diretor_box.Name = "diretor_box";
            this.diretor_box.ReadOnly = true;
            this.diretor_box.Size = new System.Drawing.Size(261, 28);
            this.diretor_box.TabIndex = 49;
            // 
            // ano_label
            // 
            this.ano_label.AutoSize = true;
            this.ano_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ano_label.Location = new System.Drawing.Point(247, 127);
            this.ano_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ano_label.Name = "ano_label";
            this.ano_label.Size = new System.Drawing.Size(66, 24);
            this.ano_label.TabIndex = 46;
            this.ano_label.Text = "ANO:";
            // 
            // ano_box
            // 
            this.ano_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ano_box.Location = new System.Drawing.Point(319, 127);
            this.ano_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.ano_box.Name = "ano_box";
            this.ano_box.ReadOnly = true;
            this.ano_box.Size = new System.Drawing.Size(148, 28);
            this.ano_box.TabIndex = 45;
            // 
            // CotaSocio_label
            // 
            this.CotaSocio_label.AutoSize = true;
            this.CotaSocio_label.Font = new System.Drawing.Font("OCR A Extended", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CotaSocio_label.Location = new System.Drawing.Point(247, 18);
            this.CotaSocio_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CotaSocio_label.Name = "CotaSocio_label";
            this.CotaSocio_label.Size = new System.Drawing.Size(251, 29);
            this.CotaSocio_label.TabIndex = 44;
            this.CotaSocio_label.Text = "Cotas do Sócio";
            this.CotaSocio_label.Click += new System.EventHandler(this.CotaSocio_label_Click);
            // 
            // list_cotasSocio
            // 
            this.list_cotasSocio.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_cotasSocio.FormattingEnabled = true;
            this.list_cotasSocio.ItemHeight = 17;
            this.list_cotasSocio.Location = new System.Drawing.Point(1, 0);
            this.list_cotasSocio.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.list_cotasSocio.Name = "list_cotasSocio";
            this.list_cotasSocio.Size = new System.Drawing.Size(218, 582);
            this.list_cotasSocio.TabIndex = 43;
            this.list_cotasSocio.SelectedIndexChanged += new System.EventHandler(this.list_cotasSocio_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(499, 127);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 24);
            this.label1.TabIndex = 55;
            this.label1.Text = "VALOR:";
            // 
            // valorBox1
            // 
            this.valorBox1.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.valorBox1.Location = new System.Drawing.Point(601, 127);
            this.valorBox1.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.valorBox1.Name = "valorBox1";
            this.valorBox1.ReadOnly = true;
            this.valorBox1.Size = new System.Drawing.Size(148, 28);
            this.valorBox1.TabIndex = 54;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(519, 362);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 63);
            this.button1.TabIndex = 56;
            this.button1.Text = "Colocar Pago";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Cotas_do_Socio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 586);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.valorBox1);
            this.Controls.Add(this.Voltar);
            this.Controls.Add(this.pagamento_label);
            this.Controls.Add(this.data_box);
            this.Controls.Add(this.diretor_label);
            this.Controls.Add(this.diretor_box);
            this.Controls.Add(this.ano_label);
            this.Controls.Add(this.ano_box);
            this.Controls.Add(this.CotaSocio_label);
            this.Controls.Add(this.list_cotasSocio);
            this.Name = "Cotas_do_Socio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cotas_do_Socio";
            this.Load += new System.EventHandler(this.Cotas_do_Socio_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Voltar;
        private System.Windows.Forms.Label pagamento_label;
        private System.Windows.Forms.TextBox data_box;
        private System.Windows.Forms.Label diretor_label;
        private System.Windows.Forms.TextBox diretor_box;
        private System.Windows.Forms.Label ano_label;
        private System.Windows.Forms.TextBox ano_box;
        private System.Windows.Forms.Label CotaSocio_label;
        private System.Windows.Forms.ListBox list_cotasSocio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox valorBox1;
        private System.Windows.Forms.Button button1;
    }
}