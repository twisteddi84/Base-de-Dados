﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WinFormsApp1
{
    public partial class Alunos : Form
    {
        private SqlConnection cn;
        private int currentContact;
        private bool adding;
        private int nif_professor_selecionado;
        public Alunos()
        {
            InitializeComponent();
        }
        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }

        private void Alunos_Load(object sender, EventArgs e)
        {
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Aluno ", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            list_alunos.Items.Clear();

            while (reader.Read())
            {
                Aluno i = new Aluno();
                i.NIF = (int)reader["NIF"];
                i.DataNasc = (DateTime)reader["data_de_nascimento"];
                i.Nome = reader["nome"].ToString();
                i.Naipe = reader["naipe"].ToString();
                i.Telefone = (int)reader["telefone"];
                if (reader["NIF_Professor"] != DBNull.Value)
                {
                    i.NIF_Professor = (int)reader["NIF_Professor"];
                }
                else
                {
                    i.NIF_Professor = 404; // Define o valor como nulo, dependendo da definição do tipo da propriedade FardaID em Musicos_class
                }

                list_alunos.Items.Add(i);
            }
            reader.Close();

            cn.Close();


            currentContact = 0;
            ShowContact();
        }

        public void ShowContact()
        {
            if (list_alunos.Items.Count == 0 | currentContact < 0)
                return;
            Aluno i = new Aluno();
            i = (Aluno)list_alunos.Items[currentContact];
            id_box.Text = i.NIF.ToString();
            data_box.Text = i.DataNasc.ToString("yyyy-MM-dd");
            nome_box.Text = i.Nome;
            naipe_box.Text = i.Naipe;
            tele_box.Text = i.Telefone.ToString();
            if (i.NIF_Professor == 404)
            {
                prof_but.Visible = true;
                prof_box.Text = "Nao tem";
                removerProf.Visible = false;
            }
            else
            {
                removerProf.Visible = true;
                prof_but.Visible = false;
                prof_box.Text = i.NIF_Professor.ToString();
            }
        }

        private void list_alunos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_alunos.SelectedIndex >= 0)
            {
                currentContact = list_alunos.SelectedIndex;
                ShowContact();
            }
        }
        public void ClearFields()
        {
            id_box.Text = "";
            data_box.Text = "";
            nome_box.Text = "";
            naipe_box.Text = "";
            prof_box.Text = "";
            tele_box.Text = "";
            
        }

        public void UnlockControls()
        {
            id_box.ReadOnly = false;
            data_box.ReadOnly = false;
            nome_box.ReadOnly = false;
            naipe_box.ReadOnly = false;
            prof_box.ReadOnly = false;
            tele_box.ReadOnly = false;
        }

        public void LockControls()
        {
            id_box.ReadOnly = true;
            data_box.ReadOnly = true;
            nome_box.ReadOnly = true;
            naipe_box.ReadOnly = true;
            prof_box.ReadOnly = true;
            tele_box.ReadOnly = true;
        }

        public void HideButtons()
        {
            UnlockControls();
            Add.Visible = false;
            Atualizar.Visible = false;
            Remover.Visible = false;
        }


        public void ShowButtons()
        {
            LockControls();
            Add.Visible = true;
            Atualizar.Visible = true;
            Remover.Visible = true;
        }

        private void Add_Click(object sender, EventArgs e)
        {
            prof_but.Visible = false;
            removerProf.Visible = false;
            adding = true;
            ClearFields();
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_alunos.Enabled = false;
            prof_box.Visible = false;
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                SaveAluno();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            list_alunos.Enabled = true;
            int idx = list_alunos.FindString(id_box.Text);
            list_alunos.SelectedIndex = idx;
            Alunos_Load(sender, e);
            ShowButtons();
            prof_box.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
        }

        private bool SaveAluno()
        {
            Aluno i = new Aluno();
            try
            {
                if (adding || prof_box.Text == "Nao tem")
                {
                    i.NIF = int.Parse(id_box.Text);
                    i.DataNasc = DateTime.Parse(data_box.Text);
                    i.Nome = nome_box.Text;
                    i.Telefone = int.Parse(tele_box.Text);
                    i.Naipe = naipe_box.Text;
                }
                else
                {
                    i.NIF = int.Parse(id_box.Text);
                    i.DataNasc = DateTime.Parse(data_box.Text);
                    i.Nome = nome_box.Text;
                    i.Telefone = int.Parse(tele_box.Text);
                    i.Naipe = naipe_box.Text;
                    i.NIF_Professor = int.Parse(prof_box.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            if (adding)
            {
                SubmitContact(i);
                list_alunos.Items.Add(i);
            }
            else
            {
                UpdateMusico(i);
                list_alunos.Items[currentContact] = i;
            }
            return true;
        }

        private void SubmitContact(Aluno C)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.InsertAluno ";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", C.NIF);
            cmd.Parameters.AddWithValue("@Nome", C.Nome);
            cmd.Parameters.AddWithValue("@Data", C.DataNasc);
            cmd.Parameters.AddWithValue("@Naipe", C.Naipe);
            cmd.Parameters.AddWithValue("@Telefone", C.Telefone);


            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
        }

        private void UpdateMusico(Aluno C)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();
            if(prof_box.Text == "Nao tem")
            {
                cmd.CommandText = "Banda.AlunoSemProfessor";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@NIF", C.NIF);
                cmd.Parameters.AddWithValue("@Nome", C.Nome);
                cmd.Parameters.AddWithValue("@Data", C.DataNasc);
                cmd.Parameters.AddWithValue("@Naipe", C.Naipe);
                cmd.Parameters.AddWithValue("@Telefone", C.Telefone);
            }
            else
            {
                cmd.CommandText = "Banda.AlunoComProfessor";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@NIF", C.NIF);
                cmd.Parameters.AddWithValue("@Nome", C.Nome);
                cmd.Parameters.AddWithValue("@Data", C.DataNasc);
                cmd.Parameters.AddWithValue("@Naipe", C.Naipe);
                cmd.Parameters.AddWithValue("@Telefone", C.Telefone);
                cmd.Parameters.AddWithValue("@NIF_Professor ", C.NIF_Professor);
            }
            
            cmd.Connection = cn;

            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                if (rows == 1)
                    MessageBox.Show("Update OK");
                else
                    MessageBox.Show("Update NOT Ok");
            }
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            prof_box.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            list_alunos.Enabled = true;
            if (list_alunos.Items.Count > 0)
            {
                currentContact = list_alunos.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }

        private void RemoveContact(int NIF)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.DeleteAluno";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", NIF);
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to delete contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            if (list_alunos.SelectedIndex > -1)
            {
                try
                {
                    RemoveContact(((Aluno)list_alunos.SelectedItem).NIF);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                list_alunos.Items.RemoveAt(list_alunos.SelectedIndex);
                if (currentContact == list_alunos.Items.Count)
                    currentContact = list_alunos.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more contacts");
                }
                else
                {
                    ShowContact();
                }
            }
        }

        private void Atualizar_Click(object sender, EventArgs e)
        {
            prof_but.Visible = false;
            removerProf.Visible = false;
            currentContact = list_alunos.SelectedIndex;
            if (currentContact <= 0)
            {
                //MessageBox.Show("Please select a contact to edit");
                currentContact = 1;
                //return;
            }
            prof_but.Visible = false;
            adding = false;
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_alunos.Enabled = false;
        }

        private void Remover_Click_1(object sender, EventArgs e)
        {
            if (list_alunos.SelectedIndex > -1)
            {
                try
                {
                    RemoveContact(((Aluno)list_alunos.SelectedItem).NIF);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                list_alunos.Items.RemoveAt(list_alunos.SelectedIndex);
                if (currentContact == list_alunos.Items.Count)
                    currentContact = list_alunos.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more contacts");
                }
                else
                {
                    ShowContact();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;
        }

        private void prof_but_Click(object sender, EventArgs e)
        {
            try
            {
                Atribuir_Prof ap = new Atribuir_Prof();
                ap.ShowDialog();
                nif_professor_selecionado = ap.GetNIF();
                Aluno a = new Aluno();
                a.NIF = int.Parse(id_box.Text);
                a.Nome = nome_box.Text;
                a.DataNasc = DateTime.Parse(data_box.Text);
                a.Naipe = naipe_box.Text;
                a.Telefone = int.Parse(tele_box.Text);
                a.NIF_Professor = nif_professor_selecionado;
                UpdateProfessor(a);
                Alunos_Load(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateProfessor(Aluno a)
        {
            if (!verifySGBDConnection())
                return;

            cn = DatabaseManager.GetConnection();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Banda.AlunoComProfessor";
                cmd.Parameters.Clear();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@NIF", a.NIF);
                cmd.Parameters.AddWithValue("@Nome", a.Nome);
                cmd.Parameters.AddWithValue("@Data", a.DataNasc);
                cmd.Parameters.AddWithValue("@Naipe", a.Naipe);
                cmd.Parameters.AddWithValue("@Telefone", a.Telefone);
                cmd.Parameters.AddWithValue("@NIF_Professor ", a.NIF_Professor);
                cmd.Connection = cn;
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Cancelar_Click_1(object sender, EventArgs e)
        {
            removerProf.Visible = true;
            tele_box.Visible = true;
            prof_box.Visible = true;
            nome_box.Visible = true;
            data_box.Visible = true;
            id_box.Visible = true;
            naipe_box.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            list_alunos.Enabled = true;
            if (list_alunos.Items.Count > 0)
            {
                currentContact = list_alunos.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }

        private void removerProf_Click(object sender, EventArgs e)
        {
            Aluno a = new Aluno();
            a.Nome = nome_box.Text;
            a.Telefone = int.Parse(tele_box.Text);
            a.Naipe = naipe_box.Text;
            a.NIF = int.Parse(id_box.Text);
            a.DataNasc = DateTime.Parse(data_box.Text);
            UpdateRemoveProfessor(a);
            removerProf.Visible = false;
            Alunos_Load(sender, e);

        }
        private void UpdateRemoveProfessor(Aluno a)
        {
            if (!verifySGBDConnection())
                return;

            cn = DatabaseManager.GetConnection();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Banda.AlunoComProfessor";
                cmd.Parameters.Clear();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@NIF", a.NIF);
                cmd.Parameters.AddWithValue("@Nome", a.Nome);
                cmd.Parameters.AddWithValue("@Data", a.DataNasc);
                cmd.Parameters.AddWithValue("@Naipe", a.Naipe);
                cmd.Parameters.AddWithValue("@Telefone", a.Telefone);
                cmd.Parameters.AddWithValue("@NIF_Professor ", DBNull.Value);
                cmd.Connection = cn;
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void farda_label_Click(object sender, EventArgs e)
        {

        }

        private void prof_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void tele_label_Click(object sender, EventArgs e)
        {

        }

        private void tele_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void data_label_Click(object sender, EventArgs e)
        {

        }

        private void data_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void naipe_label_Click(object sender, EventArgs e)
        {

        }

        private void naipe_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void nome_label_Click(object sender, EventArgs e)
        {

        }

        private void nome_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void nif_label_Click(object sender, EventArgs e)
        {

        }

        private void id_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void Musicos_label_Click(object sender, EventArgs e)
        {

        }
    }
}
