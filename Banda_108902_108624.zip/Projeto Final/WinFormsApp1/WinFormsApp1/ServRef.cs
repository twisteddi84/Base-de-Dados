﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    class ServRef
    {
        private int _id_servico;
        private float _preco_ref;
        private String _nome;
        private String _localidade;
        
        public String Nome
        {
            get { return _nome; }
            set { _nome = value; }
        }

        public String Localidade
        {
            get { return _localidade; }
            set { _localidade = value; }
        }
        public int ID_ser
        {
            get { return _id_servico; }
            set { _id_servico = value; }
        }

        public float Preco
        {
            get { return _preco_ref; }
            set { _preco_ref = value; }
        }
        public override String ToString()
        {
            return _id_servico.ToString() +"  " + _nome;
        }

        public ServRef() : base()
        {
        }

        public ServRef(int id_serv, float preco, String local, String nome) : base()
        {
            this._id_servico = id_serv;
            this._preco_ref = preco;
            this._localidade = local;
            this._nome = nome;

        }

        public ServRef(int id_serv, String local, String nome) : base()
        {
            this._id_servico = id_serv;
            this._localidade = local;
            this._nome = nome;

        }
    }
}
