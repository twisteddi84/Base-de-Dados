﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    class Servico
    {
        private int _id;
        private DateTime _dataserv;
        private TimeSpan _horaIn;
        private String _nome;
        private String _localidade;
        private int _preco;
        private double _pag_music;

		public int ID
		{
			get { return _id; }
			set { _id = value; }
		}

		public int Preco
		{
			get { return _preco; }
			set { _preco = value; }
		}

		public double Pagamento_per_musi
		{
			get { return _pag_music; }
			set { _pag_music = value; }
		}

		public String Nome
		{
			get { return _nome; }
			set
			{
				if (value == null | String.IsNullOrEmpty(value))
				{
					throw new Exception(" field can’t be empty");
					return;
				}
				_nome = value;
			}
		}

		public String Localidade
		{
			get { return _localidade; }
			set { _localidade = value; }
		}

		public DateTime DataServico
		{
			get { return _dataserv; }
			set { _dataserv = value; }
		}
		public TimeSpan HoraInicio
		{
			get { return _horaIn; }
			set { _horaIn = value; }
		}
		public override String ToString()
		{
			return _id + " " + _nome;
		}

		public Servico() : base()
		{
		}

		public Servico(int ID, DateTime data_servico, TimeSpan horaIn, String nome, String localidade, int preco, double pagperMusic) : base()
		{
			this._id = ID;
			this._dataserv = data_servico;
			this._nome = nome;
			this._horaIn = horaIn;
			this._localidade = localidade;
			this._preco = preco;
			this._pag_music = pagperMusic;
		}

		public Servico(DateTime data_servico, TimeSpan horaIn, String nome, String localidade, int preco, double pagperMusic) : base()
		{
			
			this._dataserv = data_servico;
			this._nome = nome;
			this._horaIn = horaIn;
			this._localidade = localidade;
			this._preco = preco;
			this._pag_music = pagperMusic;
		}


	}
}
