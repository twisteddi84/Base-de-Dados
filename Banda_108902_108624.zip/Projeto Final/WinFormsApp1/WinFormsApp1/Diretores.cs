﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Diretores : Form
    {
        private SqlConnection cn;
        private int currentContact;
        private bool adding;
        public Diretores()
        {
            InitializeComponent();
        }
        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }

        private void Diretores_Load(object sender, EventArgs e)
        {
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            button2.Visible = true;
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Direcao", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            list_diretores.Items.Clear();

            while (reader.Read())
            {
                Diretor i = new Diretor();
                i.NIF = (int)reader["NIF"];
                i.DataNasc = (DateTime)reader["data_de_nascimento"];
                i.Nome = reader["nome"].ToString();
                i.Cargo = reader["cargo"].ToString();
                i.Telefone = (int)reader["telefone"];
                i.Email = reader["email"].ToString();
               

                list_diretores.Items.Add(i);
            }

            reader.Close();

            cn.Close();


            currentContact = 0;
            ShowContact();
        }

        public void ShowContact()
        {
            if (list_diretores.Items.Count == 0 | currentContact < 0)
                return;
            Diretor i = new Diretor();
            i = (Diretor)list_diretores.Items[currentContact];
            id_box.Text = i.NIF.ToString();
            data_box.Text = i.DataNasc.ToString("yyyy-MM-dd");
            nome_box.Text = i.Nome;
            tele_box.Text = i.Telefone.ToString();
            email_box.Text = i.Email;
            cargo_box.Text = i.Cargo;
        }

        private void list_diretores_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_diretores.SelectedIndex >= 0)
            {
                currentContact = list_diretores.SelectedIndex;
                ShowContact();
            }
        }
        public void ClearFields()
        {
            id_box.Text = "";
            data_box.Text = "";
            nome_box.Text = "";
            email_box.Text = "";
            tele_box.Text = "";
            cargo_box.Text = "";

        }

        public void UnlockControls()
        {
            id_box.ReadOnly = false;
            data_box.ReadOnly = false;
            nome_box.ReadOnly = false;
            email_box.ReadOnly = false;
            cargo_box.ReadOnly = false;
            tele_box.ReadOnly = false;
        }

        public void LockControls()
        {
            id_box.ReadOnly = true;
            data_box.ReadOnly = true;
            nome_box.ReadOnly = true;
            email_box.ReadOnly = true;
            cargo_box.ReadOnly = true;
            tele_box.ReadOnly = true;
        }

        public void HideButtons()
        {
            UnlockControls();
            Add.Visible = false;
            Atualizar.Visible = false;
            Remover.Visible = false;
        }


        public void ShowButtons()
        {
            LockControls();
            Add.Visible = true;
            Atualizar.Visible = true;
            Remover.Visible = true;
        }
        private void Add_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            adding = true;
            ClearFields();
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_diretores.Enabled = false;
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                SaveDiretor();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            list_diretores.Enabled = true;
            int idx = list_diretores.FindString(id_box.Text);
            list_diretores.SelectedIndex = idx;
            
            Diretores_Load(sender, e);
            ShowButtons();
            Confirmar.Visible = false;
            Cancelar.Visible = false;
        }

        private bool SaveDiretor()
        {
            Diretor i = new Diretor();
            try
            {
        
                i.NIF = int.Parse(id_box.Text);
                i.DataNasc = DateTime.Parse(data_box.Text);
                i.Nome = nome_box.Text;
                i.Telefone = int.Parse(tele_box.Text);
                i.Email = email_box.Text;
                i.Cargo = cargo_box.Text;
                
             
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            if (adding)
            {
                SubmitContact(i);
                list_diretores.Items.Add(i);
            }
            else
            {
                
                UpdateMusico(i);
                list_diretores.Items[currentContact] = i;
            }
            return true;
        }

        private void SubmitContact(Diretor C)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.InsertDirecao";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", C.NIF);
            cmd.Parameters.AddWithValue("@Nome", C.Nome);
            cmd.Parameters.AddWithValue("@Data", C.DataNasc);
            cmd.Parameters.AddWithValue("@Email", C.Email);
            cmd.Parameters.AddWithValue("@Telefone", C.Telefone);
            cmd.Parameters.AddWithValue("@Cargo", C.Cargo);

            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
        }

        private void UpdateMusico(Diretor C)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Banda.UpdateDirecao";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", C.NIF);
            cmd.Parameters.AddWithValue("@Nome", C.Nome);
            cmd.Parameters.AddWithValue("@Data", C.DataNasc);
            cmd.Parameters.AddWithValue("@Email", C.Email);
            cmd.Parameters.AddWithValue("@Telefone", C.Telefone);
            cmd.Parameters.AddWithValue("@Cargo", C.Cargo);
            cmd.Connection = cn;

            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in the database.\nERROR MESSAGE:\n" + ex.Message);
            }
            finally
            {
                if (rows == 1)
                    MessageBox.Show("Update OK");
                else
                    MessageBox.Show("Update NOT Ok");
            }
        }


        private void Atualizar_Click(object sender, EventArgs e)
        {
            currentContact = list_diretores.SelectedIndex;
            if (currentContact <= 0)
            {
                //MessageBox.Show("Please select a contact to edit");
                currentContact = 1;
                //return;
            }
            button2.Visible = false;
            adding = false;
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_diretores.Enabled = false;
        }

        private void RemoveContact(int NIF)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.DeleteDirecao";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", NIF);
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to delete contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            if (list_diretores.SelectedIndex > -1)
            {
                try
                {
                    RemoveContact(((Diretor)list_diretores.SelectedItem).NIF);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                list_diretores.Items.RemoveAt(list_diretores.SelectedIndex);
                if (currentContact == list_diretores.Items.Count)
                    currentContact = list_diretores.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more contacts");
                }
                else
                {
                    ShowContact();
                }
            }
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            tele_box.Visible = true;
            nome_box.Visible = true;
            data_box.Visible = true;
            id_box.Visible = true;
            email_box.Visible = true;
            cargo_box.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            button2.Visible = true;
            list_diretores.Enabled = true;
            if (list_diretores.Items.Count > 0)
            {
                currentContact = list_diretores.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Servicos_por_Diretor spd = new Servicos_por_Diretor(int.Parse(id_box.Text));
            spd.Show();
        }
    }
}
