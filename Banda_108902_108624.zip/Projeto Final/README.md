Projeto Final Banda Filarmónica de Diogo Almeida 108902 e Tomás Matos 108624


--Conectar Base de dados--
Deve ser alterado o username e a password no Forms DatabaseManager.cs.


--Dentro da aplicação--
Para dar login dentro da aplicação terá de utilizar um membro da direção para ter 
acesso colocado o nome em letras minúsculas separados por "_". 

Exemplo:
nome: carlos_pascoal password:172834539
nome: susana_rosario password:135421356

Banda.Direcao:
(172834539,'Carlos Pascoal','1968-10-11',912352741,'carlospascoal@gmail.com','Presidente'),
(135421356,'Susana Rosário','1973-08-30',914937544,'susanaprosario@hotmail.com','Vice-Presidente'),
(123554431,'João Silva','1970-05-12',912234233,'joao12@hotmail.com','Tesoureiro'),
(958278345,'Ana Grave','1990-01-01',912492042,'anagrave01@gmail.com','Orgao Fiscal'),
(864732634,'Rui Silva','1995-02-02',965493275,'ruizinho@gmail.com','Assembleia Geral');