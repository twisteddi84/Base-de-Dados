﻿
namespace WinFormsApp1
{
    partial class InputBoxPreco
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.preco_box = new System.Windows.Forms.TextBox();
            this.preco_label = new System.Windows.Forms.Label();
            this.nif_Ref = new System.Windows.Forms.Label();
            this.OK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // preco_box
            // 
            this.preco_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.preco_box.Location = new System.Drawing.Point(243, 92);
            this.preco_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.preco_box.Name = "preco_box";
            this.preco_box.Size = new System.Drawing.Size(163, 28);
            this.preco_box.TabIndex = 46;
            this.preco_box.TextChanged += new System.EventHandler(this.pag_musi_box_TextChanged);
            // 
            // preco_label
            // 
            this.preco_label.AutoSize = true;
            this.preco_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.preco_label.Location = new System.Drawing.Point(29, 92);
            this.preco_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.preco_label.Name = "preco_label";
            this.preco_label.Size = new System.Drawing.Size(206, 24);
            this.preco_label.TabIndex = 47;
            this.preco_label.Text = "VALOR COBRADO:";
            // 
            // nif_Ref
            // 
            this.nif_Ref.AutoSize = true;
            this.nif_Ref.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nif_Ref.Location = new System.Drawing.Point(160, 29);
            this.nif_Ref.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nif_Ref.Name = "nif_Ref";
            this.nif_Ref.Size = new System.Drawing.Size(108, 24);
            this.nif_Ref.TabIndex = 48;
            this.nif_Ref.Text = "nif_ref";
            // 
            // OK
            // 
            this.OK.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OK.Location = new System.Drawing.Point(182, 185);
            this.OK.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(86, 36);
            this.OK.TabIndex = 49;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // InputBoxPreco
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(445, 269);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.nif_Ref);
            this.Controls.Add(this.preco_label);
            this.Controls.Add(this.preco_box);
            this.Name = "InputBoxPreco";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InputBoxPreco";
            this.Load += new System.EventHandler(this.InputBoxPreco_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox preco_box;
        private System.Windows.Forms.Label preco_label;
        private System.Windows.Forms.Label nif_Ref;
        private System.Windows.Forms.Button OK;
    }
}