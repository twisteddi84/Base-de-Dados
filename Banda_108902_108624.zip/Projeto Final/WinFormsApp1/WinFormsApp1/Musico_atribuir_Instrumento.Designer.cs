﻿
namespace WinFormsApp1
{
    partial class Musico_atribuir_Instrumento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancelar = new System.Windows.Forms.Button();
            this.Confirmar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.farda_label = new System.Windows.Forms.Label();
            this.farda_box = new System.Windows.Forms.TextBox();
            this.tele_label = new System.Windows.Forms.Label();
            this.tele_box = new System.Windows.Forms.TextBox();
            this.data_label = new System.Windows.Forms.Label();
            this.data_box = new System.Windows.Forms.TextBox();
            this.naipe_label = new System.Windows.Forms.Label();
            this.naipe_box = new System.Windows.Forms.TextBox();
            this.nome_label = new System.Windows.Forms.Label();
            this.nome_box = new System.Windows.Forms.TextBox();
            this.nif_label = new System.Windows.Forms.Label();
            this.id_box = new System.Windows.Forms.TextBox();
            this.Musicos_label = new System.Windows.Forms.Label();
            this.list_musicos = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Cancelar
            // 
            this.Cancelar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cancelar.Location = new System.Drawing.Point(649, 405);
            this.Cancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(128, 40);
            this.Cancelar.TabIndex = 41;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // Confirmar
            // 
            this.Confirmar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Confirmar.Location = new System.Drawing.Point(449, 405);
            this.Confirmar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Confirmar.Name = "Confirmar";
            this.Confirmar.Size = new System.Drawing.Size(128, 40);
            this.Confirmar.TabIndex = 40;
            this.Confirmar.Text = "Confirmar";
            this.Confirmar.UseVisualStyleBackColor = true;
            this.Confirmar.Click += new System.EventHandler(this.Confirmar_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(859, 33);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 40);
            this.button1.TabIndex = 36;
            this.button1.Text = "HOME";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // farda_label
            // 
            this.farda_label.AutoSize = true;
            this.farda_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.farda_label.Location = new System.Drawing.Point(307, 344);
            this.farda_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.farda_label.Name = "farda_label";
            this.farda_label.Size = new System.Drawing.Size(136, 24);
            this.farda_label.TabIndex = 35;
            this.farda_label.Text = "FARDA ID:";
            // 
            // farda_box
            // 
            this.farda_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.farda_box.Location = new System.Drawing.Point(449, 341);
            this.farda_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.farda_box.Name = "farda_box";
            this.farda_box.ReadOnly = true;
            this.farda_box.Size = new System.Drawing.Size(116, 28);
            this.farda_box.TabIndex = 34;
            // 
            // tele_label
            // 
            this.tele_label.AutoSize = true;
            this.tele_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_label.Location = new System.Drawing.Point(589, 344);
            this.tele_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tele_label.Name = "tele_label";
            this.tele_label.Size = new System.Drawing.Size(136, 24);
            this.tele_label.TabIndex = 33;
            this.tele_label.Text = "TELEFONE:";
            // 
            // tele_box
            // 
            this.tele_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_box.Location = new System.Drawing.Point(731, 341);
            this.tele_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.tele_box.Name = "tele_box";
            this.tele_box.ReadOnly = true;
            this.tele_box.Size = new System.Drawing.Size(194, 28);
            this.tele_box.TabIndex = 32;
            // 
            // data_label
            // 
            this.data_label.AutoSize = true;
            this.data_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_label.Location = new System.Drawing.Point(307, 218);
            this.data_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.data_label.Name = "data_label";
            this.data_label.Size = new System.Drawing.Size(234, 24);
            this.data_label.TabIndex = 31;
            this.data_label.Text = "DATA NASCIMENTO:";
            // 
            // data_box
            // 
            this.data_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_box.Location = new System.Drawing.Point(547, 214);
            this.data_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.data_box.Name = "data_box";
            this.data_box.ReadOnly = true;
            this.data_box.Size = new System.Drawing.Size(178, 28);
            this.data_box.TabIndex = 30;
            // 
            // naipe_label
            // 
            this.naipe_label.AutoSize = true;
            this.naipe_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.naipe_label.Location = new System.Drawing.Point(307, 283);
            this.naipe_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.naipe_label.Name = "naipe_label";
            this.naipe_label.Size = new System.Drawing.Size(94, 24);
            this.naipe_label.TabIndex = 29;
            this.naipe_label.Text = "NAIPE:";
            // 
            // naipe_box
            // 
            this.naipe_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.naipe_box.Location = new System.Drawing.Point(407, 280);
            this.naipe_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.naipe_box.Name = "naipe_box";
            this.naipe_box.ReadOnly = true;
            this.naipe_box.Size = new System.Drawing.Size(238, 28);
            this.naipe_box.TabIndex = 28;
            // 
            // nome_label
            // 
            this.nome_label.AutoSize = true;
            this.nome_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_label.Location = new System.Drawing.Point(565, 146);
            this.nome_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nome_label.Name = "nome_label";
            this.nome_label.Size = new System.Drawing.Size(80, 24);
            this.nome_label.TabIndex = 27;
            this.nome_label.Text = "NOME:";
            // 
            // nome_box
            // 
            this.nome_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_box.Location = new System.Drawing.Point(649, 146);
            this.nome_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.nome_box.Name = "nome_box";
            this.nome_box.ReadOnly = true;
            this.nome_box.Size = new System.Drawing.Size(268, 28);
            this.nome_box.TabIndex = 26;
            // 
            // nif_label
            // 
            this.nif_label.AutoSize = true;
            this.nif_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nif_label.Location = new System.Drawing.Point(307, 146);
            this.nif_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nif_label.Name = "nif_label";
            this.nif_label.Size = new System.Drawing.Size(66, 24);
            this.nif_label.TabIndex = 25;
            this.nif_label.Text = "NIF:";
            // 
            // id_box
            // 
            this.id_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_box.Location = new System.Drawing.Point(379, 146);
            this.id_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.id_box.Name = "id_box";
            this.id_box.ReadOnly = true;
            this.id_box.Size = new System.Drawing.Size(162, 28);
            this.id_box.TabIndex = 24;
            // 
            // Musicos_label
            // 
            this.Musicos_label.AutoSize = true;
            this.Musicos_label.Font = new System.Drawing.Font("OCR A Extended", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Musicos_label.Location = new System.Drawing.Point(71, 17);
            this.Musicos_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Musicos_label.Name = "Musicos_label";
            this.Musicos_label.Size = new System.Drawing.Size(132, 29);
            this.Musicos_label.TabIndex = 23;
            this.Musicos_label.Text = "Músicos";
            // 
            // list_musicos
            // 
            this.list_musicos.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_musicos.FormattingEnabled = true;
            this.list_musicos.ItemHeight = 17;
            this.list_musicos.Location = new System.Drawing.Point(2, 50);
            this.list_musicos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.list_musicos.Name = "list_musicos";
            this.list_musicos.Size = new System.Drawing.Size(298, 480);
            this.list_musicos.TabIndex = 22;
            this.list_musicos.SelectedIndexChanged += new System.EventHandler(this.list_musicos_SelectedIndexChanged);
            // 
            // Musico_atribuir_Instrumento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 624);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.Confirmar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.farda_label);
            this.Controls.Add(this.farda_box);
            this.Controls.Add(this.tele_label);
            this.Controls.Add(this.tele_box);
            this.Controls.Add(this.data_label);
            this.Controls.Add(this.data_box);
            this.Controls.Add(this.naipe_label);
            this.Controls.Add(this.naipe_box);
            this.Controls.Add(this.nome_label);
            this.Controls.Add(this.nome_box);
            this.Controls.Add(this.nif_label);
            this.Controls.Add(this.id_box);
            this.Controls.Add(this.Musicos_label);
            this.Controls.Add(this.list_musicos);
            this.Name = "Musico_atribuir_Instrumento";
            this.Text = "Musico_atribuir_Instrumento";
            this.Load += new System.EventHandler(this.Musico_atribuir_Instrumento_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button Confirmar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label farda_label;
        private System.Windows.Forms.TextBox farda_box;
        private System.Windows.Forms.Label tele_label;
        private System.Windows.Forms.TextBox tele_box;
        private System.Windows.Forms.Label data_label;
        private System.Windows.Forms.TextBox data_box;
        private System.Windows.Forms.Label naipe_label;
        private System.Windows.Forms.TextBox naipe_box;
        private System.Windows.Forms.Label nome_label;
        private System.Windows.Forms.TextBox nome_box;
        private System.Windows.Forms.Label nif_label;
        private System.Windows.Forms.TextBox id_box;
        private System.Windows.Forms.Label Musicos_label;
        private System.Windows.Forms.ListBox list_musicos;
    }
}