﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Select_NIF_Emissor : Form
    {
        private int NIF_emissor;
        private SqlConnection cn;
        public Select_NIF_Emissor()
        {
            InitializeComponent();
            checkedListBox1.ItemCheck += checkedListBox1_ItemCheck;
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Cancelar a seleção de outros itens
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                if (i != e.Index)
                {
                    checkedListBox1.SetItemChecked(i, false);
                }
            }
        }

        private void Select_NIF_Emissor_Load(object sender, EventArgs e)
        {
            string query = "SELECT NIF,nome FROM Banda.Direcao";

            cn = DatabaseManager.GetConnection();
            SqlCommand command = new SqlCommand(query, cn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                checkedListBox1.Items.Add(reader["NIF"].ToString() + "-" + reader["nome"].ToString());
            }
            reader.Close();
            cn.Close();
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            // Armazenar as checkboxes selecionadas na lista selectedTipos
            NIF_emissor = 0; // Limpar a lista antes de adicionar os itens selecionados

            foreach (var item in checkedListBox1.CheckedItems)
            {
                string nif = item.ToString().Split('-')[0].Trim();
                NIF_emissor = int.Parse(nif);
            }

            // Fechar o formulário SelectTipos
            this.Close();
        }

        public int GetSelectedNIF()
        {
            return NIF_emissor;
        }
    }
}
