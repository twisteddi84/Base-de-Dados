﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Fardas : Form
    {
        private SqlConnection cn;
        private int currentContact;
        private bool adding;

        public Fardas()
        {
            InitializeComponent();
        }
        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }

        private void Fardas_Load(object sender, EventArgs e)
        {
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Farda ", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            list_fardas.Items.Clear();

            while (reader.Read())
            {
                Farda i = new Farda();
                i.ID = reader["id"].ToString();
                i.Estado = reader["estado"].ToString();
                i.Tamanho = reader["tamanho"].ToString();
                list_fardas.Items.Add(i);
            }
            reader.Close();
            cn.Close();


            currentContact = 0;
            ShowContact();

        }

        public void ShowContact()
        {
            if (list_fardas.Items.Count == 0 | currentContact < 0)
                return;
            Farda i = new Farda();
            i = (Farda)list_fardas.Items[currentContact];
            id_box.Text = i.ID.ToString();
            estado_box.Text = i.Estado;
            tamanho_box.Text = i.Tamanho;
        }

        private void list_fardas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_fardas.SelectedIndex >= 0)
            {
                currentContact = list_fardas.SelectedIndex;
                ShowContact();
            }
        }

        private void id_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFarda();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            list_fardas.Enabled = true;
            int idx = list_fardas.FindString(id_box.Text);
            list_fardas.SelectedIndex = idx;
            ShowButtons();
            Fardas_Load(sender, e);
            Confirmar.Visible = false;
            Cancelar.Visible = false;
        }

        public void ClearFields()
        {
            id_box.Text = "";
            estado_box.Text = "";
            tamanho_box.Text = "";
           
        }

        public void UnlockControls()
        {
            estado_box.ReadOnly = false;
            tamanho_box.ReadOnly = false;
            
        }

        public void LockControls()
        {
            id_box.ReadOnly = true;
            estado_box.ReadOnly = true;
            tamanho_box.ReadOnly = true;
    
        }

        public void HideButtons()
        {
            UnlockControls();
            Add.Visible = false;
            Atualizar.Visible = false;
            Remover.Visible = false;
        }


        public void ShowButtons()
        {
            LockControls();
            Add.Visible = true;
            Atualizar.Visible = true;
            Remover.Visible = true;
        }
        private void UpdateFarda(Farda C)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.UpdateFarda";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ID", C.ID);
            cmd.Parameters.AddWithValue("@Tamanho", C.Tamanho);
            cmd.Parameters.AddWithValue("@Estado", C.Estado);
            cmd.Connection = cn;

            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                if (rows == 1)
                    MessageBox.Show("Update OK");
                else
                    MessageBox.Show("Update NOT Ok");
            }
        }

        private void SubmitContact(Farda C)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.InsertFarda ";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            //cmd.Parameters.AddWithValue("@id", C.ID);
            cmd.Parameters.AddWithValue("@estado", C.Estado);
            cmd.Parameters.AddWithValue("@tamanho", C.Tamanho);
       
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
        }
        private bool SaveFarda()
        {
            Farda i = new Farda();
            try
            {
                i.ID =id_box.Text;
                i.Estado = estado_box.Text;
                i.Tamanho = tamanho_box.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            if (adding)
            {
                SubmitContact(i);
                list_fardas.Items.Add(i);
            }
            else
            {
                UpdateFarda(i);
                list_fardas.Items[currentContact] = i;
            }
            return true;
        }

        private void Add_Click(object sender, EventArgs e)
        {
            adding = true;
            ClearFields();
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_fardas.Enabled = false;
        }

        private void Atualizar_Click(object sender, EventArgs e)
        {
            currentContact = list_fardas.SelectedIndex;
            if (currentContact <= 0)
            {
                //MessageBox.Show("Please select a contact to edit");
                currentContact = 1;
                //return;
            }
            adding = false;
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_fardas.Enabled = false;
        }

        private void RemoveContact(String ID)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.DeleteFarda";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to delete contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            if (list_fardas.SelectedIndex > -1)
            {
                try
                {
                    RemoveContact(((Farda)list_fardas.SelectedItem).ID);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                list_fardas.Items.RemoveAt(list_fardas.SelectedIndex);
                if (currentContact == list_fardas.Items.Count)
                    currentContact = list_fardas.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more contacts");
                }
                else
                {
                    ShowContact();
                }
            }
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            list_fardas.Enabled = true;
            if (list_fardas.Items.Count > 0)
            {
                currentContact = list_fardas.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }
    }
}
