﻿
namespace WinFormsApp1
{
    partial class Instrumentos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.textBoxDataCompra = new System.Windows.Forms.TextBox();
            this.Data = new System.Windows.Forms.Label();
            this.textBoxModelo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxTipoInstrumento = new System.Windows.Forms.TextBox();
            this.tipo_instrumento = new System.Windows.Forms.Label();
            this.aluno_musico = new System.Windows.Forms.Label();
            this.Nome = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.NIF = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Remover = new System.Windows.Forms.Button();
            this.Atualizar = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Cancelar = new System.Windows.Forms.Button();
            this.Confirmar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 17;
            this.listBox1.Location = new System.Drawing.Point(1, 45);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.ScrollAlwaysVisible = true;
            this.listBox1.Size = new System.Drawing.Size(255, 480);
            this.listBox1.TabIndex = 0;
            this.listBox1.UseTabStops = false;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("OCR A Extended", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(21, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Instrumentos";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(306, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "ID:";
            // 
            // textBoxID
            // 
            this.textBoxID.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBoxID.Location = new System.Drawing.Point(364, 141);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.ReadOnly = true;
            this.textBoxID.Size = new System.Drawing.Size(76, 28);
            this.textBoxID.TabIndex = 3;
            // 
            // textBoxDataCompra
            // 
            this.textBoxDataCompra.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBoxDataCompra.Location = new System.Drawing.Point(723, 142);
            this.textBoxDataCompra.Name = "textBoxDataCompra";
            this.textBoxDataCompra.ReadOnly = true;
            this.textBoxDataCompra.Size = new System.Drawing.Size(193, 28);
            this.textBoxDataCompra.TabIndex = 5;
            // 
            // Data
            // 
            this.Data.AutoSize = true;
            this.Data.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Data.Location = new System.Drawing.Point(497, 141);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(220, 24);
            this.Data.TabIndex = 4;
            this.Data.Text = "Data de Compra:";
            // 
            // textBoxModelo
            // 
            this.textBoxModelo.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBoxModelo.Location = new System.Drawing.Point(424, 308);
            this.textBoxModelo.Name = "textBoxModelo";
            this.textBoxModelo.ReadOnly = true;
            this.textBoxModelo.Size = new System.Drawing.Size(344, 28);
            this.textBoxModelo.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(310, 308);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 24);
            this.label4.TabIndex = 6;
            this.label4.Text = "Modelo:";
            // 
            // textBoxTipoInstrumento
            // 
            this.textBoxTipoInstrumento.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBoxTipoInstrumento.Location = new System.Drawing.Point(606, 223);
            this.textBoxTipoInstrumento.Name = "textBoxTipoInstrumento";
            this.textBoxTipoInstrumento.ReadOnly = true;
            this.textBoxTipoInstrumento.Size = new System.Drawing.Size(310, 28);
            this.textBoxTipoInstrumento.TabIndex = 9;
            this.textBoxTipoInstrumento.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // tipo_instrumento
            // 
            this.tipo_instrumento.AutoSize = true;
            this.tipo_instrumento.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tipo_instrumento.Location = new System.Drawing.Point(310, 223);
            this.tipo_instrumento.Name = "tipo_instrumento";
            this.tipo_instrumento.Size = new System.Drawing.Size(290, 24);
            this.tipo_instrumento.TabIndex = 8;
            this.tipo_instrumento.Text = "Tipo de Instrumento:";
            this.tipo_instrumento.Click += new System.EventHandler(this.label3_Click);
            // 
            // aluno_musico
            // 
            this.aluno_musico.AutoSize = true;
            this.aluno_musico.Font = new System.Drawing.Font("OCR A Extended", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.aluno_musico.Location = new System.Drawing.Point(546, 376);
            this.aluno_musico.Name = "aluno_musico";
            this.aluno_musico.Size = new System.Drawing.Size(117, 25);
            this.aluno_musico.TabIndex = 10;
            this.aluno_musico.Text = "Músico:";
            this.aluno_musico.Click += new System.EventHandler(this.aluno_musico_Click);
            // 
            // Nome
            // 
            this.Nome.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Nome.Location = new System.Drawing.Point(536, 479);
            this.Nome.Name = "Nome";
            this.Nome.ReadOnly = true;
            this.Nome.Size = new System.Drawing.Size(350, 28);
            this.Nome.TabIndex = 14;
            this.Nome.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(310, 482);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 24);
            this.label3.TabIndex = 13;
            this.label3.Text = "Nome do Músico:";
            // 
            // NIF
            // 
            this.NIF.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.NIF.Location = new System.Drawing.Point(536, 436);
            this.NIF.Name = "NIF";
            this.NIF.ReadOnly = true;
            this.NIF.Size = new System.Drawing.Size(350, 28);
            this.NIF.TabIndex = 12;
            this.NIF.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(310, 436);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(206, 24);
            this.label5.TabIndex = 11;
            this.label5.Text = "NIF do Músico:";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(857, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 40);
            this.button1.TabIndex = 15;
            this.button1.Text = "HOME";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Remover
            // 
            this.Remover.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Remover.Location = new System.Drawing.Point(307, 562);
            this.Remover.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Remover.Name = "Remover";
            this.Remover.Size = new System.Drawing.Size(128, 40);
            this.Remover.TabIndex = 22;
            this.Remover.Text = "Remover";
            this.Remover.UseVisualStyleBackColor = true;
            this.Remover.Click += new System.EventHandler(this.Remover_Click);
            // 
            // Atualizar
            // 
            this.Atualizar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Atualizar.Location = new System.Drawing.Point(160, 562);
            this.Atualizar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Atualizar.Name = "Atualizar";
            this.Atualizar.Size = new System.Drawing.Size(128, 40);
            this.Atualizar.TabIndex = 21;
            this.Atualizar.Text = "Atualizar";
            this.Atualizar.UseVisualStyleBackColor = true;
            this.Atualizar.Click += new System.EventHandler(this.Atualizar_Click);
            // 
            // Add
            // 
            this.Add.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Add.Location = new System.Drawing.Point(13, 562);
            this.Add.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(128, 40);
            this.Add.TabIndex = 20;
            this.Add.Text = "Adicionar";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Cancelar
            // 
            this.Cancelar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cancelar.Location = new System.Drawing.Point(693, 361);
            this.Cancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(128, 40);
            this.Cancelar.TabIndex = 24;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // Confirmar
            // 
            this.Confirmar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Confirmar.Location = new System.Drawing.Point(388, 361);
            this.Confirmar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Confirmar.Name = "Confirmar";
            this.Confirmar.Size = new System.Drawing.Size(128, 40);
            this.Confirmar.TabIndex = 23;
            this.Confirmar.Text = "Confirmar";
            this.Confirmar.UseVisualStyleBackColor = true;
            this.Confirmar.Click += new System.EventHandler(this.Confirmar_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(497, 445);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(163, 51);
            this.button2.TabIndex = 25;
            this.button2.Text = "Atribuir a músico";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button3.Location = new System.Drawing.Point(753, 445);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(163, 51);
            this.button3.TabIndex = 26;
            this.button3.Text = "Atribuir a Aluno";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button4.Location = new System.Drawing.Point(788, 530);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(128, 58);
            this.button4.TabIndex = 27;
            this.button4.Text = "Remover Músico";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Instrumentos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 624);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.Confirmar);
            this.Controls.Add(this.Remover);
            this.Controls.Add(this.Atualizar);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Nome);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.NIF);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.aluno_musico);
            this.Controls.Add(this.textBoxTipoInstrumento);
            this.Controls.Add(this.tipo_instrumento);
            this.Controls.Add(this.textBoxModelo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxDataCompra);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Name = "Instrumentos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Instrumentos";
            this.Load += new System.EventHandler(this.Instrumentos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.TextBox textBoxDataCompra;
        private System.Windows.Forms.Label Data;
        private System.Windows.Forms.TextBox textBoxModelo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxTipoInstrumento;
        private System.Windows.Forms.Label tipo_instrumento;
        private System.Windows.Forms.Label aluno_musico;
        private System.Windows.Forms.TextBox Nome;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox NIF;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Remover;
        private System.Windows.Forms.Button Atualizar;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button Confirmar;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}