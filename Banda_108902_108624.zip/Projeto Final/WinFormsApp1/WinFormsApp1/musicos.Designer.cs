﻿
namespace WinFormsApp1
{
    partial class musicos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.list_musicos = new System.Windows.Forms.ListBox();
            this.Musicos_label = new System.Windows.Forms.Label();
            this.id_box = new System.Windows.Forms.TextBox();
            this.nif_label = new System.Windows.Forms.Label();
            this.nome_label = new System.Windows.Forms.Label();
            this.nome_box = new System.Windows.Forms.TextBox();
            this.naipe_label = new System.Windows.Forms.Label();
            this.naipe_box = new System.Windows.Forms.TextBox();
            this.data_label = new System.Windows.Forms.Label();
            this.data_box = new System.Windows.Forms.TextBox();
            this.tele_label = new System.Windows.Forms.Label();
            this.tele_box = new System.Windows.Forms.TextBox();
            this.farda_label = new System.Windows.Forms.Label();
            this.farda_box = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Atualizar = new System.Windows.Forms.Button();
            this.Remover = new System.Windows.Forms.Button();
            this.Confirmar = new System.Windows.Forms.Button();
            this.Cancelar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pesquisa_box = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.removerFardaBut = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // list_musicos
            // 
            this.list_musicos.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_musicos.FormattingEnabled = true;
            this.list_musicos.ItemHeight = 17;
            this.list_musicos.Location = new System.Drawing.Point(1, 45);
            this.list_musicos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.list_musicos.Name = "list_musicos";
            this.list_musicos.Size = new System.Drawing.Size(298, 463);
            this.list_musicos.TabIndex = 0;
            this.list_musicos.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // Musicos_label
            // 
            this.Musicos_label.AutoSize = true;
            this.Musicos_label.Font = new System.Drawing.Font("OCR A Extended", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Musicos_label.Location = new System.Drawing.Point(70, 12);
            this.Musicos_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Musicos_label.Name = "Musicos_label";
            this.Musicos_label.Size = new System.Drawing.Size(132, 29);
            this.Musicos_label.TabIndex = 1;
            this.Musicos_label.Text = "Músicos";
            this.Musicos_label.Click += new System.EventHandler(this.label1_Click);
            // 
            // id_box
            // 
            this.id_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_box.Location = new System.Drawing.Point(378, 141);
            this.id_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.id_box.Name = "id_box";
            this.id_box.ReadOnly = true;
            this.id_box.Size = new System.Drawing.Size(162, 28);
            this.id_box.TabIndex = 2;
            this.id_box.TextChanged += new System.EventHandler(this.id_box_TextChanged);
            // 
            // nif_label
            // 
            this.nif_label.AutoSize = true;
            this.nif_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nif_label.Location = new System.Drawing.Point(306, 141);
            this.nif_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nif_label.Name = "nif_label";
            this.nif_label.Size = new System.Drawing.Size(66, 24);
            this.nif_label.TabIndex = 3;
            this.nif_label.Text = "NIF:";
            this.nif_label.Click += new System.EventHandler(this.id_label_Click);
            // 
            // nome_label
            // 
            this.nome_label.AutoSize = true;
            this.nome_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_label.Location = new System.Drawing.Point(564, 141);
            this.nome_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nome_label.Name = "nome_label";
            this.nome_label.Size = new System.Drawing.Size(80, 24);
            this.nome_label.TabIndex = 5;
            this.nome_label.Text = "NOME:";
            this.nome_label.Click += new System.EventHandler(this.nome_label_Click);
            // 
            // nome_box
            // 
            this.nome_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_box.Location = new System.Drawing.Point(659, 141);
            this.nome_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.nome_box.Name = "nome_box";
            this.nome_box.ReadOnly = true;
            this.nome_box.Size = new System.Drawing.Size(268, 28);
            this.nome_box.TabIndex = 4;
            this.nome_box.TextChanged += new System.EventHandler(this.nome_box_TextChanged);
            // 
            // naipe_label
            // 
            this.naipe_label.AutoSize = true;
            this.naipe_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.naipe_label.Location = new System.Drawing.Point(306, 278);
            this.naipe_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.naipe_label.Name = "naipe_label";
            this.naipe_label.Size = new System.Drawing.Size(94, 24);
            this.naipe_label.TabIndex = 7;
            this.naipe_label.Text = "NAIPE:";
            this.naipe_label.Click += new System.EventHandler(this.naipe_label_Click);
            // 
            // naipe_box
            // 
            this.naipe_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.naipe_box.Location = new System.Drawing.Point(416, 278);
            this.naipe_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.naipe_box.Name = "naipe_box";
            this.naipe_box.ReadOnly = true;
            this.naipe_box.Size = new System.Drawing.Size(238, 28);
            this.naipe_box.TabIndex = 6;
            this.naipe_box.TextChanged += new System.EventHandler(this.naipe_box_TextChanged);
            // 
            // data_label
            // 
            this.data_label.AutoSize = true;
            this.data_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_label.Location = new System.Drawing.Point(306, 213);
            this.data_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.data_label.Name = "data_label";
            this.data_label.Size = new System.Drawing.Size(234, 24);
            this.data_label.TabIndex = 9;
            this.data_label.Text = "DATA NASCIMENTO:";
            this.data_label.Click += new System.EventHandler(this.data_label_Click);
            // 
            // data_box
            // 
            this.data_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_box.Location = new System.Drawing.Point(564, 210);
            this.data_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.data_box.Name = "data_box";
            this.data_box.ReadOnly = true;
            this.data_box.Size = new System.Drawing.Size(178, 28);
            this.data_box.TabIndex = 8;
            this.data_box.TextChanged += new System.EventHandler(this.data_box_TextChanged);
            // 
            // tele_label
            // 
            this.tele_label.AutoSize = true;
            this.tele_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_label.Location = new System.Drawing.Point(588, 339);
            this.tele_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tele_label.Name = "tele_label";
            this.tele_label.Size = new System.Drawing.Size(136, 24);
            this.tele_label.TabIndex = 11;
            this.tele_label.Text = "TELEFONE:";
            this.tele_label.Click += new System.EventHandler(this.tele_label_Click);
            // 
            // tele_box
            // 
            this.tele_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_box.Location = new System.Drawing.Point(730, 336);
            this.tele_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.tele_box.Name = "tele_box";
            this.tele_box.ReadOnly = true;
            this.tele_box.Size = new System.Drawing.Size(194, 28);
            this.tele_box.TabIndex = 10;
            this.tele_box.TextChanged += new System.EventHandler(this.tele_box_TextChanged);
            // 
            // farda_label
            // 
            this.farda_label.AutoSize = true;
            this.farda_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.farda_label.Location = new System.Drawing.Point(306, 339);
            this.farda_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.farda_label.Name = "farda_label";
            this.farda_label.Size = new System.Drawing.Size(136, 24);
            this.farda_label.TabIndex = 13;
            this.farda_label.Text = "FARDA ID:";
            this.farda_label.Click += new System.EventHandler(this.farda_label_Click);
            // 
            // farda_box
            // 
            this.farda_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.farda_box.Location = new System.Drawing.Point(460, 336);
            this.farda_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.farda_box.Name = "farda_box";
            this.farda_box.ReadOnly = true;
            this.farda_box.Size = new System.Drawing.Size(116, 28);
            this.farda_box.TabIndex = 12;
            this.farda_box.TextChanged += new System.EventHandler(this.farda_box_TextChanged);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(858, 28);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 40);
            this.button1.TabIndex = 16;
            this.button1.Text = "HOME";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Add
            // 
            this.Add.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Add.Location = new System.Drawing.Point(12, 560);
            this.Add.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(128, 40);
            this.Add.TabIndex = 17;
            this.Add.Text = "Adicionar";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Atualizar
            // 
            this.Atualizar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Atualizar.Location = new System.Drawing.Point(159, 560);
            this.Atualizar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Atualizar.Name = "Atualizar";
            this.Atualizar.Size = new System.Drawing.Size(128, 40);
            this.Atualizar.TabIndex = 18;
            this.Atualizar.Text = "Atualizar";
            this.Atualizar.UseVisualStyleBackColor = true;
            this.Atualizar.Click += new System.EventHandler(this.button2_Click);
            // 
            // Remover
            // 
            this.Remover.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Remover.Location = new System.Drawing.Point(306, 560);
            this.Remover.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Remover.Name = "Remover";
            this.Remover.Size = new System.Drawing.Size(128, 40);
            this.Remover.TabIndex = 19;
            this.Remover.Text = "Remover";
            this.Remover.UseVisualStyleBackColor = true;
            this.Remover.Click += new System.EventHandler(this.Remover_Click);
            // 
            // Confirmar
            // 
            this.Confirmar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Confirmar.Location = new System.Drawing.Point(448, 400);
            this.Confirmar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Confirmar.Name = "Confirmar";
            this.Confirmar.Size = new System.Drawing.Size(128, 40);
            this.Confirmar.TabIndex = 20;
            this.Confirmar.Text = "Confirmar";
            this.Confirmar.UseVisualStyleBackColor = true;
            this.Confirmar.Click += new System.EventHandler(this.Confirmar_Click);
            // 
            // Cancelar
            // 
            this.Cancelar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cancelar.Location = new System.Drawing.Point(648, 400);
            this.Cancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(128, 40);
            this.Cancelar.TabIndex = 21;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(378, 386);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(132, 54);
            this.button2.TabIndex = 22;
            this.button2.Text = "Atribuir Farda";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button3.Location = new System.Drawing.Point(588, 477);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(220, 77);
            this.button3.TabIndex = 23;
            this.button3.Text = "Ver Festas Realizadas";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // pesquisa_box
            // 
            this.pesquisa_box.Font = new System.Drawing.Font("OCR A Extended", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pesquisa_box.Location = new System.Drawing.Point(317, 45);
            this.pesquisa_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.pesquisa_box.Name = "pesquisa_box";
            this.pesquisa_box.PlaceholderText = "Pesquisar por";
            this.pesquisa_box.Size = new System.Drawing.Size(194, 22);
            this.pesquisa_box.TabIndex = 24;
            this.pesquisa_box.Tag = "";
            this.pesquisa_box.TextChanged += new System.EventHandler(this.pesquisa_box_TextChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("OCR A Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox1.Location = new System.Drawing.Point(517, 42);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(54, 17);
            this.checkBox1.TabIndex = 25;
            this.checkBox1.Text = "Nome";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("OCR A Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox2.Location = new System.Drawing.Point(517, 62);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(61, 17);
            this.checkBox2.TabIndex = 26;
            this.checkBox2.Text = "Naipe";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // removerFardaBut
            // 
            this.removerFardaBut.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.removerFardaBut.Location = new System.Drawing.Point(406, 386);
            this.removerFardaBut.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.removerFardaBut.Name = "removerFardaBut";
            this.removerFardaBut.Size = new System.Drawing.Size(132, 54);
            this.removerFardaBut.TabIndex = 27;
            this.removerFardaBut.Text = "Remover Farda";
            this.removerFardaBut.UseVisualStyleBackColor = true;
            this.removerFardaBut.Click += new System.EventHandler(this.removerFardaBut_Click);
            // 
            // musicos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 624);
            this.Controls.Add(this.removerFardaBut);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.pesquisa_box);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.Confirmar);
            this.Controls.Add(this.Remover);
            this.Controls.Add(this.Atualizar);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.farda_label);
            this.Controls.Add(this.farda_box);
            this.Controls.Add(this.tele_label);
            this.Controls.Add(this.tele_box);
            this.Controls.Add(this.data_label);
            this.Controls.Add(this.data_box);
            this.Controls.Add(this.naipe_label);
            this.Controls.Add(this.naipe_box);
            this.Controls.Add(this.nome_label);
            this.Controls.Add(this.nome_box);
            this.Controls.Add(this.nif_label);
            this.Controls.Add(this.id_box);
            this.Controls.Add(this.Musicos_label);
            this.Controls.Add(this.list_musicos);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Name = "musicos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "musicos";
            this.Load += new System.EventHandler(this.musicos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox list_musicos;
        private System.Windows.Forms.Label Musicos_label;
        private System.Windows.Forms.TextBox id_box;
        private System.Windows.Forms.Label nif_label;
        private System.Windows.Forms.Label nome_label;
        private System.Windows.Forms.TextBox nome_box;
        private System.Windows.Forms.Label naipe_label;
        private System.Windows.Forms.TextBox naipe_box;
        private System.Windows.Forms.Label data_label;
        private System.Windows.Forms.TextBox data_box;
        private System.Windows.Forms.Label tele_label;
        private System.Windows.Forms.TextBox tele_box;
        private System.Windows.Forms.Label farda_label;
        private System.Windows.Forms.TextBox farda_box;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Atualizar;
        private System.Windows.Forms.Button Remover;
        private System.Windows.Forms.Button Confirmar;
        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.TextBox pesquisa_box;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Button removerFardaBut;
    }
}