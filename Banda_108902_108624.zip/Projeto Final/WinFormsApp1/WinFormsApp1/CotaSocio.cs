﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    class CotaSocio
    {
        private int _Ano;
        private int _NIFEmissor;
        private DateTime? _DataPagamento;
        private int _valor;
        private String _nomeEmissor;

        public int Ano
        {
            get { return _Ano; }
            set { _Ano = value; }
        }
        public String nomeEmissor
        {
            get { return _nomeEmissor; }
            set { _nomeEmissor = value; }
        }

        public int Valor
        {
            get { return _valor; }
            set { _valor = value; }
        }

        public DateTime? DataPagamento
        {
            get { return _DataPagamento; }
            set { _DataPagamento = value; }
        }

        public int NIFEmissor
        {
            get { return _NIFEmissor; }
            set { _NIFEmissor = value; }
        }

        public override String ToString()
        {
            return "Ano-"+_Ano + " Valor-"+_valor+"€";
        }


        public CotaSocio()
        {
        }

        public CotaSocio(int Ano, int NIFEmissor, DateTime? DataPagamento, int valor,String nomeEmissor)
        {
            this._nomeEmissor = nomeEmissor;
            this._valor = valor;
            this._DataPagamento = DataPagamento;
            this._NIFEmissor = NIFEmissor;
            this._Ano = Ano;
        }

        public CotaSocio(int Ano)
        {
            this._Ano = Ano;
        }
    }
}
