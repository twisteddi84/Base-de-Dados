﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Cotas_do_Socio : Form
    {
        private int NIF_socio;
        private int currentContact;
        private SqlConnection cn;
        public Cotas_do_Socio(int NIF)
        {
            NIF_socio = NIF;
            InitializeComponent();
        }

        private void Voltar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = DatabaseManager.GetConnection();

            if (cn.State != ConnectionState.Open)
            {
                cn.Open();
                return true; // Return true when the connection is successfully opened
            }

            return true; // Return true when the connection state is already open
        }

        private void Cotas_do_Socio_Load(object sender, EventArgs e)
        {
            CotaSocio_label.Text = CotaSocio_label.Text + " " + NIF_socio.ToString();
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.GetCotaSocioInfo(@NIF)", cn);
            cmd.Parameters.AddWithValue("@NIF", NIF_socio);
            SqlDataReader reader = cmd.ExecuteReader();
            list_cotasSocio.Items.Clear();

            while (reader.Read())
            {
                CotaSocio cota = new CotaSocio();
                cota.Ano = (int)reader["Ano_Cota"];
                cota.DataPagamento = reader["Data_do_pagamento"] != DBNull.Value ? (DateTime)reader["Data_do_pagamento"] : (DateTime?)null;
                cota.NIFEmissor = (int)reader["NIF_do_emissor"];
                cota.Valor = (int)reader["valor"];
                cota.nomeEmissor = (String)reader["NomeDiretor"];

                // Você pode adicionar mais propriedades relevantes à classe CotaSocio, se necessário

                list_cotasSocio.Items.Add(cota);
            }

            currentContact = 0;
            reader.Close();
            ShowCotas();
        }

        public void ShowCotas()
        {
            if (list_cotasSocio.Items.Count == 0 | currentContact < 0)
                return;
            CotaSocio i = new CotaSocio();
            i = (CotaSocio)list_cotasSocio.Items[currentContact];
            ano_box.Text = i.Ano.ToString();
            valorBox1.Text = i.Valor.ToString();
            diretor_box.Text = i.nomeEmissor.ToString();
            data_box.Text = (i.DataPagamento != null) ? i.DataPagamento.Value.ToString("yyyy-MM-dd") + " Pago" : "Não Pagou";
            if(data_box.Text == "Não Pagou")
            {
                button1.Visible = true;
            }
            else
            {
                button1.Visible = false;
            }
        }


        private void tele_label_Click(object sender, EventArgs e)
        {

        }

        private void list_cotasSocio_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_cotasSocio.SelectedIndex >= 0)
            {
                currentContact = list_cotasSocio.SelectedIndex;
                ShowCotas();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            list_cotasSocio.Enabled = false;
            ano_box.ReadOnly = true;
            valorBox1.ReadOnly = true;
            diretor_box.ReadOnly = true;
            button1.Visible = false;
            try
            {
                CotaSocio i = new CotaSocio();
                try
                {
                    i.Ano = int.Parse(ano_box.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                UpdateCota(i,sender,e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            list_cotasSocio.Enabled = true;
            int idx = list_cotasSocio.FindString(ano_box.Text);
            list_cotasSocio.SelectedIndex = idx;

        }

        private void UpdateCota(CotaSocio C, object sender, EventArgs e)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Banda.UpdateCotaSocio";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", NIF_socio);
            cmd.Parameters.AddWithValue("@Ano", C.Ano);
            cmd.Parameters.AddWithValue("@Data", DateTime.Now);
            cmd.Connection = cn;

            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                if (rows == 1) {
                    MessageBox.Show("Update OK");
                    Cotas_do_Socio_Load(sender, e);
                }

                else { MessageBox.Show("Update NOT Ok"); }
            }
        }


        private void CotaSocio_label_Click(object sender, EventArgs e)
        {

        }
    }
}
