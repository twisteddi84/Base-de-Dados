﻿using System;

namespace WinFormsApp1
{
    class Cota
    {
        private int _valor;
        private int _dataAno;
        private int _NIFEmissor;

        public int Valor
        {
            get { return _valor; }
            set { _valor = value; }
        }

        public int DataAno
        {
            get { return _dataAno; }
            set { _dataAno = value; }
        }

        public int NIFEmissor
        {
            get { return _NIFEmissor; }
            set { _NIFEmissor = value; }
        }

        public override String ToString()
        {
            if (_NIFEmissor == 0)
            {
                return _dataAno + "   " + "Nao tem Emissor";
            }
            return _dataAno + "   " + _NIFEmissor;
        }

        public Cota()
        {
        }

        public Cota(int valor, int dataAno, int NIFEmissor)
        {
            _valor = valor;
            _dataAno = dataAno;
            _NIFEmissor = NIFEmissor;
        }

        public Cota(int valor, int dataAno)
        {
            _valor = valor;
            _dataAno = dataAno;
            _NIFEmissor = 0;
        }
    }
}
