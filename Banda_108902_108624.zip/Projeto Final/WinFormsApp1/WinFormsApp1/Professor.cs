﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
	class Professor
	{
		private int _NIF;
		private DateTime _dataNasc;
		private String _nome;
		private String _tipo_instrumento;
		private int _telefone;
		private float _ordenado;

		public int NIF
		{
			get { return _NIF; }
			set { _NIF = value; }
		}

		public int Telefone
		{
			get { return _telefone; }
			set { _telefone = value; }
		}

		public String Nome
		{
			get { return _nome; }
			set
			{
				if (value == null | String.IsNullOrEmpty(value))
				{
					throw new Exception(" field can’t be empty");
					return;
				}
				_nome = value;
			}
		}

		public String TipoInstru
		{
			get { return _tipo_instrumento; }
			set { _tipo_instrumento = value; }
		}

		public DateTime DataNasc
		{
			get { return _dataNasc; }
			set { _dataNasc = value; }
		}

		public float Ordenado
		{
			get { return _ordenado; }
			set { _ordenado = value; }
		}




		public override String ToString()
		{
			return _NIF + "   " + _nome;
		}

		public Professor() : base()
		{
		}

		public Professor(int NIF, DateTime datanasc, String nome, String tipo_intru, int telefone, float ordenado) : base()
		{
			this._NIF = NIF;
			this._dataNasc = datanasc;
			this._nome = nome;
			this._tipo_instrumento = tipo_intru;
			this._telefone = telefone;
			this._ordenado = ordenado;
		}
		
	}
}
