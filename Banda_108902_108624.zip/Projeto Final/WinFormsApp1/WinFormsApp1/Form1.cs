﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private SqlConnection cn;
        public static int nif_dir_loged = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private static string RemoveAccent(string txt)
        {
            byte[] bytes = System.Text.Encoding.GetEncoding("Cyrillic").GetBytes(txt); //Tailspin uses Cyrillic (ISO-8859-5); others use Hebraw (ISO-8859-8)
            return System.Text.Encoding.ASCII.GetString(bytes);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userName = textBox2.Text;
            cn = DatabaseManager.GetConnection();

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Direcao ", cn);
            SqlDataReader reader = cmd.ExecuteReader();

            bool TrueUser = false;

            while (reader.Read())
            {
                Diretor i = new Diretor();
                i.NIF = (int)reader["NIF"];
                i.Nome = reader["nome"].ToString();

                String user_name = "";
                if (i.Nome.Contains(" "))
                {
                    String[] name_splited = i.Nome.Split(" ");
                   
                    for (int j = 0; j < name_splited.Length; j++)
                    {
                        if (j == 0)
                        {
                            user_name += "" + name_splited[j];
                        }
                        else
                        {
                            user_name += "_" + name_splited[j];
                        }
                    }

                } else
                {
                    user_name = i.Nome;
                }
                user_name = RemoveAccent(user_name).ToLower();

                if (user_name == textBox2.Text && textBox3.Text == i.NIF.ToString())
                {
                    TrueUser = true;
                    nif_dir_loged = i.NIF;
                }

            }
            reader.Close();
            cn.Close();

            if (TrueUser)
            {
                TestDBConnection(cn);
                MessageBox.Show("Bem Vindo " + userName);
                Home h = new Home();
                h.Show();
                Visible = false;
            } else
            {
                MessageBox.Show("Argumentos Invalidos");
            
            }


        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            var userName = textBox2.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            var userPass = textBox3.Text;
        }
        private void TestDBConnection(SqlConnection CN)
        { 

            try
            {
                if (CN.State == ConnectionState.Open)
                {
                    MessageBox.Show("Successful connection to database " + CN.Database + " on the "
                   + CN.DataSource + " server", "Connection Test", MessageBoxButtons.OK);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to open connection to database due to the error \r\n" +
               ex.Message, "Connection Test", MessageBoxButtons.OK);
            }
        }
       

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
