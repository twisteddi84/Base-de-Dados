


go
CREATE TRIGGER Banda.TRG_RemocaoMusico
ON Banda.Musico
INSTEAD OF DELETE
AS
BEGIN
    -- Atualizar a tabela Banda.Pessoa_Instrumento definindo NIF_Musico como NULL
    UPDATE Banda.Pessoa_Instrumento
    SET NIF_Musico = NULL
    WHERE NIF_Musico IN (SELECT NIF FROM DELETED);


    DELETE FROM Banda.Servico_Musico
    WHERE NIF_musico IN (SELECT NIF FROM DELETED);

    -- Remover os m�sicos da tabela Banda.Musico
    DELETE FROM Banda.Musico
    WHERE NIF IN (SELECT NIF FROM DELETED);
END
go



go
CREATE TRIGGER TRG_RemocaoReforcoServico
ON Banda.Reforco
INSTEAD OF DELETE
AS
BEGIN
    -- Remover os registros da tabela Banda.Reforco_Servico
    DELETE FROM Banda.Reforco_Servico
    WHERE NIF_Reforco IN (SELECT NIF FROM DELETED);

    -- Remover os registros da tabela Banda.Reforco
    DELETE FROM Banda.Reforco
    WHERE NIF IN (SELECT NIF FROM DELETED);
END
go




go
CREATE TRIGGER TRG_UniqueFardaID
ON Banda.Musico
AFTER INSERT, UPDATE
AS
BEGIN
    IF EXISTS (
        SELECT farda_id
        FROM Banda.Musico
        WHERE farda_id IS NOT NULL
        GROUP BY farda_id
        HAVING COUNT(*) > 1
    )
    BEGIN
        RAISERROR ('Duplicated non-null values found in farda_id column.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;
END;
go


go
CREATE TRIGGER Banda.trg_UpdateAlunoOnProfessorDelete
ON Banda.Professor
INSTEAD OF DELETE
AS
BEGIN
    -- Atualizar a tabela Banda.Pessoa_Instrumento definindo NIF_Musico como NULL
    UPDATE Banda.Aluno
    SET  NIF_Professor = NULL
    WHERE NIF_Professor IN (SELECT NIF FROM DELETED);

    -- Remover os registros da tabela Banda.Reforco_Servico
    DELETE FROM Banda.Professor
    WHERE NIF IN (SELECT NIF FROM DELETED);

END;

go
CREATE TRIGGER Banda.TRG_RemocaoInstrumento
ON Banda.Instrumento
INSTEAD OF DELETE
AS
BEGIN

    DELETE FROM Banda.Pessoa_Instrumento
    WHERE identificador_Instrumento IN (SELECT Identificador FROM DELETED);
    
    DELETE FROM Banda.Instrumento
    WHERE Identificador IN (SELECT Identificador FROM DELETED);

END


go
CREATE TRIGGER Banda.TRG_RemocaoAluno
ON Banda.Aluno
INSTEAD OF DELETE
AS
BEGIN

-- Atualizar a tabela Banda.Pessoa_Instrumento definindo NIF_Aluno como NULL
    UPDATE Banda.Pessoa_Instrumento
    SET NIF_Aluno = NULL
    WHERE NIF_Aluno IN (SELECT NIF FROM DELETED);

    -- Remover os alunos da tabela Banda.Aluno
    DELETE FROM Banda.Aluno
    WHERE NIF IN (SELECT NIF FROM DELETED);
END

go
CREATE TRIGGER Banda.TRG_RemocaoSocio
ON Banda.Socio
INSTEAD OF DELETE
AS
BEGIN

    DELETE FROM Banda.Cota_Socio
    WHERE NIF_Socio IN (SELECT NIF FROM DELETED);
    
    DELETE FROM Banda.Socio
    WHERE NIF IN (SELECT NIF FROM DELETED);
END


go
CREATE TRIGGER Banda.TRG_RemocaoFarda
ON Banda.Farda
INSTEAD OF DELETE
AS
BEGIN
    UPDATE Banda.Musico
    SET farda_id = NULL
    WHERE farda_id IN (SELECT id FROM DELETED);

    DELETE FROM Banda.Farda
    WHERE id IN (SELECT id FROM DELETED);
END

go
CREATE TRIGGER Banda.TRG_RemocaoDiretor
ON Banda.Direcao
INSTEAD OF DELETE
AS
BEGIN

    DELETE FROM Banda.Servico_Direcao
    WHERE NIF_diretor IN (SELECT NIF FROM DELETED)

    DELETE FROM Banda.Direcao
    WHERE NIF IN (SELECT NIF FROM DELETED);
END


go
CREATE TRIGGER Banda.TRG_RemocaoServico
ON Banda.Servico
INSTEAD OF DELETE
AS
BEGIN
    DELETE FROM Banda.Tipos_por_Servico
    WHERE id_servico IN (SELECT id FROM DELETED);

    DELETE FROM Banda.Reforco_Servico
    WHERE id_servico IN (SELECT id FROM DELETED);

    DELETE FROM Banda.Servico_Musico
    WHERE id_servico IN (SELECT id FROM DELETED);

    DELETE FROM Banda.Servico_Direcao
    WHERE id_servico IN (SELECT id FROM DELETED)

    DELETE FROM Banda.Servico
    WHERE id IN (SELECT id FROM DELETED);
END
go


go
CREATE TRIGGER Banda.TRG_RemocaoCota
ON Banda.Cota
INSTEAD OF DELETE
AS
BEGIN

    DELETE FROM Banda.Cota_Socio
    WHERE Ano_Cota IN (SELECT ano FROM DELETED)

    DELETE FROM Banda.Cota
    WHERE ano IN (SELECT ano FROM DELETED);
END
go


go
CREATE TRIGGER Trigger_InserirCotaSocio
ON Banda.Cota
AFTER INSERT
AS
BEGIN
    INSERT INTO Banda.Cota_Socio (NIF_Socio, Ano_Cota, Data_do_pagamento)
    SELECT S.NIF, I.Ano, NULL
    FROM Banda.Socio AS S
    CROSS JOIN inserted AS I;
END
go