


go
CREATE PROCEDURE InsertProfessor
    @NIF INT,
    @Nome VARCHAR(50),
    @Data DATE,
    @TipoInstru VARCHAR(50),
    @Telefone VARCHAR(20),
    @Ordenado DECIMAL(10, 2)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Banda.Professor (NIF, nome, data_de_nascimento, tipo_instrumento, telefone, ordenado)
    VALUES (@NIF, @Nome, @Data, @TipoInstru, @Telefone, @Ordenado);

END
go


go
CREATE PROCEDURE UpdateProfessor
    @NIF INT,
    @Nome VARCHAR(50),
    @Data DATE,
    @TipoInstru VARCHAR(50),
    @Telefone VARCHAR(20),
    @Ordenado DECIMAL(10, 2)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Banda.Professor
    SET nome = @Nome,
        data_de_nascimento = @Data,
        tipo_instrumento = @TipoInstru,
        telefone = @Telefone,
        ordenado = @Ordenado
    WHERE NIF = @NIF;
END
go

go
CREATE PROCEDURE Banda.InsertMusico
    @NIF INT,
    @Nome VARCHAR(100),
    @Data DATE,
    @Naipe VARCHAR(50),
    @Telefone INT
AS
BEGIN
    INSERT INTO Banda.Musico (NIF, nome, data_de_nascimento, naipe, telefone)
    VALUES (@NIF, @Nome, @Data, @Naipe, @Telefone)
END
go

go
CREATE PROCEDURE Banda.UpdateMusicoSemFarda
    @NIF INT,
    @Nome VARCHAR(100),
    @Data DATE,
    @Naipe VARCHAR(50),
    @Telefone INT
AS
BEGIN
    UPDATE Banda.Musico 
    SET nome = @Nome, data_de_nascimento = @Data, naipe = @Naipe, telefone = @Telefone
    WHERE NIF = @NIF
END
go

go
CREATE PROCEDURE Banda.UpdateMusicoComFarda
    @NIF INT,
    @Nome VARCHAR(100),
    @Data DATE,
    @Naipe VARCHAR(50),
    @Telefone INT,
    @FardaID INT
AS
BEGIN
    UPDATE Banda.Musico 
    SET nome = @Nome, data_de_nascimento = @Data, naipe = @Naipe, telefone = @Telefone, farda_id  = @FardaID
    WHERE NIF = @NIF
END
go

go 
CREATE PROCEDURE Banda.UpdateInstrumento
    @ID INT,
    @Data DATE,
    @Modelo VARCHAR(50),
    @Tipo VARCHAR(50)
AS
BEGIN

    UPDATE Banda.Instrumento SET Data_Compra = @Data, Modelo = @Modelo, Tipo_Instrumento = @Tipo 
    WHERE Identificador = @ID
    
END
go

go
CREATE PROCEDURE Banda.InsertInstrumento
    @Data DATE,
    @Modelo VARCHAR(50),
    @Tipo VARCHAR(50)
AS
BEGIN

    INSERT Banda.Instrumento (Data_Compra , Modelo, Tipo_Instrumento) 
    VALUES (@Data,@Modelo,@Tipo)
    
END
go

go
CREATE PROCEDURE Banda.UpdateReforco
    @Nome VARCHAR(50),
    @Naipe VARCHAR(50),
    @Telefone INT,
    @NIF INT
AS
BEGIN
    UPDATE Banda.Reforco SET nome = @Nome, naipe = @Naipe, telefone = @Telefone WHERE NIF = @NIF   
END
go

go
CREATE PROCEDURE Banda.GetAlunoByProfNif
    @NIF_prof INT
AS
BEGIN
    
    SELECT * FROM Banda.Aluno WHERE NIF_Professor = @NIF_prof
END
go

go
CREATE PROCEDURE Banda.InsertReforco
    @Nome VARCHAR(50),
    @Naipe VARCHAR(50),
    @Telefone INT,
    @NIF INT
AS
BEGIN
    INSERT Banda.Reforco (NIF, nome, naipe, telefone) VALUES (@NIF, @Nome, @Naipe, @Telefone)
END
go

go
CREATE PROCEDURE Banda.InsertAluno
    @NIF INT,
    @Nome VARCHAR(100),
    @Data DATE,
    @Naipe VARCHAR(50),
	@Telefone INT
AS
BEGIN
    INSERT Banda.Aluno (NIF, nome, data_de_nascimento, naipe, telefone) VALUES (@NIF, @Nome, @Data, @Naipe, @Telefone)
END
go

go
CREATE PROCEDURE Banda.AlunoSemProfessor
    @NIF INT,
    @Nome VARCHAR(100),
    @Data DATE,
    @Naipe VARCHAR(50),
	@Telefone INT
AS
BEGIN
    UPDATE Banda.Aluno SET nome = @Nome, data_de_nascimento = @Data, naipe = @Naipe, telefone  = @Telefone WHERE NIF = @NIF
END
go

go
CREATE PROCEDURE Banda.UpdateServico
    @Nome VARCHAR(50),
    @Localidade VARCHAR(50),
    @Preco INT,
    @ID INT,
    @Hora TIME,
    @Data DATE,
    @Paga DECIMAL(10, 2)
AS
BEGIN
    UPDATE Banda.Servico SET nome  = @Nome, localidade = @Localidade, preco = @Preco, hora_ini = @Hora, data_servico  = @Data,  pagamento_por_musico = @Paga WHERE id = @ID
END
go

go
CREATE PROCEDURE Banda.InsertServico
    @Nome VARCHAR(50),
    @Localidade VARCHAR(50),
    @Preco INT,
    @Hora TIME,
    @Data DATE,
    @Paga DECIMAL(10, 2)
AS
BEGIN
    INSERT INTO Banda.Servico (nome, localidade, preco, hora_ini, data_servico, pagamento_por_musico) VALUES (@Nome, @Localidade, @Preco, @Hora, @Data, @Paga); SELECT SCOPE_IDENTITY();

END
go

go
CREATE PROCEDURE Banda.AlunoComProfessor
    @NIF INT,
    @Nome VARCHAR(100),
    @Data DATE,
    @Naipe VARCHAR(50),
	@Telefone INT,
	@NIF_Professor INT
AS
BEGIN
    UPDATE Banda.Aluno SET nome = @Nome,     data_de_nascimento = @Data,   naipe = @Naipe,     telefone  = @Telefone, NIF_Professor = @NIF_Professor  WHERE NIF = @NIF
END
go

go
CREATE PROCEDURE Banda.DeleteAluno
    @NIF INT
AS
BEGIN
    DELETE Banda.Aluno WHERE NIF=@NIF
END
go

go
CREATE PROCEDURE Banda.InsertAlunoInstrumento
    @NIF INT,
    @InstrumentoID INT
AS
BEGIN
    INSERT INTO Banda.Pessoa_Instrumento (identificador_Instrumento, NIF_Aluno) VALUES (@InstrumentoID, @NIF)
END
go


go
CREATE PROCEDURE Banda.InsertTiposPorServico
    @IdServico INT,
    @TipoServico VARCHAR(100)
AS
BEGIN
    INSERT Banda.Tipos_por_Servico (id_servico, tipo_servico) VALUES (@IdServico, @TipoServico)
END
go

go
CREATE PROCEDURE Banda.InsertCota
    @ano INT,
	@valor INT,
	@nif_dir INT
AS
BEGIN
	INSERT Banda.Cota (ano, valor, NIF_do_emissor) VALUES (@ano, @valor, @nif_dir) 
END
go

go
CREATE PROCEDURE Banda.UpdateCota
    @ano INT,
	@valor INT
AS
BEGIN
	UPDATE Banda.Cota SET valor = @valor WHERE ano = @ano
END
go

go
CREATE PROCEDURE Banda.DeleteCota
    @ano INT
AS
BEGIN
	DELETE Banda.Cota WHERE ano=@ano
END
go

go
CREATE PROCEDURE Banda.InsertServicoMusico
    @ID INT,
    @NIF INT
AS
BEGIN
    INSERT Banda.Servico_Musico (id_servico, NIF_musico) VALUES (@ID, @NIF)
END
go

go
CREATE PROCEDURE Banda.InsertServicoDirecao
    @ID INT,
    @NIF INT
AS
BEGIN
    INSERT Banda.Servico_Direcao (NIF_diretor , id_servico) VALUES (@NIF, @ID)
END
go

go
CREATE PROCEDURE Banda.UpdateCotaSocio
    @NIF INT,
	@Ano INT,
	@Data Date
AS
BEGIN
	UPDATE Banda.Cota_Socio SET  Data_do_pagamento = @Data WHERE (NIF_Socio = @NIF AND Ano_Cota = @Ano)
END
go

go
CREATE PROCEDURE Banda.InsertReforcoServico
    @ID INT,
    @NIF INT,
    @PRECO float
AS
BEGIN
    INSERT Banda.Reforco_Servico (NIF_Reforco , id_servico ,preco) VALUES (@NIF, @ID,@PRECO)
END
go

go
CREATE PROCEDURE Banda.InsertDirecao
    @NIF INT,
	@Nome VARCHAR(100),
	@Data DATE,
	@Email VARCHAR(100),
	@Telefone INT,
	@Cargo VARCHAR(20)
AS
BEGIN
    INSERT Banda.Direcao (NIF, nome, data_de_nascimento, telefone, email, cargo) VALUES (@NIF, @Nome, @Data, @Telefone, @Email, @Cargo)
END
go

go
CREATE PROCEDURE Banda.UpdateDirecao
    @NIF INT,
	@Nome VARCHAR(100),
	@Data DATE,
	@Email VARCHAR(100),
	@Telefone INT,
	@Cargo VARCHAR(20)
AS
BEGIN
    UPDATE Banda.Direcao SET Direcao.nome = @Nome, Direcao.data_de_nascimento = @Data, Direcao.telefone = @Telefone, Direcao.email = @Email, Direcao.cargo = @Cargo WHERE NIF = @NIF;
END
go

go
CREATE PROCEDURE Banda.DeleteDirecao
    @NIF INT
AS
BEGIN
    DELETE Banda.Direcao WHERE NIF=@NIF
END
go

go
CREATE PROCEDURE Banda.UpdateFarda
    @Tamanho VARCHAR(50),
    @ID INT,
    @Estado VARCHAR(50)
AS
BEGIN
    UPDATE Banda.Farda SET tamanho = @Tamanho, estado = @Estado WHERE id = @ID
END
go

go
CREATE PROCEDURE Banda.InsertFarda
    @Tamanho VARCHAR(50),
    @Estado VARCHAR(50)
AS
BEGIN
    INSERT Banda.Farda (estado, tamanho ) VALUES (@estado, @tamanho)
END
go

go
CREATE PROCEDURE Banda.DeleteFarda
    @ID INT
AS
BEGIN
    DELETE Banda.Farda WHERE id=@ID
END
go

go
CREATE PROCEDURE Banda.InsertPessoa_Instrumento
    @InstrumentoID INT,
    @NIF INT
AS
BEGIN
    INSERT INTO Banda.Pessoa_Instrumento (identificador_Instrumento, NIF_Musico) VALUES (@InstrumentoID, @NIF)
END
go

go
CREATE PROCEDURE Banda.InsertSocio
    @NIF INT,
    @Nome VARCHAR(50),
    @Telefone INT,
    @Email VARCHAR(100)
AS
BEGIN
    INSERT Banda.Socio (NIF, nome, telefone, email) VALUES (@NIF, @Nome, @Telefone, @Email)
END
go

go
CREATE PROCEDURE Banda.UpdateSocio
    @NIF INT,
    @Nome VARCHAR(50),
    @Telefone INT,
    @Email VARCHAR(100)
AS
BEGIN
    UPDATE Banda.Socio SET nome = @Nome, telefone = @Telefone, email = @email WHERE NIF = @NIF
END
go

go
CREATE PROCEDURE Banda.DeleteSocio
    @NIF INT
AS
BEGIN
    DELETE Banda.Socio WHERE NIF=@NIF
END
go