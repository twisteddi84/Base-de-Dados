﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Atribuir_Presencas : Form
    {
        private SqlConnection cn;
        private List<int> selectedDiretores;
        private List<int> selectedMusicos;
        private List<int> selectedReforcos;
        public Atribuir_Presencas()
        {
            InitializeComponent();
            selectedDiretores = new List<int>();
            selectedMusicos = new List<int>();
            selectedReforcos = new List<int>();
        }

        private void Atribuir_Presencas_Load(object sender, EventArgs e)
        {
            string query = "SELECT NIF,nome FROM Banda.Musico";

            cn = DatabaseManager.GetConnection();
            SqlCommand command = new SqlCommand(query, cn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                checkedListBoxMusicos.Items.Add(reader["NIF"].ToString() + "-" + reader["nome"].ToString());
            }
            reader.Close();
            cn.Close();

            cn = DatabaseManager.GetConnection();
            string query1 = "SELECT NIF,nome FROM Banda.Direcao ";

            SqlCommand command1 = new SqlCommand(query1, cn);
            SqlDataReader reader1 = command1.ExecuteReader();

            while (reader1.Read())
            {
                checkedListBoxDiretores.Items.Add(reader1["NIF"].ToString() + "-" + reader1["nome"].ToString());
            }
            reader1.Close();
            
            string query2 = "SELECT NIF,nome FROM Banda.Reforco";


            SqlCommand command2 = new SqlCommand(query2, cn);
            SqlDataReader reader2 = command2.ExecuteReader();

            while (reader2.Read())
            {
                checkedListBoxReforco.Items.Add(reader2["NIF"].ToString() +"-"+ reader2["nome"].ToString());
            }
            reader2.Close();
            cn.Close();
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            // Armazenar as checkboxes selecionadas na lista selectedTipos
            selectedDiretores.Clear(); // Limpar a lista antes de adicionar os itens selecionados
            selectedMusicos.Clear(); // Limpar a lista antes de adicionar os itens selecionados
            selectedReforcos.Clear(); // Limpar a lista antes de adicionar os itens selecionados

            foreach (var item in checkedListBoxDiretores.CheckedItems)
            {
                string nif = item.ToString().Split('-')[0].Trim();
                selectedDiretores.Add(int.Parse(nif));
            }

            foreach (var item in checkedListBoxMusicos.CheckedItems)
            {
                string nif = item.ToString().Split('-')[0].Trim();
                selectedMusicos.Add(int.Parse(nif));
            }

            foreach (var item in checkedListBoxReforco.CheckedItems)
            {
                string nif = item.ToString().Split('-')[0].Trim();
                selectedReforcos.Add(int.Parse(nif));
            }

            // Fechar o formulário SelectTipos
            this.Close();
        }
        public List<int> GetSelectedMusicos()
        {
            return selectedMusicos;
        }
        public List<int> GetSelectedDiretores()
        {
            return selectedDiretores;
        }
        public List<int> GetSelectedReforcos()
        {
            return selectedReforcos;
        }
    }
}
