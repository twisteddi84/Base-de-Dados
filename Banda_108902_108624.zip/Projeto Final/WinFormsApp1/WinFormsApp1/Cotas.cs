﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Cotas : Form
    {
        private SqlConnection cn;
        private int currentContact;
        private bool adding;
        public Cotas()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;
        }

        private void id_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void nome_box_TextChanged(object sender, EventArgs e)
        {

        }
        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }


        private void Cotas_Load(object sender, EventArgs e)
        {

            Confirmar.Visible = false;
            Cancelar.Visible = false;
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Cota ", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            list_cotas.Items.Clear();

            while (reader.Read())
            {
                Cota i = new Cota();
                i.Valor = (int)reader["valor"];
                i.DataAno = (int)reader["ano"];

                if (!reader.IsDBNull(reader.GetOrdinal("NIF_do_emissor")))
                {
                    i.NIFEmissor = (int)reader["NIF_do_emissor"];
                }
                else
                {
                    
                }


                list_cotas.Items.Add(i);
            }
            reader.Close();
            cn.Close();


            currentContact = 0;
            ShowContact();
        }

        public void ShowContact()
        {
            if (list_cotas.Items.Count == 0 | currentContact < 0)
                return;
            Cota i = new Cota();
            i = (Cota)list_cotas.Items[currentContact];
            if(i.NIFEmissor == 0)
            {
                id_box.Text = "Não tem";
            }
            else
            {
                id_box.Text = i.NIFEmissor.ToString();
            }
            ano_box.Text = i.DataAno.ToString();
            valor_box.Text = i.Valor.ToString();

        }

        private void list_cotas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_cotas.SelectedIndex >= 0)
            {
                currentContact = list_cotas.SelectedIndex;
                ShowContact();
            }
        }

        public void ClearFields()
        {
            id_box.Text = "";
            ano_box.Text = "";
            valor_box.Text = "";
        }

        public void UnlockControls()
        {
            id_box.ReadOnly = false;
            ano_box.ReadOnly = false;
            valor_box.ReadOnly = false;
        }

        public void LockControls()
        {
            id_box.ReadOnly = true;
            ano_box.ReadOnly = true;
            valor_box.ReadOnly = true;
        }

        public void HideButtons()
        {
            UnlockControls();
            Add.Visible = false;
            Atualizar.Visible = false;
            Remover.Visible = false;
        }


        public void ShowButtons()
        {
            LockControls();
            Add.Visible = true;
            Atualizar.Visible = true;
            Remover.Visible = true;
        }


        private void Add_Click(object sender, EventArgs e)
        {
            adding = true;
            
            ClearFields();
            HideButtons();
            id_box.Text = Form1.nif_dir_loged.ToString();
            id_box.ReadOnly = true;
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_cotas.Enabled = false;
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                SaveCota();
            }
            catch (Exception ex)
            {
                
                MessageBox.Show(ex.Message);
            }
            list_cotas.Enabled = true;
            int idx = list_cotas.FindString(id_box.Text);
            list_cotas.SelectedIndex = idx;
            ShowButtons();
            Confirmar.Visible = false;
            Cancelar.Visible = false;
        }

        private void SubmitContact(Cota C)
        {
            
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();
            
            cmd.CommandText = "Banda.InsertCota";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ano", C.DataAno);
            cmd.Parameters.AddWithValue("@valor", C.Valor);
            cmd.Parameters.AddWithValue("@nif_dir", Form1.nif_dir_loged);


            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                if (ex.Number == 547)
                {
                    MessageBox.Show("O Ano não é válido ou é maior que o atual");
                }else
                {
                    throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
                }
               
            }
        }

        private void UpdateSocio(Cota C)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.UpdateCota";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ano", C.DataAno);
            cmd.Parameters.AddWithValue("@valor", C.Valor);
            cmd.Connection = cn;

            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                if (rows == 1)
                    MessageBox.Show("Update OK");
                else
                    MessageBox.Show("Update NOT Ok");
            }
        }

        private bool SaveCota()
        {
            Cota i = new Cota();
            try
            {
                i.NIFEmissor = Form1.nif_dir_loged;
                i.DataAno = int.Parse(ano_box.Text);
                i.Valor = int.Parse(valor_box.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            if (adding)
            {
                SubmitContact(i);
                list_cotas.Items.Add(i);
            }
            else
            {
                UpdateSocio(i);
                list_cotas.Items[currentContact] = i;
            }
            return true;
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            if (list_cotas.SelectedIndex > -1)
            {
                try
                {
                    RemoveCota(((Cota)list_cotas.SelectedItem).DataAno);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                list_cotas.Items.RemoveAt(list_cotas.SelectedIndex);
                if (currentContact == list_cotas.Items.Count)
                    currentContact = list_cotas.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more socio");
                }
                else
                {
                    ShowContact();
                }
            }
        }

        private void RemoveCota(int ano)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.DeleteCota";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ano", ano);
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to delete socio in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }


        private void Cancelar_Click(object sender, EventArgs e)
        {
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            list_cotas.Enabled = true;
            if (list_cotas.Items.Count > 0)
            {
                currentContact = list_cotas.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }

        private void Atualizar_Click(object sender, EventArgs e)
        {
            if (currentContact <= 0)
            {
                //MessageBox.Show("Please select a contact to edit");
                currentContact = 1;
                //return;
            }
            adding = false;
            HideButtons();
            id_box.ReadOnly = true;
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_cotas.Enabled = false;
            
        }

    }
}
