﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    class Socio
    {

        private int _NIF;
        private String _nome;
        private int _tele;
        private String _email;

        public int NIF
        {
            get { return _NIF; }
            set { _NIF = value; }
        }

        public String Nome
        {
            get { return _nome; }
            set { _nome = value; }
        }

        public int Tele
        {
            get { return _tele; }
            set { _tele = value; }
        }


        public String Email
        {
            get { return _email; }
            set { _email = value; }
        }

        public override String ToString()
        {
            return _NIF + " " + _nome;
        }

        public Socio() : base()
        {
        }
        public Socio(int NIF, String nome, int tele, String email) : base()
        {
            this._NIF = NIF;
            this._nome = nome;
            this._tele = tele;
            this._email = email;

        }

    }
}
