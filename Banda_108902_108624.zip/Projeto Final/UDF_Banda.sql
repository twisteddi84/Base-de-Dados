go
CREATE FUNCTION Banda.GetCotaSocioInfo (@NIF_Socio INT)
RETURNS TABLE
AS
RETURN
(
    SELECT CS.*, C.NIF_do_emissor, C.valor, D.nome AS NomeDiretor
    FROM Banda.Cota_Socio CS
    INNER JOIN Banda.Cota C ON CS.Ano_Cota = C.ano
    INNER JOIN Banda.Direcao D ON C.NIF_do_emissor = D.NIF
    WHERE CS.NIF_Socio = @NIF_Socio
)

go

go
CREATE FUNCTION Banda.GetNameService (@NIF_Reforco INT)
RETURNS TABLE 
AS
RETURN 
(

    SELECT id, nome, localidade, NIF_Reforco, Reforco_Servico.preco FROM Banda.Reforco_Servico, Banda.Servico WHERE id_servico = id and NIF_Reforco = @NIF_Reforco
)

go

go
CREATE FUNCTION Banda.GetNameService_to_Dir (@NIF_Diretor INT)
RETURNS TABLE 
AS
RETURN 
(

   SELECT id, nome, localidade FROM Banda.Servico_Direcao, Banda.Servico WHERE id_servico = id and NIF_diretor = @NIF_Diretor
)
go

go
CREATE FUNCTION Banda.GetNIFsPessoaInstrumento (@InstrumentoID INT)
RETURNS TABLE 
AS
RETURN 
(

   SELECT NIF_Musico, NIF_Aluno FROM Banda.Pessoa_Instrumento WHERE identificador_Instrumento = @InstrumentoID
)
go

go
CREATE FUNCTION Banda.GetMusicoByNIF (@NIF INT)
RETURNS TABLE 
AS
RETURN 
(

   SELECT * FROM Banda.Musico WHERE NIF = @NIF
)
go

go
CREATE FUNCTION Banda.GetAlunoByNIF (@NIF INT)
RETURNS TABLE 
AS
RETURN 
(

   SELECT * FROM Banda.Aluno WHERE NIF = @NIF
)
go