﻿
namespace WinFormsApp1
{
    partial class Atribuir_Presencas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.checkedListBoxDiretores = new System.Windows.Forms.CheckedListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checkedListBoxMusicos = new System.Windows.Forms.CheckedListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.checkedListBoxReforco = new System.Windows.Forms.CheckedListBox();
            this.Cancelar = new System.Windows.Forms.Button();
            this.Confirmar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("OCR A Extended", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(53, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 35);
            this.label1.TabIndex = 3;
            this.label1.Text = "Diretores";
            // 
            // checkedListBoxDiretores
            // 
            this.checkedListBoxDiretores.CheckOnClick = true;
            this.checkedListBoxDiretores.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkedListBoxDiretores.FormattingEnabled = true;
            this.checkedListBoxDiretores.Location = new System.Drawing.Point(30, 99);
            this.checkedListBoxDiretores.Name = "checkedListBoxDiretores";
            this.checkedListBoxDiretores.Size = new System.Drawing.Size(273, 328);
            this.checkedListBoxDiretores.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("OCR A Extended", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(416, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 35);
            this.label2.TabIndex = 5;
            this.label2.Text = "Músicos";
            // 
            // checkedListBoxMusicos
            // 
            this.checkedListBoxMusicos.CheckOnClick = true;
            this.checkedListBoxMusicos.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkedListBoxMusicos.FormattingEnabled = true;
            this.checkedListBoxMusicos.Location = new System.Drawing.Point(377, 99);
            this.checkedListBoxMusicos.Name = "checkedListBoxMusicos";
            this.checkedListBoxMusicos.Size = new System.Drawing.Size(273, 328);
            this.checkedListBoxMusicos.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("OCR A Extended", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(764, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(191, 35);
            this.label3.TabIndex = 7;
            this.label3.Text = "Reforços";
            // 
            // checkedListBoxReforco
            // 
            this.checkedListBoxReforco.CheckOnClick = true;
            this.checkedListBoxReforco.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkedListBoxReforco.FormattingEnabled = true;
            this.checkedListBoxReforco.Location = new System.Drawing.Point(724, 99);
            this.checkedListBoxReforco.Name = "checkedListBoxReforco";
            this.checkedListBoxReforco.Size = new System.Drawing.Size(273, 328);
            this.checkedListBoxReforco.TabIndex = 6;
            // 
            // Cancelar
            // 
            this.Cancelar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cancelar.Location = new System.Drawing.Point(650, 469);
            this.Cancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(189, 58);
            this.Cancelar.TabIndex = 45;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            // 
            // Confirmar
            // 
            this.Confirmar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Confirmar.Location = new System.Drawing.Point(182, 469);
            this.Confirmar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Confirmar.Name = "Confirmar";
            this.Confirmar.Size = new System.Drawing.Size(189, 58);
            this.Confirmar.TabIndex = 44;
            this.Confirmar.Text = "Confirmar";
            this.Confirmar.UseVisualStyleBackColor = true;
            this.Confirmar.Click += new System.EventHandler(this.Confirmar_Click);
            // 
            // Atribuir_Presencas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 557);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.Confirmar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.checkedListBoxReforco);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkedListBoxMusicos);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkedListBoxDiretores);
            this.Name = "Atribuir_Presencas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Atribuir_Presencas";
            this.Load += new System.EventHandler(this.Atribuir_Presencas_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox checkedListBoxDiretores;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckedListBox checkedListBoxMusicos;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckedListBox checkedListBoxReforco;
        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button Confirmar;
    }
}