INSERT INTO Banda.Instrumento(Data_Compra, Modelo, Tipo_Instrumento)
VALUES
	('2000-05-10','Selmer YUSA','Saxofone Alto'), --1
	('1997-02-15','Yamaha 23','Saxofone Alto'), --2
	('1950-10-25','Yanagisawa 2R4','Saxofone Alto'),--3

	('1940-12-21','Thomann TR200','Trompete'), --4
	('1956-10-24','VanDiesel 69','Trompete'), --5
	('1989-09-10','Yamaha YTR','Trompete'), --6

	('1890-08-24','B&S GRS','Tuba'), --7
	('1942-05-23','Melton RA-L','Tuba'), --8

	('2020-12-01','Benson','Saxofone Soprano'), --9

	('2010-10-01','Thomann Antique','Saxofone Tenor'), --10
	('1967-06-09','Yanagisawa T-WO1','Saxofone Tenor'), --11

	('1980-10-20','Yamaha YCL','Clarinete'), --12
	('1922-09-12','Buffet Crampon','Clarinete'), --13
	('1897-01-01','Startone SCL','Clarinete'), --14
	('1978-04-17','Yamaha 221','Clarinete'), --15

	('1897-11-22','Jupiter JBC','Clarinete Baixo'), --16

	('1978-08-19','Thomann SL 5','Trombone'), --17
	('2000-01-02','Yamaha SL-345','Trombone'), --18

	('1888-04-28','Hans Hoyer 6801','Trompa'), --19
	('1888-04-28','Yamaha YHR-567','Trompa'), --20

	('1969-12-22','Yamaha YFL-200C','Flauta'), --21 
	('1799-10-12','Pearl Flutes PFA','Flauta'), --22

	('1978-12-12','LaLique HF200','Obo�'), --23

	('1800-10-04','Gretsch Drums WG','Bateria'), --24

	('1799-12-15','Millenium MD124','Tarola'), --25
	('1850-10-23','Pearl 14','Tarola'), --26

	('1901-01-24','Meinl 22','Pratos'); --28

Insert into Banda.Farda (tamanho, estado)
VALUES
	('XS','Camisa muito usada'), --1
	('S','Camisa usada'), --2
	('S','Farda Nova'), --3 
	('S','Bom estado'), --4
	('M','Camisa com colarinho mau'), --5
	('M','Farda Nova'), --6
	('M','Farda Nova'), --7
	('L','Casaco com um buraco'), --8
	('L','Bom estado'), --9
	('L','Sem Calças'), --10
	('XL','Usada'), --11			
	('XL','Farda nova'), --12
	('XL','Camisa não muito boa'), --13
	('XL','Calças não muito boas'), --14
	('XXL','Farda nova'), --15
	('XXXL','Farda nova'), --16
	('16 anos','Pouco usado'), --17
	('16 anos','Farda Nova'), --18
	('16 anos','Farda Nova'), --19
	('15 anos','Farda Nova'), --20
	('15 anos','Farda Nova'), --21
	('15 anos','Farda Nova'), --22
	('15 anos','Usada'), --23
	('14 anos','Calças não muito boas'), --24
	('14 anos','Farda Nova'), --25
	('14 anos','Bom estado'), --26
	('XS','Farda Nova'), --27
	('XS','Farda Nova'), --28
	('XS','Colarinho estragado'); --29



INSERT INTO Banda.Musico (NIF, nome, data_de_nascimento, naipe, telefone, farda_id)
VALUES
	(123456789, 'John Doe', '2003-02-05', 'Saxofone Soprano', 987654321,28),

	(222222222, 'Sarah Davis', '1992-07-03', 'Saxofone Alto', 956789012,1),
	(123456790, 'Mark Johnson', '1998-06-20', 'Saxofone Alto', 912345678,9),
	(234567891, 'Lisa Anderson', '1991-03-12', 'Saxofone Alto', 923456789,5),

	(444444443, 'Andrew Walker', '1987-09-17', 'Saxofone Tenor', 967890123,10),
	(345678912, 'Eric Thompson', '1995-11-02', 'Saxofone Tenor', 934567890,11),
	(666666667, 'Sophie Turner', '1993-04-25', 'Saxofone Tenor', 989012346,23),

	(987654321, 'Jane Smith', '1985-09-20', 'Trompete', 923456789,18),
	(111111111, 'Michael Brown', '1988-11-25', 'Trompete', 945678901,17),
	(333333332, 'Elizabeth Lee', '1990-02-02', 'Trompete', 956789012,2),
	(777723453, 'Matthew Turner', '1986-12-04', 'Trompete', 901234567,15),
	
	(456789123, 'Alice Johnson', '1995-03-10', 'Percuss�o', 934567890,16),
	(666666666, 'Olivia Clark', '1994-01-18', 'Percuss�o', 990123456,3),
	(222222221, 'Christopher Hill', '1989-07-16', 'Percuss�o', 945678901,6),
	
	(333333333, 'Robert Wilson', '1983-02-14', 'Clarinete', 967890123,29),
	(777777778, 'Benjamin Taylor', '1990-09-17', 'Clarinete', 900123457,27),
	(888888889, 'Victoria Hall', '1997-05-28', 'Clarinete', 912345678,4),
	(999999990, 'Jacob Martin', '1994-12-08', 'Clarinete', 923456789,26),

	(666666665, 'Joseph Turner', '1992-01-29', 'Clarinete Baixo', 989012345,21),
	
	(444444444, 'Emily Thompson', '1991-09-08', 'Flauta', 978901234,8),
	(777777776, 'Ava White', '1984-12-15', 'Flauta', 990123456,19),

	(555555555, 'Thomas Anderson', '1993-08-10', 'Trombone',934567890,20),
    (666666664, 'Sophia Turner', '1996-06-15', 'Trombone', 978901234,22),

	(777777779, 'Isabella Martinez', '1994-11-12', 'Trompa', 945678901,7),
    (888888890, 'Daniel Thompson', '1999-04-25', 'Trompa', 956789012,12);



INSERT INTO Banda.Professor (NIF, nome, data_de_nascimento, tipo_instrumento, telefone, ordenado)
VALUES
    (111111112, 'Bruno Santos', '1975-05-10', 'Saxofone', 987654328, 1200.00),
    (222222223, 'Edgar Silva', '1982-09-15', 'Trompete', 976543210, 1000.50),
    (333333334, 'Francisco Geraldes', '1978-02-20', 'Tuba', 965432109, 980.00),
    (444444445, 'Maria Sousa', '1985-07-25', 'Flauta', 954321098, 1000.00);

INSERT INTO Banda.Aluno (NIF, nome, data_de_nascimento, naipe,telefone,NIF_Professor)
VALUES
	(111111333, 'Tomás Matos','1997-04-12','Saxofone Alto',915232342,111111112),
	(222224444, 'Diogo Almeida','1997-03-10','Trompete',912459955,222222223),
	(333337777, 'Maria Amado','2004-02-01','Flauta',914937555,444444445)

INSERT INTO Banda.Pessoa_Instrumento (identificador_Instrumento, NIF_Musico, NIF_Aluno)
VALUES 
    (9, 123456789, NULL),   --Soprano (musico)
    (2, 222222222,NULL),   --Alto (musico)
    (1, NULL,111111333),   --Alto (aluno)
    (10, 444444443, NULL),  --Tenor (musico)
    (11, 666666667, NULL),  --Tenor (musico)
    (4, NULL, 222224444),   --Trompete (aluno)
    (6, 333333332, NULL),   --Trompete (musico)
    (12, 777777778, NULL),  --Clarinete (musico)
    (13, 888888889, NULL),  --Clarinete (musico)
    (15, 999999990, NULL), --Clarinete (musico)
    (16, 666666665, NULL), --Clarinete Baixo (musico)
    (21, NULL,333337777), --Flauta (aluno)
    (18, 555555555,NULL), --Trombone (musico)
    (19, 888888890,NULL); --Trompa (musico)



INSERT INTO Banda.Tipo_servico (tipo_servico)
VALUES
	('Procissão'),
	('Peditório'),
	('Missa'),
	('Concerto'),
	('Outro');

INSERT INTO Banda.Servico (nome,localidade,preco,hora_ini,data_servico,pagamento_por_musico)
VALUES
	('Festa de São Miguel','Bairro de São Miguel',800,'08:00:00','2022-06-17',19), --1
	('Festa de São Jorge','São Jorge',750,'08:30:00','2022-08-28',17.5), --2
	('Senhor dos Passos','Porto de Mós',500,'14:30:00','2023-03-15',15) --3

INSERT INTO Banda.Tipos_por_Servico(id_servico,tipo_servico)
VALUES
	(1,'Missa'),
	(1,'Procissão'),
	(1,'Concerto'),

	(2,'Peditório'),
	(2,'Missa'),
	(2,'Procissão'),

	(3,'Procissão');
	

INSERT INTO Banda.Reforco(NIF,nome,naipe,telefone)
VALUES
	(666777888,'Manuel Jorge','Tuba',912399987),
	(777666333,'Joana Sousa','Clarinete',923427917),
	(992233771,'Bernardo Moniz', 'Trombone', 921762821),
	(123712520,'António António','Trompa', 912399998);

INSERT INTO Banda.Reforco_Servico(NIF_Reforco,id_servico,preco)
VALUES
	(666777888,1,50),
	(123712520,1,60),

	(777666333,2,50),
	(666777888,2,50),

	(992233771,3,30);
	
INSERT INTO Banda.Servico_Musico(id_servico, NIF_musico)
VALUES
    (1, 123456789), (1, 222222222), (1, 123456790), (1, 234567891), (1, 444444443),
    (1, 345678912), (1, 666666667), (1, 987654321), (1, 111111111), (1, 333333332),
    (1, 777723453), (1, 456789123), (1, 666666666), (1, 222222221), (1, 333333333),
    (1, 777777778), (1, 888888889), (1, 999999990), (1, 666666665), (1, 444444444),
    (1, 777777776), (1, 555555555), (1, 777777779), (1, 888888890),


    (2, 123456789), (2, 222222222), (2, 123456790), (2, 234567891), (2, 444444443),
    (2, 345678912), (2, 666666667), (2, 987654321), (2, 111111111), (2, 333333332),
    (2, 777723453), (2, 456789123), (2, 666666666), (2, 222222221), (2, 333333333),
    (2, 777777778), (2, 888888889), (2, 999999990), (2, 666666665), (2, 444444444),
    (2, 777777776), (2, 555555555), (2, 777777779), (2, 888888890),

    (3, 123456789), (3, 222222222), (3, 123456790), (3, 234567891), (3, 444444443),
    (3, 345678912), (3, 666666667), (3, 987654321), (3, 111111111), (3, 333333332),
	(3, 777723453), (3, 456789123), (3, 666666666), (3, 222222221), (3, 333333333),
    (3, 777777778), (3, 888888889), (3, 999999990), (3, 666666665), (3, 444444444),
    (3, 777777776), (3, 555555555), (3, 777777779), (3, 888888890);


INSERT INTO Banda.Direcao (NIF,nome,data_de_nascimento,telefone,email,cargo)
VALUES
	(172834539,'Carlos Pascoal','1968-10-11',912352741,'carlospascoal@gmail.com','Presidente'),
	(135421356,'Susana Rosário','1973-08-30',914937544,'susanaprosario@hotmail.com','Vice-Presidente'),
	(123554431,'João Silva','1970-05-12',912234233,'joao12@hotmail.com','Tesoureiro'),
	(958278345,'Ana Grave','1990-01-01',912492042,'anagrave01@gmail.com','Orgao Fiscal'),
	(864732634,'Rui Silva','1995-02-02',965493275,'ruizinho@gmail.com','Assembleia Geral');

INSERT INTO Banda.Servico_Direcao (NIF_diretor,id_servico)
VALUES
	(172834539,1),
	(958278345,1),

	(123554431,2),
	(172834539,2),
	(135421356,2),

	(135421356,3),
	(172834539,3);

INSERT INTO Banda.Socio(NIF,nome,telefone,email)
VALUES
	(678943237,'Joao Cancelo',917949921,'jonyoftheballs@hotmail.com'),
	(777777777,'Cristiano Ronaldo',977777777,'soulindo@hotmail.Siiiii'),
	(235432111,'Rui Patricio',912342344,'bolanaoentra@gmail.pt'),
	(574364859,'Bruno Fernandes',912332322,'bruninhoFernas@hotmail.ptptpt');

INSERT INTO Banda.Cota(ano,valor,NIF_do_emissor)
VALUES
	(2020,20,172834539),
	(2021,20,172834539),
	(2022,20,135421356);

INSERT INTO Banda.Cota_Socio(NIF_Socio,Ano_Cota,Data_do_pagamento)
VALUES
	(678943237,2020,'2020-03-12'),
	(678943237,2021,'2021-05-11'),
	(678943237,2022,NULL),

	(777777777,2020,'2020-03-12'),
	(777777777,2021,'2021-05-10'),
	(777777777,2022,NULL),

	(235432111,2020,'2020-10-10'),
	(235432111,2021,'2021-05-11'),
	(235432111,2022,NULL),

	(574364859,2020,'2020-01-03'),
	(574364859,2021,'2021-05-11'),
	(574364859,2022,NULL);

