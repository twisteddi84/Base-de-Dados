﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Fardas_Disponiveis : Form
    {
        int id_Selecionado;
        private SqlConnection cn;
        public Fardas_Disponiveis()
        {
            InitializeComponent();
            checkedListBox1.ItemCheck += checkedListBox1_ItemCheck;
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Cancelar a seleção de outros itens
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                if (i != e.Index)
                {
                    checkedListBox1.SetItemChecked(i, false);
                }
            }
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            // Armazenar as checkboxes selecionadas na lista selectedTipos
            id_Selecionado = 0; // Limpar a lista antes de adicionar os itens selecionados

            foreach (var item in checkedListBox1.CheckedItems)
            {
                string id = item.ToString().Split('-')[0].Trim();
                id_Selecionado = int.Parse(id);
            }

            // Fechar o formulário SelectTipos
            this.Close();
        }

        private void Fardas_Disponiveis_Load(object sender, EventArgs e)
        {
            checkedListBox1.SelectionMode = SelectionMode.One;
            string query = "SELECT * FROM Banda.FardasDisponiveis;";
            cn = DatabaseManager.GetConnection();
            SqlCommand command = new SqlCommand(query, cn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                checkedListBox1.Items.Add(reader["id"].ToString() + "-" + reader["tamanho"].ToString());
            }

            reader.Close();
            cn.Close();
        }

        public int GetID()
        {
            return id_Selecionado;
        }
    }
}
