﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    class Instrumento
    {
		private String _ID;
		private DateTime _DataCompra;
		private String _Modelo;
		private String _TipoInstrumento;

		public String ID
		{
			get { return _ID; }
			set { _ID = value; }
		}


		public String Modelo
		{
			get { return _Modelo; }
			set
			{
				if (value == null | String.IsNullOrEmpty(value))
				{
					throw new Exception("Company Name field can’t be empty");
					return;
				}
				_Modelo = value;
			}
		}

		public String TipoInstrumento
		{
			get { return _TipoInstrumento; }
			set { _TipoInstrumento = value; }
		}

		public DateTime DataCompra
		{
			get { return _DataCompra; }
			set { _DataCompra = value; }
		}




		public override String ToString()
		{
			return _ID + "   " + _TipoInstrumento;
		}

		public Instrumento() : base()
		{
		}

		public Instrumento(String ID, DateTime DataCompra, String Modelo, String TipoInstrumento) : base()
		{
			this.ID = _ID;
			this.DataCompra = _DataCompra;
			this.Modelo = _Modelo;
			this.TipoInstrumento = _TipoInstrumento;
		}

		public Instrumento(DateTime DataCompra, String Modelo, String TipoInstrumento) : base()
		{
			this.DataCompra = _DataCompra;
			this.Modelo = _Modelo;
			this.TipoInstrumento = _TipoInstrumento;
		}
	}
}
