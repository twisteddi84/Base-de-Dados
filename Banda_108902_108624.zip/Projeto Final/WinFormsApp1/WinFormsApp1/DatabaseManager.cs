﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace WinFormsApp1
{
    public static class DatabaseManager
    {
        private static SqlConnection cn;

        public static SqlConnection GetConnection()
        {
            if (cn == null)
            {
                cn = new SqlConnection("data source = tcp:mednat.ieeta.pt\\SQLSERVER, 8101; Initial Catalog = p4g8; uid = p4g8; password = 497397053@BDTD");
                //cn = new SqlConnection("Data Source=DESKTOP-GOROLEN; Initial Catalog=Banda; Integrated Security=True");
            }

            if (cn.State != ConnectionState.Open)
            {
                cn.Open();
            }

            return cn;
        }

        public static void CloseConnection()
        {
            if (cn != null && cn.State == ConnectionState.Open)
            {
                cn.Close();
            }
        }
    }
}
