﻿
namespace WinFormsApp1
{
    partial class Aluno_atribuir_Instrumento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancelar = new System.Windows.Forms.Button();
            this.Confirmar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.farda_label = new System.Windows.Forms.Label();
            this.prof_box = new System.Windows.Forms.TextBox();
            this.tele_label = new System.Windows.Forms.Label();
            this.tele_box = new System.Windows.Forms.TextBox();
            this.data_label = new System.Windows.Forms.Label();
            this.data_box = new System.Windows.Forms.TextBox();
            this.naipe_label = new System.Windows.Forms.Label();
            this.naipe_box = new System.Windows.Forms.TextBox();
            this.nome_label = new System.Windows.Forms.Label();
            this.nome_box = new System.Windows.Forms.TextBox();
            this.nif_label = new System.Windows.Forms.Label();
            this.id_box = new System.Windows.Forms.TextBox();
            this.Musicos_label = new System.Windows.Forms.Label();
            this.list_alunos = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Cancelar
            // 
            this.Cancelar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cancelar.Location = new System.Drawing.Point(660, 392);
            this.Cancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(128, 40);
            this.Cancelar.TabIndex = 57;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // Confirmar
            // 
            this.Confirmar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Confirmar.Location = new System.Drawing.Point(460, 392);
            this.Confirmar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Confirmar.Name = "Confirmar";
            this.Confirmar.Size = new System.Drawing.Size(128, 40);
            this.Confirmar.TabIndex = 56;
            this.Confirmar.Text = "Confirmar";
            this.Confirmar.UseVisualStyleBackColor = true;
            this.Confirmar.Click += new System.EventHandler(this.Confirmar_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(870, 20);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 40);
            this.button1.TabIndex = 55;
            this.button1.Text = "HOME";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // farda_label
            // 
            this.farda_label.AutoSize = true;
            this.farda_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.farda_label.Location = new System.Drawing.Point(318, 329);
            this.farda_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.farda_label.Name = "farda_label";
            this.farda_label.Size = new System.Drawing.Size(192, 24);
            this.farda_label.TabIndex = 54;
            this.farda_label.Text = "NIF PROFESSOR";
            // 
            // prof_box
            // 
            this.prof_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.prof_box.Location = new System.Drawing.Point(532, 326);
            this.prof_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.prof_box.Name = "prof_box";
            this.prof_box.ReadOnly = true;
            this.prof_box.Size = new System.Drawing.Size(179, 28);
            this.prof_box.TabIndex = 53;
            // 
            // tele_label
            // 
            this.tele_label.AutoSize = true;
            this.tele_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_label.Location = new System.Drawing.Point(660, 271);
            this.tele_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tele_label.Name = "tele_label";
            this.tele_label.Size = new System.Drawing.Size(136, 24);
            this.tele_label.TabIndex = 52;
            this.tele_label.Text = "TELEFONE:";
            // 
            // tele_box
            // 
            this.tele_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_box.Location = new System.Drawing.Point(802, 268);
            this.tele_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.tele_box.Name = "tele_box";
            this.tele_box.ReadOnly = true;
            this.tele_box.Size = new System.Drawing.Size(187, 28);
            this.tele_box.TabIndex = 51;
            // 
            // data_label
            // 
            this.data_label.AutoSize = true;
            this.data_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_label.Location = new System.Drawing.Point(318, 205);
            this.data_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.data_label.Name = "data_label";
            this.data_label.Size = new System.Drawing.Size(234, 24);
            this.data_label.TabIndex = 50;
            this.data_label.Text = "DATA NASCIMENTO:";
            // 
            // data_box
            // 
            this.data_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.data_box.Location = new System.Drawing.Point(576, 203);
            this.data_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.data_box.Name = "data_box";
            this.data_box.ReadOnly = true;
            this.data_box.Size = new System.Drawing.Size(178, 28);
            this.data_box.TabIndex = 49;
            // 
            // naipe_label
            // 
            this.naipe_label.AutoSize = true;
            this.naipe_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.naipe_label.Location = new System.Drawing.Point(318, 271);
            this.naipe_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.naipe_label.Name = "naipe_label";
            this.naipe_label.Size = new System.Drawing.Size(94, 24);
            this.naipe_label.TabIndex = 48;
            this.naipe_label.Text = "NAIPE:";
            // 
            // naipe_box
            // 
            this.naipe_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.naipe_box.Location = new System.Drawing.Point(428, 270);
            this.naipe_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.naipe_box.Name = "naipe_box";
            this.naipe_box.ReadOnly = true;
            this.naipe_box.Size = new System.Drawing.Size(224, 28);
            this.naipe_box.TabIndex = 47;
            // 
            // nome_label
            // 
            this.nome_label.AutoSize = true;
            this.nome_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_label.Location = new System.Drawing.Point(576, 133);
            this.nome_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nome_label.Name = "nome_label";
            this.nome_label.Size = new System.Drawing.Size(80, 24);
            this.nome_label.TabIndex = 46;
            this.nome_label.Text = "NOME:";
            // 
            // nome_box
            // 
            this.nome_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_box.Location = new System.Drawing.Point(660, 133);
            this.nome_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.nome_box.Name = "nome_box";
            this.nome_box.ReadOnly = true;
            this.nome_box.Size = new System.Drawing.Size(268, 28);
            this.nome_box.TabIndex = 45;
            // 
            // nif_label
            // 
            this.nif_label.AutoSize = true;
            this.nif_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nif_label.Location = new System.Drawing.Point(318, 133);
            this.nif_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nif_label.Name = "nif_label";
            this.nif_label.Size = new System.Drawing.Size(66, 24);
            this.nif_label.TabIndex = 44;
            this.nif_label.Text = "NIF:";
            // 
            // id_box
            // 
            this.id_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_box.Location = new System.Drawing.Point(390, 133);
            this.id_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.id_box.Name = "id_box";
            this.id_box.ReadOnly = true;
            this.id_box.Size = new System.Drawing.Size(162, 28);
            this.id_box.TabIndex = 43;
            // 
            // Musicos_label
            // 
            this.Musicos_label.AutoSize = true;
            this.Musicos_label.Font = new System.Drawing.Font("OCR A Extended", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Musicos_label.Location = new System.Drawing.Point(82, 5);
            this.Musicos_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Musicos_label.Name = "Musicos_label";
            this.Musicos_label.Size = new System.Drawing.Size(115, 29);
            this.Musicos_label.TabIndex = 42;
            this.Musicos_label.Text = "Alunos";
            // 
            // list_alunos
            // 
            this.list_alunos.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_alunos.FormattingEnabled = true;
            this.list_alunos.ItemHeight = 17;
            this.list_alunos.Location = new System.Drawing.Point(13, 37);
            this.list_alunos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.list_alunos.Name = "list_alunos";
            this.list_alunos.Size = new System.Drawing.Size(298, 463);
            this.list_alunos.TabIndex = 41;
            this.list_alunos.SelectedIndexChanged += new System.EventHandler(this.list_alunos_SelectedIndexChanged);
            // 
            // Aluno_atribuir_Instrumento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 574);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.Confirmar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.farda_label);
            this.Controls.Add(this.prof_box);
            this.Controls.Add(this.tele_label);
            this.Controls.Add(this.tele_box);
            this.Controls.Add(this.data_label);
            this.Controls.Add(this.data_box);
            this.Controls.Add(this.naipe_label);
            this.Controls.Add(this.naipe_box);
            this.Controls.Add(this.nome_label);
            this.Controls.Add(this.nome_box);
            this.Controls.Add(this.nif_label);
            this.Controls.Add(this.id_box);
            this.Controls.Add(this.Musicos_label);
            this.Controls.Add(this.list_alunos);
            this.Name = "Aluno_atribuir_Instrumento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aluno_atribuir_Instrumento";
            this.Load += new System.EventHandler(this.Aluno_atribuir_Instrumento_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button Confirmar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label farda_label;
        private System.Windows.Forms.TextBox prof_box;
        private System.Windows.Forms.Label tele_label;
        private System.Windows.Forms.TextBox tele_box;
        private System.Windows.Forms.Label data_label;
        private System.Windows.Forms.TextBox data_box;
        private System.Windows.Forms.Label naipe_label;
        private System.Windows.Forms.TextBox naipe_box;
        private System.Windows.Forms.Label nome_label;
        private System.Windows.Forms.TextBox nome_box;
        private System.Windows.Forms.Label nif_label;
        private System.Windows.Forms.TextBox id_box;
        private System.Windows.Forms.Label Musicos_label;
        private System.Windows.Forms.ListBox list_alunos;
    }
}