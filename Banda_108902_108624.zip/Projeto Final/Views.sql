

go
CREATE VIEW Banda.FardasDisponiveis
AS
SELECT f.*
FROM Banda.Farda f
LEFT JOIN Banda.Musico m ON f.id = m.farda_id
WHERE m.farda_id IS NULL;
go
