CREATE TABLE Banda.Instrumento (
    Identificador INT NOT NULL IDENTITY PRIMARY KEY,
    Data_Compra DATE,
    Modelo VARCHAR(50),
    Tipo_Instrumento VARCHAR(50) NOT NULL
)

CREATE TABLE Banda.Farda (
    id INT NOT NULL IDENTITY,
    tamanho VARCHAR(50),
    estado VARCHAR(50),
    constraint PK_Farda primary key(id)
)

CREATE TABLE Banda.Musico (
    NIF INT,
    nome VARCHAR(100) NOT NULL,
    data_de_nascimento DATE NOT NULL,
    naipe VARCHAR(50),
    telefone INT NOT NULL CHECK (telefone < 999999999 AND telefone > 900000000),
    farda_id INT NULL,
    CONSTRAINT PK_Musico PRIMARY KEY (NIF),
	constraint FK_Farda foreign key(farda_id) references Banda.Farda(id)
)


CREATE TABLE Banda.Professor (
	NIF INT,
	nome VARCHAR(100) NOT NULL,
	data_de_nascimento DATE NOT NULL,
	tipo_instrumento VARCHAR(50),
	telefone INT NOT NULL check (telefone<999999999 and telefone>900000000),
	ordenado float,
	constraint PK_Professor primary key(NIF)
)

CREATE TABLE Banda.Aluno(
	NIF INT,
	nome VARCHAR(100) NOT NULL,
	data_de_nascimento DATE NOT NULL,
	naipe VARCHAR(50),
	telefone INT NOT NULL check (telefone<999999999 and telefone>900000000),
	NIF_Professor INT,
	constraint PK_Aluno primary key(NIF),
	constraint FK_Professor foreign key(NIF_Professor) references Banda.Professor(NIF)
)

CREATE TABLE Banda.Pessoa_Instrumento (
    identificador_Instrumento INT,
    NIF_Musico INT NULL,
    NIF_Aluno INT NULL,
    CONSTRAINT FK_Instrumento FOREIGN KEY (identificador_Instrumento) REFERENCES Banda.Instrumento (Identificador),
    CONSTRAINT FK_Musico FOREIGN KEY (NIF_Musico) REFERENCES Banda.Musico (NIF),
    CONSTRAINT FK_Aluno FOREIGN KEY (NIF_Aluno) REFERENCES Banda.Aluno (NIF),
    CONSTRAINT CHK_Relacionamento_Exclusivo CHECK (
        (NIF_Musico IS NOT NULL AND NIF_Aluno IS NULL) OR
        (NIF_Musico IS NULL AND NIF_Aluno IS NOT NULL) OR
		(NIF_Musico IS NULL AND NIF_Aluno IS NULL)
    )
)

CREATE TABLE Banda.Tipo_servico (
  tipo_servico VARCHAR(100) NOT NULL,
  constraint PK_Tipo_Servico primary key(tipo_servico)
)


CREATE TABLE Banda.Servico (
    id INT NOT NULL IDENTITY,
    nome VARCHAR(100) NOT NULL,
    localidade VARCHAR(100) NOT NULL,
    preco INT NOT NULL,
    hora_ini  TIME NOT NULL,
    data_servico Date NOT NULL,
    pagamento_por_musico DECIMAL(10, 2) NOT NULL,
    constraint PK_servico primary key(id)
)

CREATE TABLE Banda.Tipos_por_Servico (
    id_servico INT,
    tipo_servico VARCHAR(100) NOT NULL,
    constraint FK_Servico foreign key (id_servico) references Banda.Servico(id),
    constraint FK_Tipo_Servico foreign key (tipo_servico) references Banda.Tipo_servico(tipo_servico)
)

CREATE TABLE Banda.Reforco (
	NIF INT,
	nome VARCHAR(100) NOT NULL,
	naipe VARCHAR(100),
	telefone INT NOT NULL check (telefone<999999999 and telefone>900000000),
	constraint PK_Reforco primary key(NIF)
)

CREATE TABLE Banda.Reforco_Servico(
	NIF_Reforco int,
	id_servico int,
        preco float NULL,
	constraint FK_Reforco foreign key(NIF_Reforco) references Banda.Reforco(NIF),
	constraint FK_Servico_Reforco foreign key(id_servico) references Banda.Servico(id)
)

CREATE TABLE Banda.Servico_Musico(
	id_servico INT,
    NIF_musico INT NOT NULL,
    constraint FK_MusicoServico foreign key (NIF_musico) references Banda.Musico(NIF),
    constraint FK_Servico_Musico foreign key (id_servico) references Banda.Servico(id)
)

CREATE TABLE Banda.Direcao (
	NIF INT,
	nome VARCHAR(100) NOT NULL,
	data_de_nascimento DATE NOT NULL,
	telefone INT NOT NULL check (telefone<999999999 and telefone>900000000),
	email VARCHAR(100) NOT NULL check (email LIKE '%_@__%.__%'),
	cargo VARCHAR(20) NOT NULL,
	constraint PK_Direcao primary key(NIF)
)

CREATE TABLE Banda.Servico_Direcao(
    NIF_diretor INT,
    id_servico INT NOT NULL,
    constraint FK_Direcao foreign key (NIF_diretor) references Banda.Direcao(NIF),
    constraint FK_Servico_Direcao foreign key (id_servico) references Banda.Servico(ID)
)

CREATE TABLE Banda.Socio (
	NIF INT,
	nome VARCHAR(100) NOT NULL,
	telefone INT NOT NULL check (telefone<999999999 and telefone>900000000),
	email VARCHAR(100) NOT NULL check (email LIKE '%_@__%.__%'),
	constraint PK_Socio primary key (NIF)
)

CREATE TABLE Banda.Cota (
    ano INT CHECK (ano >= 1900 AND ano <= YEAR(GETDATE())),
    valor INT NOT NULL,
    NIF_do_emissor INT,
    constraint PK_Cota primary key (Ano),
    constraint FK_Direcao_Cota foreign key(NIF_do_emissor) references Banda.Direcao(NIF)
)

CREATE TABLE Banda.Cota_Socio (
    NIF_Socio INT,
    Ano_Cota INT,
    Data_do_pagamento Date NULL, 
    constraint FK_Socio foreign key (NIF_Socio) references Banda.Socio(NIF),
    constraint FK_Cota foreign key (Ano_Cota) references Banda.Cota(Ano)
)

