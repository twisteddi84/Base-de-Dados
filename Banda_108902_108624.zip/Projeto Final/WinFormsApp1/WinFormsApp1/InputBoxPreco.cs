﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class InputBoxPreco : Form
    {
        private int Nif_ref;
        public InputBoxPreco(int NIF_ref)
        {
            InitializeComponent();
            Nif_ref = NIF_ref;
        }

        private void pag_musi_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void InputBoxPreco_Load(object sender, EventArgs e)
        {
            nif_Ref.Text = Nif_ref.ToString();
        }

        private void OK_Click(object sender, EventArgs e)
        {
            if(preco_box.Text == "")
            {
                MessageBox.Show("Introduza um valor!");
            }
            try
            {
                double preco = float.Parse(preco_box.Text);
                Close();
            }
            catch
            {
                MessageBox.Show("Valor inválido.");
            }
        }

        public float getPreco()
        {
            return float.Parse(preco_box.Text);
        }
    }
}
