﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
   
    public partial class Reforcos : Form
    {
        private SqlConnection cn;
        private int currentContact;
        private bool adding;
        public Reforcos()
        {
            InitializeComponent();
        }

        private void nome_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void nome_label_Click(object sender, EventArgs e)
        {

        }

        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }

        private void Reforcos_Load(object sender, EventArgs e)
        {
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Reforco ", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            list_reforcos.Items.Clear();

            while (reader.Read())
            {
                Reforco i = new Reforco();
                i.NIF = (int)reader["NIF"];
                i.Nome = reader["nome"].ToString();
                i.Naipe = reader["naipe"].ToString();
                i.Telefone = (int)reader["telefone"];
               

                list_reforcos.Items.Add(i);
            }

            reader.Close();

            cn.Close();


            currentContact = 0;
            ShowContact();
        }

        public void ShowContact()
        {
            if (list_reforcos.Items.Count == 0 | currentContact < 0)
                return;
            Reforco i = new Reforco();
            i = (Reforco)list_reforcos.Items[currentContact];
            id_box.Text = i.NIF.ToString();
            nome_box.Text = i.Nome;
            naipe_box.Text = i.Naipe;
            tele_box.Text = i.Telefone.ToString();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;
        }

        private void list_reforcos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_reforcos.SelectedIndex >= 0)
            {
                currentContact = list_reforcos.SelectedIndex;
                ShowContact();
            }
        }

        private void Atualizar_Click(object sender, EventArgs e)
        {
            currentContact = list_reforcos.SelectedIndex;
            if (currentContact <= 0)
            {
                //MessageBox.Show("Please select a contact to edit");
                currentContact = 1;
                //return;
            }
            button2.Visible = false;
            adding = false;
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_reforcos.Enabled = false;
        }
        public void ClearFields()
        {
            id_box.Text = "";
            naipe_box.Text = "";
            nome_box.Text = "";
            tele_box.Text = "";

        }

        public void UnlockControls()
        {
            id_box.ReadOnly = false;
            nome_box.ReadOnly = false;
            naipe_box.ReadOnly = false;
            tele_box.ReadOnly = false;
        }

        public void LockControls()
        {
            id_box.ReadOnly = true;
            nome_box.ReadOnly = true;
            naipe_box.ReadOnly = true;
            tele_box.ReadOnly = true;
        }

        public void HideButtons()
        {
            UnlockControls();
            Add.Visible = false;
            Atualizar.Visible = false;
            Remover.Visible = false;
        }


        public void ShowButtons()
        {
            LockControls();
            Add.Visible = true;
            Atualizar.Visible = true;
            Remover.Visible = true;
        }

        private void Add_Click(object sender, EventArgs e)
        {
            adding = true;
            ClearFields();
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            button2.Visible = false;
            list_reforcos.Enabled = false;
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            list_reforcos.Enabled = true;
            if (list_reforcos.Items.Count > 0)
            {
                currentContact = list_reforcos.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }

        private bool SaveReforco()
        {
            Reforco i = new Reforco();

            try
            {
                i.NIF = int.Parse(id_box.Text);
                i.Nome = nome_box.Text;
                i.Telefone = int.Parse(tele_box.Text);
                i.Naipe = naipe_box.Text;
                //if (adding)
                //{
                    
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            if (adding)
            {
                SubmitContact(i);
                list_reforcos.Items.Add(i);
            }
            else
            {
                UpdateReforco(i);
                list_reforcos.Items[currentContact] = i;
            }
            return true;
        }

        private void UpdateReforco(Reforco C)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();
           
            cmd.CommandText = "Banda.UpdateReforco";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", C.NIF);
            cmd.Parameters.AddWithValue("@Nome", C.Nome);
            cmd.Parameters.AddWithValue("@Naipe", C.Naipe);
            cmd.Parameters.AddWithValue("@Telefone", C.Telefone);
         
            cmd.Connection = cn;

            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                if (rows == 1)
                    MessageBox.Show("Update OK");
                else
                    MessageBox.Show("Update NOT Ok");
            }
        }

        private void SubmitContact(Reforco C)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.InsertReforco";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", C.NIF);
            cmd.Parameters.AddWithValue("@Nome", C.Nome);
            cmd.Parameters.AddWithValue("@Naipe", C.Naipe);
            cmd.Parameters.AddWithValue("@Telefone", C.Telefone);


            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                SaveReforco();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            list_reforcos.Enabled = true;
            int idx = list_reforcos.FindString(id_box.Text);
            list_reforcos.SelectedIndex = idx;
            Reforcos_Load(sender, e);
            ShowButtons();
            Confirmar.Visible = false;
            Cancelar.Visible = false;
        }

        private void tele_label_Click(object sender, EventArgs e)
        {

        }

        private void tele_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void naipe_label_Click(object sender, EventArgs e)
        {

        }

        private void naipe_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void nif_label_Click(object sender, EventArgs e)
        {

        }

        private void id_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void Musicos_label_Click(object sender, EventArgs e)
        {

        }
        private void RemoveContact(int NIF)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "DELETE Banda.Reforco WHERE NIF=@NIF";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", NIF);
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to delete contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            if (list_reforcos.SelectedIndex > -1)
            {
                try
                {
                    RemoveContact(((Reforco)list_reforcos.SelectedItem).NIF);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                list_reforcos.Items.RemoveAt(list_reforcos.SelectedIndex);
                if (currentContact == list_reforcos.Items.Count)
                    currentContact = list_reforcos.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more contacts");
                }
                else
                {
                    ShowContact();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Servicos_por_reforco spr = new Servicos_por_reforco(int.Parse(id_box.Text));
            spr.Show();

        }
    }
}
