﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            musicos h = new musicos();
            h.Show();
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Instrumentos i = new Instrumentos();
            i.Show();
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Socios s = new Socios();
            s.Show();
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Fardas f = new Fardas();
            f.Show();
            Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Servicos s = new Servicos();
            s.Show();
            Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Alunos al = new Alunos();
            al.Show();
            Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Professores p = new Professores();
            p.Show();
            Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Reforcos r = new Reforcos();
            r.Show();
            Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Cotas c = new Cotas();
            c.Show();
            Close();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Diretores d = new Diretores();
            d.Show();
            Close();
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            Close();
        }
    }
}
