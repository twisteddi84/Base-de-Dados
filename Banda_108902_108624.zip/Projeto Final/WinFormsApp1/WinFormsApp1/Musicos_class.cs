﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
	class Musicos_class
	{
		private int _NIF;
		private DateTime _dataNasc;
		private String _nome;
		private String _naipe;
		private int _telefone;
		private int? _farda_id;
		public int NIF
		{
			get { return _NIF; }
			set { _NIF = value; }
		}

		public int Telefone
		{
			get { return _telefone; }
			set { _telefone = value; }
		}

		public int? FardaID
        {
            get { return _farda_id; }
			set { _farda_id = value;  }
        }

		public String Nome
		{
			get { return _nome; }
			set
			{
				if (value == null | String.IsNullOrEmpty(value))
				{
					throw new Exception(" field can’t be empty");
					return;
				}
				_nome = value;
			}
		}

		public String Naipe
		{
			get { return _naipe; }
			set { _naipe = value; }
		}

		public DateTime DataNasc
		{
			get { return _dataNasc; }
			set { _dataNasc = value; }
		}




		public override String ToString()
		{
			return _NIF + "   " + _nome;
		}

		public Musicos_class() : base()
		{
		}

		public Musicos_class(int NIF, DateTime datanasc, String nome, String naipe, int telefone, int farda_id) : base()
		{
			this._NIF = NIF;
			this._dataNasc = datanasc;
			this._nome = nome;
			this._naipe = naipe;
			this._telefone = telefone;
			this._farda_id = farda_id;
		}

		public Musicos_class(int NIF, String nome) : base()
		{
			this._NIF = NIF;
			this._nome = nome;

		}

		public Musicos_class(int NIF, DateTime datanasc, String nome, String naipe, int telefone) : base()
		{
			this._NIF = NIF;
			this._dataNasc = datanasc;
			this._nome = nome;
			this._naipe = naipe;
			this._telefone = telefone;
		}
	}
}
