﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Servicos_por_reforco : Form
    {
        private SqlConnection cn;
        private int currentContact;
        private bool adding;
        private int NIF_ref;
        public Servicos_por_reforco(int NIF)
        {
            NIF_ref = NIF;
            InitializeComponent();
        }
        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }
        private void Servicos_por_reforco_Load(object sender, EventArgs e)
        {
            ServRef_label.Text = "Serviços do reforço: " + NIF_ref.ToString();
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;
            try
            {


                SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.GetNameService(@NIF)", cn);
                cmd.Parameters.AddWithValue("@NIF", NIF_ref);
                SqlDataReader reader = cmd.ExecuteReader();



                list_servicos.Items.Clear();

                while (reader.Read())
                {
                    ServRef i = new ServRef();
                    i.ID_ser = (int)reader["id"];
                    i.Preco = (float)(double)reader["preco"];
                    i.Nome = reader["nome"].ToString();
                    i.Localidade = reader["localidade"].ToString();
                    list_servicos.Items.Add(i);
                }
                reader.Close();
                cn.Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            currentContact = 0;
            ShowContact();

        }

        public void ShowContact()
        {
            if (list_servicos.Items.Count == 0 || currentContact < 0)
                return;

            ServRef i = (ServRef)list_servicos.Items[currentContact];
            id_box.Text = i.ID_ser.ToString();
            preco_box.Text = i.Preco.ToString();
            nome_box.Text = i.Nome;
            loca_box.Text = i.Localidade;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void list_servicos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_servicos.SelectedIndex >= 0)
            {
                currentContact = list_servicos.SelectedIndex;
                ShowContact();
            }
        }

        private void Musicos_label_Click(object sender, EventArgs e)
        {
            
        }
    }
}
