

-- Banda.Cota_Socio
CREATE INDEX IDX_CotaSocio_NIF_Socio ON Banda.Cota_Socio (NIF_Socio);

-- Banda.Cota
CREATE INDEX IDX_Cota_Ano ON Banda.Cota (ano);

-- Banda.Musico
CREATE INDEX IDX_Musico_Farda_ID ON Banda.Musico (farda_id);

-- Banda.Pessoa_Instrumento
CREATE INDEX IDX_PessoaInstrumento_NIF_Musico ON Banda.Pessoa_Instrumento (NIF_Musico);
CREATE INDEX IDX_PessoaInstrumento_NIF_Aluno ON Banda.Pessoa_Instrumento (NIF_Aluno);

-- Banda.Servico_Musico
CREATE INDEX IDX_ServicoMusico_ID_Servico ON Banda.Servico_Musico (id_servico);