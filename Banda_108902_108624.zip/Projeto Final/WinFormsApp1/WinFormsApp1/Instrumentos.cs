﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Instrumentos : Form
    {
        private SqlConnection cn;
        private int currentContact;
        private bool adding;
        public Instrumentos()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }



        private void Instrumentos_Load(object sender, EventArgs e)
        {
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Instrumento", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            listBox1.Items.Clear();

            while (reader.Read())
            {
                Instrumento i = new Instrumento();
                i.ID = reader["Identificador"].ToString();
                i.DataCompra = (DateTime)reader["Data_Compra"];
                i.Modelo = reader["Modelo"].ToString();
                i.TipoInstrumento = reader["Tipo_Instrumento"].ToString();

                listBox1.Items.Add(i);
            }

            currentContact = 0;
            reader.Close();
            ShowContact();
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
            {
                cn.Open();
                return true; // Return true when the connection is successfully opened
            }

            return true; // Return true when the connection state is already open
        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                currentContact = listBox1.SelectedIndex;
                ShowContact();
            }
        }

        public void ShowContact()
        {
            if (listBox1.Items.Count == 0 || currentContact < 0)
                return;

            Instrumento i = (Instrumento)listBox1.Items[currentContact];
            textBoxID.Text = i.ID;
            textBoxDataCompra.Text = i.DataCompra.ToString("yyyy-MM-dd");
            textBoxModelo.Text = i.Modelo;
            textBoxTipoInstrumento.Text = i.TipoInstrumento;

            cn = DatabaseManager.GetConnection();

            using (SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.GetNIFsPessoaInstrumento(@InstrumentoID)", cn))
            {
                cmd.Parameters.AddWithValue("@InstrumentoID", i.ID);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int nifMusico = reader["NIF_Musico"] != DBNull.Value ? (int)reader["NIF_Musico"] : 0;
                        int nifAluno = reader["NIF_Aluno"] != DBNull.Value ? (int)reader["NIF_Aluno"] : 0;

                        if (nifMusico != 0)
                        {
                            // Fetch musician details and display in TextBox
                            reader.Close();
                            Musicos_class musico = FetchMusicoDetails(nifMusico);
                            if (musico != null)
                            {
                                button4.Visible = true;
                                button4.Text = "Remover Músico";
                                aluno_musico.Text = "Músico:";
                                label5.Visible = true;
                                label3.Visible = true;
                                NIF.Visible = true;
                                Nome.Visible = true;
                                NIF.Text = nifMusico.ToString(); // Display NIF in textBox5
                                Nome.Text = musico.Nome; // Display name in textBox4
                                button2.Visible = false;
                                button3.Visible = false;
                            }
                        }
                        else if (nifAluno != 0)
                        {
                            // Fetch student details and display in TextBox
                            reader.Close();
                            Aluno aluno = FetchAlunoDetails(nifAluno);
                            if (aluno != null)
                            {
                                button4.Visible = true;
                                button4.Text = "Remover Aluno";
                                aluno_musico.Text = "Aluno:";
                                label5.Visible = true;
                                label3.Visible = true;
                                NIF.Visible = true;
                                Nome.Visible = true;
                                NIF.Text = nifAluno.ToString(); // Display NIF in textBox5
                                Nome.Text = aluno.Nome; // Display name in textBox4
                                button2.Visible = false;
                                button3.Visible = false;
                            }
                        }
                        else
                        {
                            button4.Visible = false;
                            aluno_musico.Text = "Instrumento Disponível";
                            label5.Visible = false;
                            label3.Visible = false;
                            NIF.Visible = false;
                            Nome.Visible = false;
                            button2.Visible = true;
                            button3.Visible = true;
                        }
                    }
                    else
                    {
                        button4.Visible = false;
                        aluno_musico.Text = "Instrumento Disponível";
                        label5.Visible = false;
                        label3.Visible = false;
                        NIF.Visible = false;
                        Nome.Visible = false;
                        button2.Visible = true;
                        button3.Visible = true;
                    }

                    reader.Close(); // Close the SqlDataReader
                }
            }
        }

        private Musicos_class FetchMusicoDetails(int nifMusico)
        {
            Musicos_class musico = null;

            using (SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.GetMusicoByNIF(@NIF)", cn))
            {
                cmd.Parameters.AddWithValue("@NIF", nifMusico);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int nif = (int)reader["NIF"];
                        string nome = reader["Nome"].ToString();

                        musico = new Musicos_class(nif, nome);
                    }

                    reader.Close(); // Close the SqlDataReader
                }
            }

            return musico;
        }

        private Aluno FetchAlunoDetails(int nifAluno)
        {
            Aluno aluno = null;

            using (SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.GetAlunoByNIF(@NIF)", cn))
            {
                cmd.Parameters.AddWithValue("@NIF", nifAluno);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int nif = (int)reader["NIF"];
                        DateTime dataNasc = (DateTime)reader["data_de_nascimento"];
                        string nome = reader["nome"].ToString();
                        // Add additional properties specific to Aluno class

                        aluno = new Aluno(nif, nome);
                        // Set additional properties specific to Aluno class
                    }

                    reader.Close(); // Close the SqlDataReader
                }
            }

            return aluno;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void aluno_musico_Click(object sender, EventArgs e)
        {

        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                SaveInstrumento();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            listBox1.Enabled = true;
            int idx = listBox1.FindString(textBoxID.Text);
            listBox1.SelectedIndex = idx;
            ShowButtons();
            Instrumentos_Load(sender, e);
            aluno_musico.Visible = true;
            label5.Visible = true;
            label3.Visible = true;
            NIF.Visible = true;
            Nome.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
        }

        public void ShowButtons()
        {
            LockControls();
            Add.Visible = true;
            Atualizar.Visible = true;
            Remover.Visible = true;
        }
        public void LockControls()
        {
            textBoxID.ReadOnly = true;
            textBoxModelo.ReadOnly = true;
            textBoxTipoInstrumento.ReadOnly = true;
            textBoxDataCompra.ReadOnly = true;
        }

        private bool SaveInstrumento()
        {
            Instrumento i = new Instrumento();
            try
            {
                i.ID = textBoxID.Text;
                i.DataCompra = DateTime.Parse(textBoxDataCompra.Text);
                i.Modelo = textBoxModelo.Text;
                i.TipoInstrumento = textBoxTipoInstrumento.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            if (adding)
            {
                SubmitInstrumento(i);
                listBox1.Items.Add(i);
            }
            else
            {
                UpdateInstrumento(i);
                listBox1.Items[currentContact] = i;
            }
            return true;
        }

        private void UpdateInstrumento(Instrumento C)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.UpdateInstrumento";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ID", C.ID);
            cmd.Parameters.AddWithValue("@Data", C.DataCompra);
            cmd.Parameters.AddWithValue("@Modelo", C.Modelo);
            cmd.Parameters.AddWithValue("@Tipo", C.TipoInstrumento);
            cmd.Connection = cn;

            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                if (rows == 1)
                    MessageBox.Show("Update OK");
                else
                    MessageBox.Show("Update NOT Ok");
            }
        }

        private void SubmitInstrumento(Instrumento C)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.InsertInstrumento";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@Data", C.DataCompra);
            cmd.Parameters.AddWithValue("@Modelo", C.Modelo);
            cmd.Parameters.AddWithValue("@Tipo", C.TipoInstrumento);


            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            button4.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            aluno_musico.Visible = false;
            label5.Visible = false;
            label3.Visible = false;
            NIF.Visible = false;
            Nome.Visible = false;
            adding = true;
            ClearFields();
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            listBox1.Enabled = false;
        }

        public void ClearFields()
        {
            textBoxID.Text = "";
            textBoxModelo.Text = "";
            textBoxDataCompra.Text = "";
            textBoxTipoInstrumento.Text = "";

        }
        public void HideButtons()
        {
            UnlockControls();
            Add.Visible = false;
            Atualizar.Visible = false;
            Remover.Visible = false;
        }
        public void UnlockControls()
        {
            textBoxModelo.ReadOnly = false;
            textBoxDataCompra.ReadOnly = false;
            textBoxTipoInstrumento.ReadOnly = false;
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex > -1)
            {
                try
                {
                    RemoveInstrumento(((Instrumento)listBox1.SelectedItem).ID);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
                if (currentContact == listBox1.Items.Count)
                    currentContact = listBox1.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more contacts");
                }
                else
                {
                    ShowContact();
                }
            }
        }
        private void RemoveInstrumento(String ID)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "DELETE Banda.Instrumento WHERE Identificador=@ID ";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to delete contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            button3.Visible = false;
            aluno_musico.Visible = true;
            label5.Visible = true;
            label3.Visible = true;
            NIF.Visible = true;
            Nome.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            listBox1.Enabled = true;
            if (listBox1.Items.Count > 0)
            {
                currentContact = listBox1.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }

        private void Atualizar_Click(object sender, EventArgs e)
        {
            currentContact = listBox1.SelectedIndex;
            if (currentContact <= 0)
            {
                //MessageBox.Show("Please select a contact to edit");
                currentContact = 1;
                //return;
            }
            button4.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            aluno_musico.Visible = false;
            label5.Visible = false;
            label3.Visible = false;
            NIF.Visible = false;
            Nome.Visible = false;
            adding = false;
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            listBox1.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Musico_atribuir_Instrumento m = new Musico_atribuir_Instrumento(textBoxID.Text);
            m.Show();
            Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "DELETE Banda.Pessoa_Instrumento WHERE identificador_Instrumento=@ID ";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ID", int.Parse(textBoxID.Text));
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Falha a remover. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                Instrumentos_Load(sender,e);
                cn.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Aluno_atribuir_Instrumento a = new Aluno_atribuir_Instrumento(textBoxID.Text);
            a.Show();
            Close();
        }
    }
}
