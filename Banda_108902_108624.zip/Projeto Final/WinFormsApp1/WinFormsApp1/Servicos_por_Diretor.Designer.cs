﻿
namespace WinFormsApp1
{
    partial class Servicos_por_Diretor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.loca_box = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nome_box = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.id_label = new System.Windows.Forms.Label();
            this.id_box = new System.Windows.Forms.TextBox();
            this.ServRef_label = new System.Windows.Forms.Label();
            this.list_servicos = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(308, 205);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 24);
            this.label1.TabIndex = 74;
            this.label1.Text = "LOCALIDADE:";
            // 
            // loca_box
            // 
            this.loca_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.loca_box.Location = new System.Drawing.Point(492, 205);
            this.loca_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.loca_box.Name = "loca_box";
            this.loca_box.ReadOnly = true;
            this.loca_box.Size = new System.Drawing.Size(366, 28);
            this.loca_box.TabIndex = 73;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(308, 158);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 24);
            this.label2.TabIndex = 72;
            this.label2.Text = "NOME:";
            // 
            // nome_box
            // 
            this.nome_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_box.Location = new System.Drawing.Point(402, 157);
            this.nome_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.nome_box.Name = "nome_box";
            this.nome_box.ReadOnly = true;
            this.nome_box.Size = new System.Drawing.Size(349, 28);
            this.nome_box.TabIndex = 71;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(738, 435);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 40);
            this.button1.TabIndex = 70;
            this.button1.Text = "VOLTAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_label.Location = new System.Drawing.Point(308, 106);
            this.id_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(52, 24);
            this.id_label.TabIndex = 67;
            this.id_label.Text = "ID:";
            // 
            // id_box
            // 
            this.id_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_box.Location = new System.Drawing.Point(380, 106);
            this.id_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.id_box.Name = "id_box";
            this.id_box.ReadOnly = true;
            this.id_box.Size = new System.Drawing.Size(162, 28);
            this.id_box.TabIndex = 66;
            // 
            // ServRef_label
            // 
            this.ServRef_label.AutoSize = true;
            this.ServRef_label.Font = new System.Drawing.Font("OCR A Extended", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ServRef_label.Location = new System.Drawing.Point(72, 14);
            this.ServRef_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ServRef_label.Name = "ServRef_label";
            this.ServRef_label.Size = new System.Drawing.Size(149, 29);
            this.ServRef_label.TabIndex = 65;
            this.ServRef_label.Text = "Serviços";
            this.ServRef_label.Click += new System.EventHandler(this.ServRef_label_Click);
            // 
            // list_servicos
            // 
            this.list_servicos.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_servicos.FormattingEnabled = true;
            this.list_servicos.ItemHeight = 17;
            this.list_servicos.Location = new System.Drawing.Point(2, 44);
            this.list_servicos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.list_servicos.Name = "list_servicos";
            this.list_servicos.Size = new System.Drawing.Size(298, 463);
            this.list_servicos.TabIndex = 64;
            this.list_servicos.SelectedIndexChanged += new System.EventHandler(this.list_servicos_SelectedIndexChanged);
            // 
            // Servicos_por_Diretor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 483);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.loca_box);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nome_box);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.id_label);
            this.Controls.Add(this.id_box);
            this.Controls.Add(this.ServRef_label);
            this.Controls.Add(this.list_servicos);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Servicos_por_Diretor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Servicos_por_Diretor";
            this.Load += new System.EventHandler(this.Servicos_por_Diretor_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox loca_box;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nome_box;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label preco_label;
        private System.Windows.Forms.TextBox preco_box;
        private System.Windows.Forms.Label id_label;
        private System.Windows.Forms.TextBox id_box;
        private System.Windows.Forms.Label ServRef_label;
        private System.Windows.Forms.ListBox list_servicos;
    }
}