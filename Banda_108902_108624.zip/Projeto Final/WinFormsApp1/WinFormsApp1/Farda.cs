﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    class Farda
    {
        private String _ID;
        private String _tamanho;
        private String _estado;

        public String ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        public String Tamanho
        {
            get { return _tamanho; }
            set { _tamanho = value; }
        }

        public String Estado
        {
            get { return _estado; }
            set { _estado = value; }
        }

        public override String ToString()
        {
            return _ID + " " + _tamanho;
        }

        public Farda() : base()
        {
        }

        public Farda(String ID, String tamanho, String estado) : base()
        {
            this._ID = ID;
            this._tamanho = tamanho;
            this._estado = estado;

        }

        public Farda( String tamanho, String estado) : base()
        {
            this._tamanho = tamanho;
            this._estado = estado;

        }

    }

}
