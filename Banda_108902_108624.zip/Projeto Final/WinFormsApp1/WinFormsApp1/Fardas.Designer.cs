﻿
namespace WinFormsApp1
{
    partial class Fardas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancelar = new System.Windows.Forms.Button();
            this.Confirmar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.estado_label = new System.Windows.Forms.Label();
            this.estado_box = new System.Windows.Forms.TextBox();
            this.Tamanho_label = new System.Windows.Forms.Label();
            this.tamanho_box = new System.Windows.Forms.TextBox();
            this.id_label = new System.Windows.Forms.Label();
            this.id_box = new System.Windows.Forms.TextBox();
            this.Musicos_label = new System.Windows.Forms.Label();
            this.list_fardas = new System.Windows.Forms.ListBox();
            this.Remover = new System.Windows.Forms.Button();
            this.Atualizar = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Cancelar
            // 
            this.Cancelar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cancelar.Location = new System.Drawing.Point(653, 338);
            this.Cancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(128, 40);
            this.Cancelar.TabIndex = 38;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // Confirmar
            // 
            this.Confirmar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Confirmar.Location = new System.Drawing.Point(452, 338);
            this.Confirmar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Confirmar.Name = "Confirmar";
            this.Confirmar.Size = new System.Drawing.Size(128, 40);
            this.Confirmar.TabIndex = 37;
            this.Confirmar.Text = "Confirmar";
            this.Confirmar.UseVisualStyleBackColor = true;
            this.Confirmar.Click += new System.EventHandler(this.Confirmar_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(870, 26);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 40);
            this.button1.TabIndex = 36;
            this.button1.Text = "HOME";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // estado_label
            // 
            this.estado_label.AutoSize = true;
            this.estado_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.estado_label.Location = new System.Drawing.Point(425, 206);
            this.estado_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.estado_label.Name = "estado_label";
            this.estado_label.Size = new System.Drawing.Size(108, 24);
            this.estado_label.TabIndex = 29;
            this.estado_label.Text = "ESTADO:";
            // 
            // estado_box
            // 
            this.estado_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.estado_box.Location = new System.Drawing.Point(550, 206);
            this.estado_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.estado_box.Name = "estado_box";
            this.estado_box.ReadOnly = true;
            this.estado_box.Size = new System.Drawing.Size(238, 28);
            this.estado_box.TabIndex = 28;
            // 
            // Tamanho_label
            // 
            this.Tamanho_label.AutoSize = true;
            this.Tamanho_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Tamanho_label.Location = new System.Drawing.Point(560, 142);
            this.Tamanho_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tamanho_label.Name = "Tamanho_label";
            this.Tamanho_label.Size = new System.Drawing.Size(122, 24);
            this.Tamanho_label.TabIndex = 27;
            this.Tamanho_label.Text = "TAMANHO:";
            // 
            // tamanho_box
            // 
            this.tamanho_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tamanho_box.Location = new System.Drawing.Point(699, 140);
            this.tamanho_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.tamanho_box.Name = "tamanho_box";
            this.tamanho_box.ReadOnly = true;
            this.tamanho_box.Size = new System.Drawing.Size(268, 28);
            this.tamanho_box.TabIndex = 26;
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_label.Location = new System.Drawing.Point(318, 140);
            this.id_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(52, 24);
            this.id_label.TabIndex = 25;
            this.id_label.Text = "ID:";
            // 
            // id_box
            // 
            this.id_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_box.Location = new System.Drawing.Point(389, 140);
            this.id_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.id_box.Name = "id_box";
            this.id_box.ReadOnly = true;
            this.id_box.Size = new System.Drawing.Size(162, 28);
            this.id_box.TabIndex = 24;
            this.id_box.TextChanged += new System.EventHandler(this.id_box_TextChanged);
            // 
            // Musicos_label
            // 
            this.Musicos_label.AutoSize = true;
            this.Musicos_label.Font = new System.Drawing.Font("OCR A Extended", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Musicos_label.Location = new System.Drawing.Point(81, 10);
            this.Musicos_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Musicos_label.Name = "Musicos_label";
            this.Musicos_label.Size = new System.Drawing.Size(115, 29);
            this.Musicos_label.TabIndex = 23;
            this.Musicos_label.Text = "Fardas";
            // 
            // list_fardas
            // 
            this.list_fardas.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_fardas.FormattingEnabled = true;
            this.list_fardas.ItemHeight = 17;
            this.list_fardas.Location = new System.Drawing.Point(12, 44);
            this.list_fardas.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.list_fardas.Name = "list_fardas";
            this.list_fardas.Size = new System.Drawing.Size(298, 463);
            this.list_fardas.TabIndex = 22;
            this.list_fardas.SelectedIndexChanged += new System.EventHandler(this.list_fardas_SelectedIndexChanged);
            // 
            // Remover
            // 
            this.Remover.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Remover.Location = new System.Drawing.Point(306, 525);
            this.Remover.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Remover.Name = "Remover";
            this.Remover.Size = new System.Drawing.Size(128, 40);
            this.Remover.TabIndex = 41;
            this.Remover.Text = "Remover";
            this.Remover.UseVisualStyleBackColor = true;
            this.Remover.Click += new System.EventHandler(this.Remover_Click);
            // 
            // Atualizar
            // 
            this.Atualizar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Atualizar.Location = new System.Drawing.Point(159, 525);
            this.Atualizar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Atualizar.Name = "Atualizar";
            this.Atualizar.Size = new System.Drawing.Size(128, 40);
            this.Atualizar.TabIndex = 40;
            this.Atualizar.Text = "Atualizar";
            this.Atualizar.UseVisualStyleBackColor = true;
            this.Atualizar.Click += new System.EventHandler(this.Atualizar_Click);
            // 
            // Add
            // 
            this.Add.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Add.Location = new System.Drawing.Point(12, 525);
            this.Add.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(128, 40);
            this.Add.TabIndex = 39;
            this.Add.Text = "Adicionar";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Fardas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(989, 574);
            this.Controls.Add(this.Remover);
            this.Controls.Add(this.Atualizar);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.Confirmar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.estado_label);
            this.Controls.Add(this.estado_box);
            this.Controls.Add(this.Tamanho_label);
            this.Controls.Add(this.tamanho_box);
            this.Controls.Add(this.id_label);
            this.Controls.Add(this.id_box);
            this.Controls.Add(this.Musicos_label);
            this.Controls.Add(this.list_fardas);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Fardas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fardas";
            this.Load += new System.EventHandler(this.Fardas_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button Confirmar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label estado_label;
        private System.Windows.Forms.TextBox estado_box;
        private System.Windows.Forms.Label Tamanho_label;
        private System.Windows.Forms.TextBox tamanho_box;
        private System.Windows.Forms.Label id_label;
        private System.Windows.Forms.TextBox id_box;
        private System.Windows.Forms.Label Musicos_label;
        private System.Windows.Forms.ListBox list_fardas;
        private System.Windows.Forms.Button Remover;
        private System.Windows.Forms.Button Atualizar;
        private System.Windows.Forms.Button Add;
    }
}