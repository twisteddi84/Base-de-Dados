﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class musicos : Form
    {

        private SqlConnection cn;
        private int currentContact;
        private bool adding;
        private List<Musicos_class> filteredItems = new List<Musicos_class>();
        public musicos()
        {
            InitializeComponent();

        }

        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_musicos.SelectedIndex >= 0)
            {
                currentContact = list_musicos.SelectedIndex;
                ShowContact();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void id_label_Click(object sender, EventArgs e)
        {

        }

        private void musicos_Load(object sender, EventArgs e)
        {
            checkBox1.Checked = true;
            button3.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Musico ", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            list_musicos.Items.Clear();

            while (reader.Read())
            {
                Musicos_class i = new Musicos_class();
                i.NIF = (int)reader["NIF"];
                i.DataNasc = (DateTime)reader["data_de_nascimento"];
                i.Nome = reader["nome"].ToString();
                i.Naipe = reader["naipe"].ToString();
                i.Telefone = (int)reader["telefone"];
                if (reader["farda_id"] != DBNull.Value)
                {
                    i.FardaID = (int)reader["farda_id"];
                }
                else
                {
                    i.FardaID = null; // Define o valor como nulo, dependendo da definição do tipo da propriedade FardaID em Musicos_class
                }
                filteredItems.Add(i);
                list_musicos.Items.Add(i);
            }

            cn.Close();


            currentContact = 0;
            ShowContact();

        }
        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }
        public void ShowContact()
        {
            if (list_musicos.Items.Count == 0 | currentContact < 0)
                return;
            Musicos_class i = new Musicos_class();
            i = (Musicos_class)list_musicos.Items[currentContact];
            id_box.Text = i.NIF.ToString();
            data_box.Text = i.DataNasc.ToString("yyyy-MM-dd");
            nome_box.Text = i.Nome;
            naipe_box.Text = i.Naipe;
            tele_box.Text = i.Telefone.ToString();
            if (i.FardaID == null)
            {
                button2.Visible = true;
                removerFardaBut.Visible = false;
                farda_box.Text = "Nao tem";
  
            }
            else
            {
                button2.Visible = false;
                removerFardaBut.Visible = true;
                farda_box.Text = i.FardaID.ToString();
            }
        }

        private void data_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void tele_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void data_label_Click(object sender, EventArgs e)
        {

        }

        private void tele_label_Click(object sender, EventArgs e)
        {

        }

        private void id_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void naipe_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pesquisa_box.Visible = false;
            checkBox1.Visible = false;
            checkBox2.Visible = false;
            button3.Visible = false;
            removerFardaBut.Visible = false;
            currentContact = list_musicos.SelectedIndex;
            if (currentContact <= 0)
            {
                //MessageBox.Show("Please select a contact to edit");
                currentContact = 1;
                //return;
            }
            button2.Visible = false;
            adding = false;
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_musicos.Enabled = false;
        }
        public void ClearFields()
        {
            id_box.Text = "";
            data_box.Text = "";
            nome_box.Text = "";
            naipe_box.Text = "";
            farda_box.Text = "";
            tele_box.Text = "";
        }

        public void UnlockControls()
        {
            id_box.ReadOnly = false;
            data_box.ReadOnly = false;
            nome_box.ReadOnly = false;
            naipe_box.ReadOnly = false;
            farda_box.ReadOnly = false;
            tele_box.ReadOnly = false;
        }

        public void LockControls()
        {
            id_box.ReadOnly = true;
            data_box.ReadOnly = true;
            nome_box.ReadOnly = true;
            naipe_box.ReadOnly = true;
            farda_box.ReadOnly = true;
            tele_box.ReadOnly = true;
        }

        public void HideButtons()
        {
            UnlockControls();
            Add.Visible = false;
            Atualizar.Visible = false;
            Remover.Visible = false;
        }


        public void ShowButtons()
        {
            LockControls();
            Add.Visible = true;
            Atualizar.Visible = true;
            Remover.Visible = true;
        }

        private void Add_Click(object sender, EventArgs e)
        {
            pesquisa_box.Visible = false;
            checkBox1.Visible = false;
            checkBox2.Visible = false;
            button3.Visible = false;
            removerFardaBut.Visible = false;
            farda_box.Visible = false;
            button2.Visible = false;
            adding = true;
            ClearFields();
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_musicos.Enabled = false;
        }



        private void Confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                SaveMusico();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                musicos_Load(sender, e);
            }
            pesquisa_box.Visible = true;
            checkBox1.Visible = true;
            checkBox2.Visible = true;
            list_musicos.Enabled = true;
            int idx = list_musicos.FindString(id_box.Text);
            list_musicos.SelectedIndex = idx;
            ShowButtons();
            farda_box.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
        }
        private bool SaveMusico()
        {
            Musicos_class i = new Musicos_class();
            try
            {
                if (adding || farda_box.Text == "Nao tem")
                {
                    i.NIF = int.Parse(id_box.Text);
                    i.DataNasc = DateTime.Parse(data_box.Text);
                    i.Nome = nome_box.Text;
                    i.Telefone = int.Parse(tele_box.Text);
                    i.Naipe = naipe_box.Text;
                }
                else
                {
                    i.NIF = int.Parse(id_box.Text);
                    i.DataNasc = DateTime.Parse(data_box.Text);
                    i.Nome = nome_box.Text;
                    i.Telefone = int.Parse(tele_box.Text);
                    i.Naipe = naipe_box.Text;
                    i.FardaID = int.Parse(farda_box.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            if (adding)
            {
                SubmitContact(i);
                list_musicos.Items.Add(i);
            }
            else
            {
                UpdateMusico(i);
                list_musicos.Items[currentContact] = i;
            }
            return true;
        }

        private void SubmitContact(Musicos_class C)
        {
            if (!verifySGBDConnection())
                return;

            using (SqlCommand cmd = new SqlCommand("Banda.InsertMusico", cn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@NIF", C.NIF);
                cmd.Parameters.AddWithValue("@Nome", C.Nome);
                cmd.Parameters.AddWithValue("@Data", C.DataNasc);
                cmd.Parameters.AddWithValue("@Naipe", C.Naipe);
                cmd.Parameters.AddWithValue("@Telefone", C.Telefone);

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
                }
            }
        }

        private void UpdateMusico(Musicos_class C)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();
            
            if (farda_box.Text == "Nao tem")
            {
                cmd.CommandText = "Banda.UpdateMusicoSemFarda";
                cmd.Parameters.Clear();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@NIF", C.NIF);
                cmd.Parameters.AddWithValue("@Nome", C.Nome);
                cmd.Parameters.AddWithValue("@Data", C.DataNasc);
                cmd.Parameters.AddWithValue("@Naipe", C.Naipe);
                cmd.Parameters.AddWithValue("@Telefone", C.Telefone);
            }
            else
            {
                cmd.CommandText = "Banda.UpdateMusicoComFarda";
                cmd.Parameters.Clear();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@NIF", C.NIF);
                cmd.Parameters.AddWithValue("@Nome", C.Nome);
                cmd.Parameters.AddWithValue("@Data", C.DataNasc);
                cmd.Parameters.AddWithValue("@Naipe", C.Naipe);
                cmd.Parameters.AddWithValue("@Telefone", C.Telefone);
                cmd.Parameters.AddWithValue("@FardaID", C.FardaID);
            }
            cmd.Connection = cn;

            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                if (rows == 1)
                    MessageBox.Show("Update OK");
                else
                    MessageBox.Show("Update NOT Ok");
            }
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            pesquisa_box.Visible = true;
            checkBox1.Visible = true;
            checkBox2.Visible = true;
            button3.Visible = true;
            farda_box.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            list_musicos.Enabled = true;
            if (list_musicos.Items.Count > 0)
            {
                currentContact = list_musicos.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }

        private void RemoveContact(int NIF)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "DELETE Banda.Musico WHERE NIF=@NIF";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", NIF);
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to delete contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            if (list_musicos.SelectedIndex > -1)
            {
                try
                {
                    RemoveContact(((Musicos_class)list_musicos.SelectedItem).NIF);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                list_musicos.Items.RemoveAt(list_musicos.SelectedIndex);
                if (currentContact == list_musicos.Items.Count)
                    currentContact = list_musicos.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more contacts");
                }
                else
                {
                    ShowContact();
                }
            }
        }

        private void farda_label_Click(object sender, EventArgs e)
        {

        }

        private void farda_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void naipe_label_Click(object sender, EventArgs e)
        {

        }

        private void nome_label_Click(object sender, EventArgs e)
        {

        }

        private void nome_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                int rows = 0;
                Fardas_Disponiveis fd = new Fardas_Disponiveis();
                fd.ShowDialog();
                int id_selecionado = fd.GetID();
                Musicos_class m = new Musicos_class();
                m.NIF = int.Parse(id_box.Text);
                m.DataNasc = DateTime.Parse(data_box.Text);
                m.Nome = nome_box.Text;
                m.Telefone = int.Parse(tele_box.Text);
                m.Naipe = naipe_box.Text;
                m.FardaID = id_selecionado;
                if (!verifySGBDConnection())
                    return;
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Banda.UpdateMusicoComFarda";
                cmd.Parameters.Clear();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@NIF", m.NIF);
                cmd.Parameters.AddWithValue("@Nome", m.Nome);
                cmd.Parameters.AddWithValue("@Data", m.DataNasc);
                cmd.Parameters.AddWithValue("@Naipe", m.Naipe);
                cmd.Parameters.AddWithValue("@Telefone", m.Telefone);
                cmd.Parameters.AddWithValue("@FardaId", m.FardaID);
                cmd.Connection = cn;

                try
                {
                    rows = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
                }
                finally
                {
                    if (rows == 1)
                        MessageBox.Show("Update OK");
                       
                    else
                        MessageBox.Show("Update NOT Ok");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            musicos_Load(sender, e);
        }



        private void button3_Click(object sender, EventArgs e)
        {
            Servico_por_Musico spm = new Servico_por_Musico(Int32.Parse(id_box.Text));
            spm.Show();
        }


        private void pesquisa_box_TextChanged(object sender, EventArgs e)
        {  
            string searchTerm = pesquisa_box.Text.ToLower();
            list_musicos.Items.Clear();

            if (checkBox1.Checked == true)
            {
                // Iterate over each item in the original list to perform filtering
                foreach (Musicos_class item in filteredItems)
                {
                    // Convert the nome property to lowercase for case-insensitive comparison
                    string nome = item.Nome.ToLower();

                    // Check if the search term is equal to or contained within the item's nome property
                    if (nome.Equals(searchTerm) || nome.Contains(searchTerm))
                    {
                        // If the search term is found, add the item to the filtered list
                        list_musicos.Items.Add(item);
                    }
                }
            }
            else {
                foreach (Musicos_class item in filteredItems)
                {
                    // Convert the nome property to lowercase for case-insensitive comparison
                    string naipe = item.Naipe.ToLower();

                    // Check if the search term is equal to or contained within the item's nome property
                    if (naipe.Equals(searchTerm) || naipe.Contains(searchTerm))
                    {
                        // If the search term is found, add the item to the filtered list
                        list_musicos.Items.Add(item);
                    }
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox2.Checked == true && checkBox1.Checked == true)
            {
                checkBox2.Checked = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true && checkBox2.Checked == true)
            {
                checkBox1.Checked = false;
            }
        }

        private void removerFardaBut_Click(object sender, EventArgs e)
        {
            try
            {
                int rows = 0;
                Musicos_class m = new Musicos_class();
                m.NIF = int.Parse(id_box.Text);
                m.DataNasc = DateTime.Parse(data_box.Text);
                m.Nome = nome_box.Text;
                m.Telefone = int.Parse(tele_box.Text);
                m.Naipe = naipe_box.Text;
                if (!verifySGBDConnection())
                    return;
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Banda.UpdateMusicoComFarda";
                cmd.Parameters.Clear();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@NIF", m.NIF);
                cmd.Parameters.AddWithValue("@Nome", m.Nome);
                cmd.Parameters.AddWithValue("@Data", m.DataNasc);
                cmd.Parameters.AddWithValue("@Naipe", m.Naipe);
                cmd.Parameters.AddWithValue("@Telefone", m.Telefone);
                cmd.Parameters.AddWithValue("@FardaId", DBNull.Value);
                cmd.Connection = cn;

                try
                {
                    rows = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Failed. \n ERROR MESSAGE: \n" + ex.Message);
                }
                finally
                {
                    if (rows == 1)
                        MessageBox.Show("Farda removida com sucesso");

                    else
                        MessageBox.Show("Farda não removida");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            musicos_Load(sender, e);
        }
    }
}
