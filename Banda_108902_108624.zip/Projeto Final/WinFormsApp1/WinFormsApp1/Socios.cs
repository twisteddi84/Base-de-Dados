﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Socios : Form
    {
        private SqlConnection cn;
        private int currentContact;
        private bool adding;
        public Socios()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void email_label_Click(object sender, EventArgs e)
        {

        }
        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }
        private void Socios_Load(object sender, EventArgs e)
        {

            Confirmar.Visible = false;
            Cancelar.Visible = false;
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Socio ", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            list_socios.Items.Clear();

            while (reader.Read())
            {
                Socio i = new Socio();
                i.NIF = (int)reader["NIF"];
                i.Nome = reader["nome"].ToString();
                i.Email = reader["email"].ToString();
                i.Tele = (int)reader["telefone"];

                list_socios.Items.Add(i);
            }
            reader.Close();
            cn.Close();


            currentContact = 0;
            ShowContact();
        }
        public void ShowContact()
        {
            if (list_socios.Items.Count == 0 | currentContact < 0)
                return;
            Socio i = new Socio();
            i = (Socio)list_socios.Items[currentContact];
            id_box.Text = i.NIF.ToString();
            nome_box.Text = i.Nome;
            tele_box.Text = i.Tele.ToString();
            email_box.Text = i.Email.ToString();
        }

        private void list_socios_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_socios.SelectedIndex >= 0)
            {
                currentContact = list_socios.SelectedIndex;
                ShowContact();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;    
        }
        public void ClearFields()
        {
            id_box.Text = "";
            tele_box.Text = "";
            nome_box.Text = "";
            email_box.Text = "";
        }

        public void UnlockControls()
        {
            id_box.ReadOnly = false;
            email_box.ReadOnly = false;
            nome_box.ReadOnly = false;
            tele_box.ReadOnly = false;
        }

        public void LockControls()
        {
            id_box.ReadOnly = true;
            email_box.ReadOnly = true;
            nome_box.ReadOnly = true;
            tele_box.ReadOnly = true;
        }

        public void HideButtons()
        {
            UnlockControls();
            Add.Visible = false;
            Atualizar.Visible = false;
            Remover.Visible = false;
        }


        public void ShowButtons()
        {
            LockControls();
            Add.Visible = true;
            Atualizar.Visible = true;
            Remover.Visible = true;
        }

        private void Add_Click(object sender, EventArgs e)
        {
            ver_cotas.Visible = false;
            adding = true;
            ClearFields();
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_socios.Enabled = false;
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                SaveSocio();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            ver_cotas.Visible = true;
            list_socios.Enabled = true;
            int idx = list_socios.FindString(id_box.Text);
            list_socios.SelectedIndex = idx;
            ShowButtons();
            Confirmar.Visible = false;
            Cancelar.Visible = false;
        }
        private bool SaveSocio()
        {
            Socio i = new Socio();
            try
            {
                i.NIF = int.Parse(id_box.Text);
                i.Nome = nome_box.Text;
                i.Tele = int.Parse(tele_box.Text);
                i.Email = email_box.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            if (adding)
            {
                SubmitContact(i);
                list_socios.Items.Add(i);
            }
            else
            {
                UpdateSocio(i);
                list_socios.Items[currentContact] = i;
            }
            return true;
        }
        private void SubmitContact(Socio C)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Banda.InsertSocio";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", C.NIF);
            cmd.Parameters.AddWithValue("@Nome", C.Nome);
            cmd.Parameters.AddWithValue("@Email", C.Email);
            cmd.Parameters.AddWithValue("@Telefone", C.Tele);


            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
        }
        private void UpdateSocio(Socio C)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.UpdateSocio";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", C.NIF);
            cmd.Parameters.AddWithValue("@Nome", C.Nome);
            cmd.Parameters.AddWithValue("@email", C.Email);
            cmd.Parameters.AddWithValue("@Telefone", C.Tele);
            cmd.Connection = cn;

            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                if (rows == 1)
                    MessageBox.Show("Update OK");
                else
                    MessageBox.Show("Update NOT Ok");
            }
        }

        private void Atualizar_Click(object sender, EventArgs e)
        {
            ver_cotas.Visible = false;
            if (currentContact <= 0)
            {
                //MessageBox.Show("Please select a contact to edit");
                currentContact = 1;
                //return;
            }
            adding = false;
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_socios.Enabled = false;
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            if (list_socios.SelectedIndex > -1)
            {
                try
                {
                    RemoveSocio(((Socio)list_socios.SelectedItem).NIF);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                list_socios.Items.RemoveAt(list_socios.SelectedIndex);
                if (currentContact == list_socios.Items.Count)
                    currentContact = list_socios.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more socio");
                }
                else
                {
                    ShowContact();
                }
            }
        }
        private void RemoveSocio(int NIF)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.DeleteSocio";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@NIF", NIF);
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to delete socio in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            ver_cotas.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            list_socios.Enabled = true;
            if (list_socios.Items.Count > 0)
            {
                currentContact = list_socios.SelectedIndex;
                if (currentContact < 0)
                    currentContact = 0;
                ShowContact();
            }
            else
            {
                ClearFields();
                LockControls();
            }
            ShowButtons();
        }

        private void ver_cotas_Click(object sender, EventArgs e)
        {
            Cotas_do_Socio cs = new Cotas_do_Socio(int.Parse(id_box.Text));
            cs.Show();
        }
    }
}
