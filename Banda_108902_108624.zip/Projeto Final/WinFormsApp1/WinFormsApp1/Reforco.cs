﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    class Reforco
    {
        private int _NIF;
        private string _nome;
        private string _naipe;
        private int _telefone;

        public int NIF
        {
            get { return _NIF; }
            set { _NIF = value; }
        }

        public string Nome
        {
            get { return _nome; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new Exception("Field 'nome' can't be empty");
                }
                _nome = value;
            }
        }

        public string Naipe
        {
            get { return _naipe; }
            set { _naipe = value; }
        }

        public int Telefone
        {
            get { return _telefone; }
            set { _telefone = value; }
        }

        
        public override string ToString()
        {
            return _NIF + "   " + _nome;
        }

        public Reforco() { }

        public Reforco(int NIF, string nome, string naipe, int telefone)
        {
            this._NIF = NIF;
            this._nome = nome;
            this._naipe = naipe;
            this._telefone = telefone;
        }

        public Reforco(int NIF, string nome)
        {
            this._NIF = NIF;
            this._nome = nome;
        }
    }
}
