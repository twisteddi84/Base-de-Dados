﻿
namespace WinFormsApp1
{
    partial class Reforcos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Remover = new System.Windows.Forms.Button();
            this.Atualizar = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Cancelar = new System.Windows.Forms.Button();
            this.Confirmar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tele_label = new System.Windows.Forms.Label();
            this.tele_box = new System.Windows.Forms.TextBox();
            this.naipe_label = new System.Windows.Forms.Label();
            this.naipe_box = new System.Windows.Forms.TextBox();
            this.nome_label = new System.Windows.Forms.Label();
            this.nome_box = new System.Windows.Forms.TextBox();
            this.nif_label = new System.Windows.Forms.Label();
            this.id_box = new System.Windows.Forms.TextBox();
            this.Musicos_label = new System.Windows.Forms.Label();
            this.list_reforcos = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Remover
            // 
            this.Remover.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Remover.Location = new System.Drawing.Point(319, 518);
            this.Remover.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Remover.Name = "Remover";
            this.Remover.Size = new System.Drawing.Size(128, 40);
            this.Remover.TabIndex = 64;
            this.Remover.Text = "Remover";
            this.Remover.UseVisualStyleBackColor = true;
            this.Remover.Click += new System.EventHandler(this.Remover_Click);
            // 
            // Atualizar
            // 
            this.Atualizar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Atualizar.Location = new System.Drawing.Point(172, 518);
            this.Atualizar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Atualizar.Name = "Atualizar";
            this.Atualizar.Size = new System.Drawing.Size(128, 40);
            this.Atualizar.TabIndex = 63;
            this.Atualizar.Text = "Atualizar";
            this.Atualizar.UseVisualStyleBackColor = true;
            this.Atualizar.Click += new System.EventHandler(this.Atualizar_Click);
            // 
            // Add
            // 
            this.Add.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Add.Location = new System.Drawing.Point(25, 518);
            this.Add.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(128, 40);
            this.Add.TabIndex = 62;
            this.Add.Text = "Adicionar";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Cancelar
            // 
            this.Cancelar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Cancelar.Location = new System.Drawing.Point(646, 357);
            this.Cancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(128, 40);
            this.Cancelar.TabIndex = 60;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // Confirmar
            // 
            this.Confirmar.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Confirmar.Location = new System.Drawing.Point(445, 357);
            this.Confirmar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Confirmar.Name = "Confirmar";
            this.Confirmar.Size = new System.Drawing.Size(128, 40);
            this.Confirmar.TabIndex = 59;
            this.Confirmar.Text = "Confirmar";
            this.Confirmar.UseVisualStyleBackColor = true;
            this.Confirmar.Click += new System.EventHandler(this.Confirmar_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(860, 22);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 40);
            this.button1.TabIndex = 58;
            this.button1.Text = "HOME";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tele_label
            // 
            this.tele_label.AutoSize = true;
            this.tele_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_label.Location = new System.Drawing.Point(614, 266);
            this.tele_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tele_label.Name = "tele_label";
            this.tele_label.Size = new System.Drawing.Size(136, 24);
            this.tele_label.TabIndex = 55;
            this.tele_label.Text = "TELEFONE:";
            this.tele_label.Click += new System.EventHandler(this.tele_label_Click);
            // 
            // tele_box
            // 
            this.tele_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tele_box.Location = new System.Drawing.Point(768, 262);
            this.tele_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.tele_box.Name = "tele_box";
            this.tele_box.ReadOnly = true;
            this.tele_box.Size = new System.Drawing.Size(187, 28);
            this.tele_box.TabIndex = 54;
            this.tele_box.TextChanged += new System.EventHandler(this.tele_box_TextChanged);
            // 
            // naipe_label
            // 
            this.naipe_label.AutoSize = true;
            this.naipe_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.naipe_label.Location = new System.Drawing.Point(340, 209);
            this.naipe_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.naipe_label.Name = "naipe_label";
            this.naipe_label.Size = new System.Drawing.Size(94, 24);
            this.naipe_label.TabIndex = 51;
            this.naipe_label.Text = "NAIPE:";
            this.naipe_label.Click += new System.EventHandler(this.naipe_label_Click);
            // 
            // naipe_box
            // 
            this.naipe_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.naipe_box.Location = new System.Drawing.Point(449, 208);
            this.naipe_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.naipe_box.Name = "naipe_box";
            this.naipe_box.ReadOnly = true;
            this.naipe_box.Size = new System.Drawing.Size(224, 28);
            this.naipe_box.TabIndex = 50;
            this.naipe_box.TextChanged += new System.EventHandler(this.naipe_box_TextChanged);
            // 
            // nome_label
            // 
            this.nome_label.AutoSize = true;
            this.nome_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_label.Location = new System.Drawing.Point(614, 158);
            this.nome_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nome_label.Name = "nome_label";
            this.nome_label.Size = new System.Drawing.Size(80, 24);
            this.nome_label.TabIndex = 49;
            this.nome_label.Text = "NOME:";
            this.nome_label.Click += new System.EventHandler(this.nome_label_Click);
            // 
            // nome_box
            // 
            this.nome_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nome_box.Location = new System.Drawing.Point(709, 158);
            this.nome_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.nome_box.Name = "nome_box";
            this.nome_box.ReadOnly = true;
            this.nome_box.Size = new System.Drawing.Size(268, 28);
            this.nome_box.TabIndex = 48;
            this.nome_box.TextChanged += new System.EventHandler(this.nome_box_TextChanged);
            // 
            // nif_label
            // 
            this.nif_label.AutoSize = true;
            this.nif_label.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nif_label.Location = new System.Drawing.Point(340, 158);
            this.nif_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nif_label.Name = "nif_label";
            this.nif_label.Size = new System.Drawing.Size(66, 24);
            this.nif_label.TabIndex = 47;
            this.nif_label.Text = "NIF:";
            this.nif_label.Click += new System.EventHandler(this.nif_label_Click);
            // 
            // id_box
            // 
            this.id_box.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_box.Location = new System.Drawing.Point(411, 158);
            this.id_box.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.id_box.Name = "id_box";
            this.id_box.ReadOnly = true;
            this.id_box.Size = new System.Drawing.Size(162, 28);
            this.id_box.TabIndex = 46;
            this.id_box.TextChanged += new System.EventHandler(this.id_box_TextChanged);
            // 
            // Musicos_label
            // 
            this.Musicos_label.AutoSize = true;
            this.Musicos_label.Font = new System.Drawing.Font("OCR A Extended", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Musicos_label.Location = new System.Drawing.Point(72, 7);
            this.Musicos_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Musicos_label.Name = "Musicos_label";
            this.Musicos_label.Size = new System.Drawing.Size(149, 29);
            this.Musicos_label.TabIndex = 45;
            this.Musicos_label.Text = "Reforços";
            this.Musicos_label.Click += new System.EventHandler(this.Musicos_label_Click);
            // 
            // list_reforcos
            // 
            this.list_reforcos.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_reforcos.FormattingEnabled = true;
            this.list_reforcos.ItemHeight = 17;
            this.list_reforcos.Location = new System.Drawing.Point(3, 40);
            this.list_reforcos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.list_reforcos.Name = "list_reforcos";
            this.list_reforcos.Size = new System.Drawing.Size(298, 463);
            this.list_reforcos.TabIndex = 44;
            this.list_reforcos.SelectedIndexChanged += new System.EventHandler(this.list_reforcos_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("OCR A Extended", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(552, 380);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(221, 54);
            this.button2.TabIndex = 65;
            this.button2.Text = "Ver Serviços Realizados ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Reforcos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 574);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Remover);
            this.Controls.Add(this.Atualizar);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.Confirmar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tele_label);
            this.Controls.Add(this.tele_box);
            this.Controls.Add(this.naipe_label);
            this.Controls.Add(this.naipe_box);
            this.Controls.Add(this.nome_label);
            this.Controls.Add(this.nome_box);
            this.Controls.Add(this.nif_label);
            this.Controls.Add(this.id_box);
            this.Controls.Add(this.Musicos_label);
            this.Controls.Add(this.list_reforcos);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Reforcos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reforcos";
            this.Load += new System.EventHandler(this.Reforcos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Remover;
        private System.Windows.Forms.Button Atualizar;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button Confirmar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label tele_label;
        private System.Windows.Forms.TextBox tele_box;
        private System.Windows.Forms.Label naipe_label;
        private System.Windows.Forms.TextBox naipe_box;
        private System.Windows.Forms.Label nome_label;
        private System.Windows.Forms.TextBox nome_box;
        private System.Windows.Forms.Label nif_label;
        private System.Windows.Forms.TextBox id_box;
        private System.Windows.Forms.Label Musicos_label;
        private System.Windows.Forms.ListBox list_alunos;
        private System.Windows.Forms.ListBox list_reforcaos;
        private System.Windows.Forms.ListBox list_reforcos;
        private System.Windows.Forms.Button button2;
    }
}