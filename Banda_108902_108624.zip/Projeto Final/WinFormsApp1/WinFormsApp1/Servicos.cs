﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Servicos : Form
    {

        private SqlConnection cn;
        private int currentContact;
        private bool adding;
        private List<string> selectedTipos;
        private List<int> selectedDiretores;
        private List<int> selectedMusicos;
        private List<int> selectedReforcos;

        public Servicos()
        {
            InitializeComponent();
        }
        private SqlConnection getSGBDConnection()
        {
            string userName = "p4g8";
            string userPass = "497397053@BDTD";
            string dbServer = "mednat.ieeta.pt\\SQLSERVER,8101";
            string dbName = "p4g8";
            return new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";User ID=" + userName + ";Password=" + userPass + ";");
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }
        private double ParseDouble(string value)
        {
            value = value.Replace("$", "").Replace(",", "");

            if (double.TryParse(value, out double result))
            {
                return result / 100; // Divide the value by 100 to get the desired format (e.g., 1900 becomes 19)
            }

            return 0.0;
        }

        private void Servicos_Load(object sender, EventArgs e)
        {
            list_servicos.Enabled = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            button2.Visible = true;
            cn = DatabaseManager.GetConnection();
            if (!verifySGBDConnection())
                return;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Banda.Servico ", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            list_servicos.Items.Clear();

            while (reader.Read())
            {
                Servico i = new Servico();
                i.ID = (int)reader["id"];
                i.DataServico = (DateTime)reader["data_servico"];
                i.Nome = reader["nome"].ToString();
                i.HoraInicio = (TimeSpan)reader["hora_ini"];
                i.Pagamento_per_musi = ParseDouble(reader["pagamento_por_musico"].ToString());
                i.Preco = (int)reader["preco"];
                i.Localidade = reader["localidade"].ToString();

                list_servicos.Items.Add(i);
            }
            reader.Close();
            cn.Close();


            currentContact = 0;
            ShowContact();

        }

        public void ShowContact()
        {
            if (list_servicos.Items.Count == 0 || currentContact < 0)
                return;

            Servico i = (Servico)list_servicos.Items[currentContact];
            id_box.Text = i.ID.ToString();
            data_box.Text = i.DataServico.ToString("yyyy-MM-dd");
            hora_box.Text = i.HoraInicio.ToString(@"hh\:mm\:ss");
            nome_box.Text = i.Nome;
            preco_box.Text = i.Preco.ToString();
            pag_musi_box.Text = i.Pagamento_per_musi.ToString();
            localidade_box.Text = i.Localidade.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            Visible = false;
        }

        private void list_servicos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (list_servicos.SelectedIndex >= 0)
            {
                currentContact = list_servicos.SelectedIndex;
                ShowContact();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int id_selecionado;
            cn = DatabaseManager.GetConnection();

            id_selecionado = int.Parse(id_box.Text);
            // O valor da caixa de texto foi convertido com sucesso para um número inteiro
            // Agora você pode usar o valor "id_selecionado" para obter os tipos de serviço associados

            string sqlQuery = "Banda.GetTipos_por_ServicoById";

            // Crie uma instância do SqlCommand e defina a conexão e a consulta
            SqlCommand cmd = new SqlCommand(sqlQuery, cn);

            cmd.CommandType = CommandType.StoredProcedure;

            // Adicione o parâmetro para o id_servico
            cmd.Parameters.AddWithValue("@id_servico", id_selecionado);

            // Execute a consulta e obtenha os tipos de serviço associados ao id_servico

            try
            {
                SqlDataReader reader = cmd.ExecuteReader();
                String mensagem = "Tipos de Serviço associados ao id_servico " + id_selecionado + "\n";
                while (reader.Read())
                {
                    String tipoServico = (String)reader["tipo_servico"];
                    mensagem += tipoServico + "\n";
                }

                reader.Close();
                MessageBox.Show(mensagem);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                // Lida com exceções, se necessário
            }
        }

        public void ClearFields()
        {
            id_box.Text = "";
            nome_box.Text = "";
            data_box.Text = "";
            hora_box.Text = "";
            localidade_box.Text = "";
            preco_box.Text = "";
            pag_musi_box.Text = "";

        }

        public void UnlockControls()
        {
            nome_box.ReadOnly = false;
            data_box.ReadOnly = false;
            hora_box.ReadOnly = false;
            localidade_box.ReadOnly = false;
            preco_box.ReadOnly = false;
            pag_musi_box.ReadOnly = false;

        }

        public void LockControls()
        {
            nome_box.ReadOnly = true;
            data_box.ReadOnly = true;
            hora_box.ReadOnly = true;
            localidade_box.ReadOnly = true;
            preco_box.ReadOnly = true;
            pag_musi_box.ReadOnly = true;

        }



        private void Add_Click(object sender, EventArgs e)
        {
            adding = true;
            list_servicos.Enabled = false;
            button2.Visible = false;
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            UnlockControls();
            ClearFields();
            SelectTipos st = new SelectTipos();
            st.CancelButtonClicked += SelectTipos_CancelButtonClicked; // Assinar o evento personalizado
            st.ShowDialog();

            // Receber a lista de checkboxes selecionadas do formulário SelectTipos
            selectedTipos = st.GetSelectedTipos();

        }

        private void SelectTipos_CancelButtonClicked(object sender, EventArgs e)
        {
            // Lógica a ser executada quando o botão "Cancelar" for clicado no formulário SelectTipos
            // Por exemplo, exibir uma mensagem ou realizar alguma ação específica
            Servicos_Load(sender, e);
        }

        private void Confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                SaveServico(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            list_servicos.Enabled = true;
            int idx = list_servicos.FindString(id_box.Text);
            list_servicos.SelectedIndex = idx;
            ShowButtons();
            button3.Visible = true;
            Confirmar.Visible = false;
            Cancelar.Visible = false;
        }

        public void ShowButtons()
        {
            LockControls();
            Add.Visible = true;
            Atualizar.Visible = true;
            Remover.Visible = true;
        }

        private bool SaveServico(object sender, EventArgs e)
        {
            Servico i = new Servico();
            try
            {
                i.HoraInicio = TimeSpan.Parse(hora_box.Text);
                i.Localidade = localidade_box.Text;
                i.Nome = nome_box.Text;
                i.Pagamento_per_musi = double.Parse(pag_musi_box.Text);
                i.Preco = int.Parse(preco_box.Text);
                i.DataServico = DateTime.Parse(data_box.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            if (adding)
            {
                SubmitServico(i, selectedTipos);
                list_servicos.Items.Add(i);
                list_servicos.Enabled = true;
                Confirmar.Visible = false;
                Cancelar.Visible = false;
                LockControls();
                Servicos_Load(sender, e);
            }
            else
            {

                UpdateServico(i);
                list_servicos.Items[currentContact] = i;
                list_servicos.Enabled = true;
                Confirmar.Visible = false;
                Cancelar.Visible = false;
                LockControls();
                Servicos_Load(sender, e);
            }
            return true;
        }

        private void UpdateServico(Servico C)
        {
            int rows = 0;

            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Banda.UpdateServico";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ID", int.Parse(id_box.Text));
            cmd.Parameters.AddWithValue("@Nome", C.Nome);
            cmd.Parameters.AddWithValue("@Localidade", C.Localidade);
            cmd.Parameters.AddWithValue("@Preco", C.Preco);
            cmd.Parameters.AddWithValue("@Hora", C.HoraInicio);
            cmd.Parameters.AddWithValue("@Data", C.DataServico);
            cmd.Parameters.AddWithValue("@Paga", C.Pagamento_per_musi);
            cmd.Connection = cn;

            try
            {
                rows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to update contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                if (rows == 1)
                    MessageBox.Show("Update OK");
                else
                    MessageBox.Show("Update NOT Ok");
            }
        }
        private void SubmitServico(Servico C, List<string> tiposSelecionados)
        {
            if (!verifySGBDConnection())
                return;

            cn = DatabaseManager.GetConnection();
            // Inserir o serviço na tabela Banda.Servico
            using (SqlCommand cmdInsertServico = new SqlCommand("Banda.InsertServico", cn))
            {
                cmdInsertServico.CommandType = CommandType.StoredProcedure;
                cmdInsertServico.Parameters.AddWithValue("@Nome", C.Nome);
                cmdInsertServico.Parameters.AddWithValue("@Localidade", C.Localidade);
                cmdInsertServico.Parameters.AddWithValue("@Preco", C.Preco);
                cmdInsertServico.Parameters.AddWithValue("@Hora", C.HoraInicio);
                cmdInsertServico.Parameters.AddWithValue("@Data", C.DataServico);
                cmdInsertServico.Parameters.AddWithValue("@Paga", C.Pagamento_per_musi);

                int idServico = Convert.ToInt32(cmdInsertServico.ExecuteScalar());

                // Inserir os tipos de serviço selecionados na tabela Banda.Tipos_por_Servico
                foreach (string tipoSelecionado in tiposSelecionados)
                {
                    SqlCommand cmdInsertTipoPorServico = new SqlCommand();
                    cmdInsertTipoPorServico.CommandType = CommandType.StoredProcedure;
                    cmdInsertTipoPorServico.CommandText = "Banda.InsertTiposPorServico";
                    cmdInsertTipoPorServico.Parameters.AddWithValue("@IdServico", idServico);
                    cmdInsertTipoPorServico.Parameters.AddWithValue("@TipoServico", tipoSelecionado);
                    cmdInsertTipoPorServico.Connection = cn;
                    cmdInsertTipoPorServico.ExecuteNonQuery();
                }
            }
            // Inserir os tipos de serviço selecionados na tabela Banda.Tipos_por_Servico

            MessageBox.Show("Tipos de serviço associados ao serviço com sucesso!");
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            list_servicos.Enabled = true;
            LockControls();
            Confirmar.Visible = false;
            Cancelar.Visible = false;
            Servicos_Load(sender, e);
        }

        private void Atualizar_Click(object sender, EventArgs e)
        {
            button3.Visible = false;
            currentContact = list_servicos.SelectedIndex;
            if (currentContact <= 0)
            {
                //MessageBox.Show("Please select a contact to edit");
                currentContact = 1;
                //return;
            }
            button2.Visible = false;
            adding = false;
            HideButtons();
            Confirmar.Visible = true;
            Cancelar.Visible = true;
            list_servicos.Enabled = false;
        }
        public void HideButtons()
        {
            UnlockControls();
            Add.Visible = false;
            Atualizar.Visible = false;
            Remover.Visible = false;
        }

        private void Remover_Click(object sender, EventArgs e)
        {
            if (list_servicos.SelectedIndex > -1)
            {
                try
                {
                    RemoveContact(((Servico)list_servicos.SelectedItem).ID);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                list_servicos.Items.RemoveAt(list_servicos.SelectedIndex);
                if (currentContact == list_servicos.Items.Count)
                    currentContact = list_servicos.Items.Count - 1;
                if (currentContact == -1)
                {
                    ClearFields();
                    MessageBox.Show("There are no more service");
                }
                else
                {
                    ShowContact();
                }
            }
        }

        private void RemoveContact(int ID)
        {
            if (!verifySGBDConnection())
                return;
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "DELETE Banda.Servico WHERE id=@ID";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Connection = cn;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to delete contact in database. \n ERROR MESSAGE: \n" + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Atribuir_Presencas ap = new Atribuir_Presencas();
                ap.ShowDialog();
                MessageBox.Show("Presenças Adicionadas com Sucesso !");
                // Receber a lista de checkboxes selecionadas do formulário SelectTipos
                selectedMusicos = ap.GetSelectedMusicos();
                // Receber a lista de checkboxes selecionadas do formulário SelectTipos
                selectedReforcos = ap.GetSelectedReforcos();
                // Receber a lista de checkboxes selecionadas do formulário SelectTipos
                selectedDiretores = ap.GetSelectedDiretores();
                SubmitMusicos(selectedMusicos);
                SubmitDiretores(selectedDiretores);
                SubmitReforcos(selectedReforcos);

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SubmitMusicos(List<int> tiposSelecionados)
        {
            if (!verifySGBDConnection())
                return;

            cn = DatabaseManager.GetConnection();

            // Inserir os tipos de serviço selecionados na tabela Banda.Tipos_por_Servico
            foreach (int tipoSelecionado in tiposSelecionados)
            {
                try
                {
                    SqlCommand cmdInsertTipoPorServico = new SqlCommand();
                    cmdInsertTipoPorServico.CommandText = "Banda.InsertServicoMusico";
                    cmdInsertTipoPorServico.CommandType = CommandType.StoredProcedure;
                    cmdInsertTipoPorServico.Parameters.AddWithValue("@ID", int.Parse(id_box.Text));
                    cmdInsertTipoPorServico.Parameters.AddWithValue("@NIF", tipoSelecionado);
                    cmdInsertTipoPorServico.Connection = cn;
                    cmdInsertTipoPorServico.ExecuteNonQuery();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
        private void SubmitDiretores(List<int> tiposSelecionados)
        {
            if (!verifySGBDConnection())
                return;

            cn = DatabaseManager.GetConnection();

            // Inserir os tipos de serviço selecionados na tabela Banda.Tipos_por_Servico
            foreach (int tipoSelecionado in tiposSelecionados)
            {
                try
                {
                    SqlCommand cmdInsertTipoPorServico = new SqlCommand();
                    cmdInsertTipoPorServico.CommandText = "Banda.InsertServicoDirecao";
                    cmdInsertTipoPorServico.CommandType = CommandType.StoredProcedure;
                    cmdInsertTipoPorServico.Parameters.AddWithValue("@ID", int.Parse(id_box.Text));
                    cmdInsertTipoPorServico.Parameters.AddWithValue("@NIF", tipoSelecionado);
                    cmdInsertTipoPorServico.Connection = cn;
                    cmdInsertTipoPorServico.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
        private void SubmitReforcos(List<int> tiposSelecionados)
        {
            if (!verifySGBDConnection())
                return;

            cn = DatabaseManager.GetConnection();

            // Inserir os tipos de serviço selecionados na tabela Banda.Tipos_por_Servico
            foreach (int tipoSelecionado in tiposSelecionados)
            {
                try
                {
                    SqlCommand cmdInsertTipoPorServico = new SqlCommand();
                    cmdInsertTipoPorServico.CommandText = "Banda.InsertReforcoServico";
                    cmdInsertTipoPorServico.CommandType = CommandType.StoredProcedure;
                    cmdInsertTipoPorServico.Parameters.AddWithValue("@ID", int.Parse(id_box.Text));
                    cmdInsertTipoPorServico.Parameters.AddWithValue("@NIF", tipoSelecionado);
                    InputBoxPreco ip = new InputBoxPreco(tipoSelecionado);
                    ip.ShowDialog();
                    double preco = ip.getPreco();
                    cmdInsertTipoPorServico.Parameters.AddWithValue("@PRECO", preco);
                    cmdInsertTipoPorServico.Connection = cn;
                    cmdInsertTipoPorServico.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
    }
}

